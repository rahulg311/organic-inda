import { Component, useEffect } from 'react';
import { Route, Switch } from 'react-router-dom';
import { Routes } from './routes/routes';
import TopNave from './components/common/TopNave';
import Header from "./components/common/Header";
import Manu from './components/common/Manu';
import Footer from './components/common/Footer';
import { APP_NAME } from './config/constants';





const App = () => {

	useEffect(() => {
		document.title = APP_NAME
	});

	return (
		<section>
			<header>
				<TopNave ></TopNave>
			</header>
			<main class='pt-7'>
				<Header></Header>
				<Switch>
					{Routes.map((route, idx) => (
						<Route
							key={idx}
							exact={route.exact}
							path={route.path}
							component={route.component}
						/>
					))}
				</Switch>
			</main>
			<footer>
				<Footer></Footer>
			</footer>
		</section>
	);
}

export default App

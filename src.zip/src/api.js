import axios from 'axios'
import { END_POINT } from './routes/paths';
const api = {
    get: (url) =>  axios.get(END_POINT + url),
    post: (url)=> axios.post(END_POINT + url),
    postother: (request) => axios.post(
        END_POINT + request.url,
        request.data
    ),
    postOtherApi: (request) => axios.post(
        END_POINT + request.url,
        request.data,
        {
            headers: { ...request.headers, }
        }),
        postMarchPayment: (request , formData) => axios.post(
             request.url,
             formData,
            {
                headers: { ...request.headers, }
            }),

        
    
    

}
export default api;
import React from "react";

const ButtonTriangle = () => {
  return (
      <div className="buttonTriangle d-flex">
          <div className="buttonTriangle_left"></div>
          <div className="buttonTriangle_button "> 
                                      <p>BUY NOW</p>
                                    </div>
          <div className="buttonTriangle_right"></div>
      </div>
  );
};

export default ButtonTriangle;

import React, { useState } from 'react';
import Quantity from "./Quantity"

const ProductCard = ({ item, decrementProduct, deleteProduct, incrementProduct }) => {
	return (
		<div class='card-body  px-md-0 px-0 mb-4'>
			<div>
				<div class='d-flex mb-3'>
					<div class='d-lg-flex'>
						<div>
							<img
								src={
									item.media_file_path
										? item.media_file_path
										: '/assets/imgs/no-image.png'
								}
								alt=''
								class='w-lg-sm w-100 h-lg-sm h-sm border p-2 rounded-4 me-lg-4'
							/>
						</div>
						<div>
							<h6 class='mb-1 me-lg-5 mt-lg-0 mt-4'>
								<a href='#'>{item.prd_title}</a>
							</h6>
							<p>₹{item.price}</p>
							<div>
								<div class='d-flex align-items-center justify-content-between justify-content-lg-start ms-1'>
									<Quantity
										item={item}
										decrementProduct={decrementProduct}
										incrementProduct={incrementProduct}
									/>
									{/* <button class='btn btn-sm ms-3 px-1 fs-19'>
							<i class='far fa-heart m-0'></i>
						</button> */}
									<button
										class='btn btn-sm px-1 ms-3 fs-17'
										onClick={() => deleteProduct(item.id)}
									>
										<i class='fas fa-trash'></i>
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ProductCard

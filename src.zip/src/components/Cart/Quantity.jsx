import React, { useState } from 'react';
import Loading from '../Loading';
import useAuth from '../../hooks/useAuth';
const Quantity = ({ item, incrementProduct,decrementProduct }) => {
	
	return (
		<nav class='mb-0'>
			<ul class='pagination mb-0 pagination-sm'>
				<li class='page-item cursor' onClick={()=>{
					decrementProduct(item.id)
				}}>
					<span class='page-link'>-</span>
				</li>
				<li class='page-item'>
					<span class='page-link'>{item.quantity}</span>
				</li>
				<li
					class='page-item cursor'
					onClick={() => {
						incrementProduct(item.id);
					}}
				>
					<span class='page-link'>+</span>
				</li>
			</ul>
		</nav>
	);
};

export default Quantity

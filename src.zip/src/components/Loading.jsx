import React from 'react'
import  '../../src/components/Products/Loading.css'

const Loading = ({ className, size }) => {
	return (
		<div style={{position:"fixed", height:"100vh", width:"100%", background:"#00000050", top:0 , alignItems:"center", justifyContent:"center", display:"flex",  zIndex: "2"}}>
			<div style={{alignItem:"center", display:"flex", justifyContent:"center", position:"absolute"}}>
			<div className={className}>
				<div class={`spinner-border spinner-border-${size}`} role='status'>
					<span class='visually-hidden'>Loading...</span>
				</div>
			</div>

			</div>
			
			</div>
		
	);
}

export default Loading

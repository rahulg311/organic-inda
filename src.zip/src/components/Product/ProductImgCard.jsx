import React from 'react'
import Loading from "../Loading";

const ProductImgCard = ({
	product,
	decrementProduct,
	incrementProduct,
	addToCart,
	loading,
	quantity,
}) => {
	return (
		<div className='col'>
			<div className='w-100 p-2 rounded-4  border'>
				<img
					src={
						product?.media_file_path ? product.media_file_path : '/assets/imgs/no-image.png'
					}
					alt=''
					className='w-100 rounded-4 '
				/>
				<div className='mt-4 center mb-3'>
					<img
						src={
							product?.media_file_path ? product.media_file_path : '/assets/imgs/no-image.png'
						}
						alt=''
						className='w-90px h-90px rounded-2 me-3 '
					/>
					<img
						src={
							product?.media_file_path ? product.media_file_path : '/assets/imgs/no-image.png'
						}
						alt=''
						className='w-90px h-90px rounded-2 me-3 '
					/>
					<img
						src={
							product?.media_file_path ? product.media_file_path : '/assets/imgs/no-image.png'
						}
						alt=''
						className='w-90px h-90px rounded-2'
					/>
				</div>
				<div className='mt-4 center align-items-center'>
					<nav class='mb-0'>
						<ul class='pagination mb-0 pagination'>
							<li class='page-item cursor' onClick={decrementProduct}>
								<span class='page-link'>-</span>
							</li>
							<li class='page-item'>
								<span class='page-link'>{quantity}</span>
							</li>
							<li class='page-item cursor' onClick={incrementProduct}>
								<span class='page-link'>+</span>
							</li>
						</ul>
					</nav>
					<div class='ms-4 py-1 d-flex justify-content-between align-items-start'>
						<button class='btn btn-success py-2 px-5' onClick={addToCart} disabled={loading}>
							{loading ? <Loading size='sm' /> : 'Add to Cart'}
						</button>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ProductImgCard

import React from 'react'

const ProductInfo = ({ product, total }) => {
	return (
		<div className='col'>
			<div>
				<div className='d-lg-flex justify-content-lg-between mb-3 align-items-lg-center'>
					<h3>{product?.prd_title}</h3>
					<h1 className='ms-lg-4'>₹{total}</h1>
				</div>
				<p>
					Ashwagandha (Withania somnifera) has been used as an herbal supplement for centuries
					as a natural source of energy and vitality. Classified as an adaptogenic herb,
					Ashwagandha promotes a healthy response to environmental, emotional, and physical
					stress, and has been linked to lower cortisol and blood sugar levels. ORGANIC INDIA
					ashwagandha capsules can be taken as a daily dietary supplement to promote restful
					sleep and help manage chronic stress and anxiety, as well as bolster the immune
					system and improve brain function.
				</p>
				<h6 class='mt-4 mb-4'>BENEFITS</h6>
				<ul>
					<li className='mb-2'>
						Promotes restful sleep without sedating. Supports endurance, vitality and
					</li>
					<li className='mb-2'>
						Promotes restful sleep without sedating. Supports endurance, vitality and
					</li>
					<li className='mb-2'>
						Promotes restful sleep without sedating. Supports endurance, vitality and
					</li>
					<li className='mb-2'>
						Promotes restful sleep without sedating. Supports endurance, vitality and
					</li>
				</ul>
			</div>
		</div>
	);
};

export default ProductInfo

import React, { Component  } from "react";
import Slider from "react-slick";
import { Link } from "react-router-dom";

export default class ProductList extends Component {
  constructor() {
    super()
    this.state = {
      prodData:  []
    }

  }
  componentDidMount(){
    this.setState({prodData: this.props.ProdData})
  }
  render() {
    console.log(this.props.ProdData, "product list ")
    console.log(this.state.prodData, "product list  state")
    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 4,
      initialSlide: 0,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    };
    return (
      <div className="h-50  mt-2 mb-2 ">
    
        <Slider {...settings}>

          {
            this.state.prodData && this.state.prodData.map((item , index)=>(
              <div className='center flex-column    '>
						<Link to={`/productcart/:${item.prd_slug}` }className=" w-90 h_50" >
								<img src={item.image} class='rounded-3 w-1-100 w-100 h-100   obj-fit  ' alt='' onClick={()=>{this.props.setID(item.prd_slug)}} />
							</Link>
							{/* <button class='btn btn-warning bg-opacity-50 mt-2 text-white'>Shop Now</button> */}
							<a href="" className='text-muted mt-4 fs-13'> {item.prd_title}</a>
							<div>
                <p>
                  <h8>₹ {item.prd_selling_price}</h8>
                  
                </p>
              </div>
						</div>

            ))
          }
      	
        </Slider>
      </div>
    );
  }
}
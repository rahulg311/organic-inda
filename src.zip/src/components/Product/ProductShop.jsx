import React, { Component } from "react";
import Slider from "react-slick";

export default class ProductShop extends Component {

  constructor() {
    super()
    this.state = {
      catergory: []
    }

  }
  selectCat = (item) => {
    console.log(item,"category id check")
    this.props.catProductList(item);
    this.props.setId(item);
    this.props.setValue(3);
    this.props.setCurrentPage(1)

  }
  componentDidMount() {
    this.setState({ catergory: this.props.catergory })
  }
  render() {
    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 4,
      initialSlide: 0,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
            dots: true
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    };
    return (
      <div className=" ms-4 me-4 mt-2 mb-2">
        <Slider {...settings}>

          {
            this.state.catergory && this.state.catergory.map((item, index) => (
              <div className="row px-2 px-3">
                <div class='col-12  '>
                  <div class=' mb-4'>
                    <img src={item.category_image} alt='' class='card-img-top  w-100' />
                    <div class='card-body mt-1 text-center green-h rounded-bottom-7 '>
                      <p class='card-title'>
                        <button style={{border:0, background:0}} onClick={() => this.selectCat(item.category_id)} className='text-white' >{item.title}</button>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))
          }



        </Slider>
      </div>
    );
  }
}
import React from 'react'

const Review = ({ comment }) => {
	return (
		<div className='col'>
			<div className='mb-4'>
				<div className='d-flex align-items-center'>
					<img
						src='/assets/imgs/no-image.png'
						class='w-50px h-50px rounded-circle'
						alt=''
					/>
					<h6 class='mb-0 ms-3'>Safdar Azeem</h6>
				</div>
			</div>
			<p class=''>
				Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae nostrum reprehenderit
				autem et consequuntur magni atque iure n
			</p>
			<div>
				<img
					src='/assets/imgs/no-image.png'
					class='w-60px me-3 h-60px rounded-3'
					alt=''
				/>
				<img
					src='/assets/imgs/no-image.png'
					class='w-60px me-3 h-60px rounded-3'
					alt=''
				/>
				<img
					src='/assets/imgs/no-image.png'
					class='w-60px me-3 h-60px rounded-3'
					alt=''
				/>
			</div>
			<div class='mt-5 d-md-flex justify-content-md-between'>
				<button class='btn btn-outline-success mb-md-0 mb-4'>
					<i class='fas fa-thumbs-up me-2'></i>
					helpful
				</button>
				<small>2 people found this review helpful</small>
			</div>
		</div>
	);
};

export default Review

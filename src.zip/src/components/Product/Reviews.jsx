import React from 'react'
import Review from './Review';
const Reviews = () => {
	return (
		<div className='mt-8'>
			<h2 className='mb-7'>Most Useful Reviews</h2>
			<div className='row  gy-md-9 gy-6 gx-9 row-cols-md-2 row-cols-1'>
				<Review />
				<Review />
				<Review />
			</div>
		</div>
	);
};
export default Reviews

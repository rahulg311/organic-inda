import React from 'react'
import SellingProduct from '../home/SellingProduct'

const SuggestedProducts = () => {
    return (
			<div>
				<div>
					<SellingProduct title='You may also like' />
				</div>
			</div>
		);
}

export default SuggestedProducts

import React from 'react';
import { Link } from 'react-router-dom';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import '@splidejs/splide/dist/css/themes/splide-skyblue.min.css';

const HerbalSelling = ({ title }) => {
	return (
		<div class='   text-white py-2'>
			{/* <header>
				<div className='text-center mb-5 pb-3'>
					<h1 className=''>{title}</h1>
				</div>
			</header> */}

			<div className='container'>
				<Splide
					options={{
						rewind: true,
						gap: '8rem',
						perPage: 5,
						pagination: false,
						drag: false,
						perMove: 3,
						breakpoints: {
							1100: {
								perPage: 2,
							},
							680: {
								perPage: 1,
							},
						},
						classes: {
							arrows: '',
							arrow: `splide__arrow text-white `,
							prev: 'splide__arrow--prev your-class-prev border rounded-circle p-2 ',
							next: 'splide__arrow--next  border rounded-circle p-2 ',
						},
					}}
				>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/h1.png' class='rounded-3 ' alt='' />
							</Link>
							{/* <button class='btn btn-warning bg-opacity-50 mt-2 text-white'>Shop Now</button> */}
							<a href="" className='green-h-text mt-4 fs-16'>Immunity Kit</a>
						</div>
					</SplideSlide>

					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/1.png' class='rounded-3 ' alt='' />
							</Link>
							<a href="" className='green-h-text mt-4 fs-16'>Tulsi Ginger </a>
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/3.png' class='rounded-3 ' alt='' />
							</Link>
							<a href="" className='green-h-text mt-4 fs-16'>Kalmegh</a>
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/4.png' class='rounded-3 ' alt='' />
							</Link>
							<a href="" className='green-h-text mt-4 fs-16'>Amalaki</a>
						</div>
					</SplideSlide>
                    <SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/2.png ' class='rounded-3 ' alt='' />
							</Link>
							<a href="" className='green-h-text mt-4 fs-16'>Suger Balance</a>
						</div>
					</SplideSlide>
                    <SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/4.png' class='rounded-3 ' alt='' />
							</Link>
							<a href="" className='green-h-text mt-4 fs-16'>Immunity Kit</a>
						</div>
					</SplideSlide>
				</Splide>
			</div>
		</div>
	);
};

export default HerbalSelling;

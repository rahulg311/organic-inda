import React, { useState } from 'react';
import { Link } from "react-router-dom"
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';
import Loading from '../Loading';

const ProductCard = ({ item }) => {
	const [loading, setLoading] = useState(false);

	const { response, isLoading, doPost } = usePost();
	const { getUserToken, getUserId } = useAuth();

	const addToCart = async () => {

		setLoading(true);
		const getCardData = JSON.parse(localStorage.getItem('cart'));
		if (getCardData) {
			const checkItem = getCardData.find(e => e.id === item.id);

			if (checkItem) {
				const newCardData = getCardData.map(item => {


					addToCartApi(item);

					if (item.id === checkItem.id) {
						const quantity = item.quantity + 1;
						item.quantity = quantity;
						item.price = item.actualPrice * quantity;
					}
					return item;
				})
				localStorage.setItem('cart', JSON.stringify(newCardData));
				setTimeout(() => {
					setLoading(false);
				}, 500);
				return;
			} else {

				item['quantity'] = 1;
				addToCartApi(item);

				localStorage.setItem('cart', JSON.stringify(item));

			}

			const newCardData = [
				...getCardData,
				{ ...item, quantity: 1, price: item.prd_mrp, actualPrice: item.prd_mrp },
			];
			localStorage.setItem('cart', JSON.stringify(newCardData));
			setTimeout(() => {
				setLoading(false);
			}, 500);


			return;
		}
		const newCardData = [
			{ ...item, quantity: 1, price: item.prd_mrp, actualPrice: item.prd_mrp },
		];
		localStorage.setItem('cart', JSON.stringify(newCardData));
		setTimeout(() => {
			setLoading(false);
		}, 500);
		return;
	}

	const addToCartApi = (item) => {

		if (getUserToken()) {

			/* send cart to api */
			const data = {
				'user_id': getUserId(),
				'product_id': item.id,
				'quantity': item.quantity
			};

			const headers = {
				headers: {
					'TOKEN-KEY': getUserToken(),
					id: getUserId(),
				},
			};

			doPost('add_to_cart', data, headers);
			/* send cart to api */
		}


	}


	return (
		<div class='col-12 col-md-6 col-lg-4'>
			<div class='card mb-4'>
				<Link to={`/product/${item.id}`}>
					<img src={item.media_file_path} alt='' class='card-img-top h-md' />
				</Link>
				<div class='card-body text-center'>
					<h6 class='card-title'>
						<Link to={`/product/${item.id}`}>{item.prd_title}</Link>
					</h6>
					<div class='text-center mb-3 mt-4'>
						<button
							class={`btn me-3 bg-secondary bg-opacity-25  w-100 `}
							onClick={addToCart}
							disabled={loading}
						>
							{loading ? <Loading size='sm' /> : 'Add to Cart'}
						</button>
					</div>
				</div>
			</div>
		</div>
	);
};

export default ProductCard;

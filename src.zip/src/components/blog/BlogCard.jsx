import React from 'react'
import { Link } from 'react-router-dom';

const BlogCard = ({ item }) => {
	return (
		<div class='col'>
			<Link to={`/blog/${item.id}`}>
			<img
				src={
					item?.media_file_path
						? item?.media_file_path
						: 'https://developer.fbw.center/assets/no-image.png'
				}
				class='w-100 rounded-3 h-md'
				alt=''/>
			
			</Link>
			<div class='mt-4'>
				{item?.created_at.split(' ')[0].split('-').reverse().join('/')}
				<h4>
					<Link to={`/blog/${item.id}`}>{item?.blog_title}</Link>
				</h4>
				<p dangerouslySetInnerHTML={{ __html: item?.blog_description }}></p>
			</div>
		</div>
	);
};

export default BlogCard;
import React from 'react'
import { Link, NavLink } from 'react-router-dom'
const Footer = () => {
	return (
		<div className='bg-success w-100   py-6'>
			<div className='container text-white'>
				<div className='row pb-1 gx-9 gy-5'>
					<div class='col-md-3 col-12 text-center'>
						<img
							src='https://organicindiausa.com/wp-content/uploads/2019/11/OIWhite_logo.svg'
							alt=''
							class='w-90 menu-responsive-70'
						/>
					</div>
					<div className='col-md-9 col-12'>
						<div className='d-md-flex mb-md-6 mb-7 border-bottom  border-dark justify-content-between'>
							<div>
								<h1>Join Our Community</h1>
								<p>SAVE 15% WHEN YOU SIGN UP!</p>
							</div>
							<div className='w-md-lg mt-md-0  '>
								<div className='row mb-4'>
									<div className='col-12'>
										<input
											type='text'
											className='form-control w-75    width-67 float-start'
											placeholder='your email address '
										></input>
										<button type="button" class="btn green-h-textt bg-white float-end  ">Subscribe</button>
									</div>
								</div>



							</div>
						</div>
						<section className='row text-white row-cols-lg-4  gy-7 row-cols-md-2 row-cols-2'>
							<div class='d-flex flex-column '>
								<Link className='text-white text-opacity-75 mb-4' to='/productcategory'>
									ABOUT OUR PRODUCTS
								</Link>
								<Link className='text-white text-opacity-75 mb-4' to='/ourstory'>
									OUR STORY
								</Link>
								<Link className='text-white text-opacity-75 mb-4' to='/regenerative'>
									REGENERATIVE AGRICULTURE
								</Link>
								<Link className='text-white text-opacity-75 mb-4' to='/meetfarmers'>
									MEET THE FARMERS
								</Link>
							</div>
							<div class='d-flex flex-column '>
								<Link className='text-white text-opacity-75 mb-4' to='/blogs'>
									BLOG
								</Link>
								<Link className='text-white text-opacity-75 mb-4' to='/blogs'>
									PRESS
								</Link>
								<Link className='text-white text-opacity-75 mb-4' to='/faqs'>
									FAQS
								</Link>

							</div>
							<div class='d-flex flex-column m-top-15 '>

								<Link className='text-white text-opacity-75 mb-4' to='/storeLocator'>
									STORE LOCATOR
								</Link>
								<Link className='text-white text-opacity-75 mb-4' to='/wholeherb'>
									WHOLESALE
								</Link>

								<NavLink className='text-white text-opacity-75 mb-4' to='/contect'>
									CONTACT
								</NavLink >

							</div>
							<div class='d-flex flex-column m-top-15 '>
								<h4>Shop Now</h4>
								{/* <div className='text-center mt-0 pt-0'>
							<img src='/assets/imgs/bor.png' alt='' className='w-100 ' />
						</div> */}
								<div class='d-flex justify-content-between flex-wrap '>

									<div class='w-35px h-35px mb-2 center border border-white rounded-circle'>
										<i class='fab btn p-0 text-white fa-linkedin fs-6'></i>
									</div>
									<div class='w-35px h-35px center border border-white rounded-circle'>
										<i class='fab btn p-0 text-white fa-twitter fs-6'></i>
									</div>
									<div class='w-35px h-35px center border border-white rounded-circle'>
										<i class='fab btn p-0 text-white fa-instagram fs-6'></i>
									</div>

									<div class='w-35px h-35px center border border-white rounded-circle'>
										<i class='fab btn p-0 text-white fa-facebook fs-6'></i>
									</div>
								</div>
							</div>
						</section>
					</div>
				</div>
			</div>

			<div className='container text-white m-top-15'>
				<div class='text-center w-80 mx-auto  '>
					<p class='fs-15'>
						©2021 ORGANIC INDIA | Privacy Policy | Terms & Conditions | Limited Warranty
					</p>
					<small className='fs-11 w-100'>
						DISCLAIMER: The products and any claims made about specific products on or
						through this site have not been evaluated by the United States Food and Drug
						Administration and are not approved or intended to diagnose, treat, cure or
						prevent disease. This site is not intended to provide diagnosis, treatment or
						medical advice. Content provided on this site for informational purposes only.
					</small>
				</div></div>
			<img src='/assets/imgs/borderimg.png' alt='' className='w-100  m-xs-img  m-img mt-2' />




		</div>
	);
}

export default Footer

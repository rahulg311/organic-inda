import React from 'react';
import { Link, NavLink } from "react-router-dom";
const Header = () => {
	return (
		<div className=''>
			<div className='container '>
				<div className='row'>
					<div className='col-md-2 col-12'>
					<Link className='navbar-brand  menu-responsive ' to='/'>
						<img src='/assets/imgs/logo.png' alt='' className='  mt-2 w-180px menu-responsive ' />
					</Link>
					</div>
					<div className='col-md-5 col-12'>
					<div class="input-group mt_7 ps-3  pt-3 ">
								<input type="text" class="form-control border-radius-0" placeholder="Search" aria-label="Input group example" aria-describedby="btnGroupAddon" /><div class="input-group-prepend">
									<div class="input-group-text h-100 bg-transparent border-radius-0" id="btnGroupAddon">
										<i className="fa fa-search"></i>
									</div>
								</div>
							</div>
					</div>
					<div className='col-md-5 col-12'>
						<div className='row mt_5 pt_0'>
							<div className='col-md-12'>
								<ul className='ull rahul   d-flex justify-content-around m-0 p-0 '>
								<li className='nav-item m-0 p-0  '>
								<NavLink activeClassName='active fw-medium' exact to='/ourstory' className='nav-link   '>
								
								<p className=' pt-4    fs-15 navv  menu-responsive-herder'>	OurStory</p>
								</NavLink>
							</li>
							<li className='nav-item m-0 p-0'>
								<NavLink activeClassName='active fw-medium' exact to='/blogs' className='nav-link '>
								
								<p className=' pt-4  fs-15 navv  menu-responsive-herder '>	Media</p>
								</NavLink>
							</li>
							<li className='nav-item m-0 p-0 '>
								<NavLink activeClassName='active fw-medium ' exact to='/herbs' className='nav-link '>
								
								<p className=' pt-4 fs-15 navv menu-responsive-herder  '>	Herbs</p>
								</NavLink>
							</li>
							<li className='nav-item m-0 p-0 '>
								<NavLink activeClassName='active fw-medium' exact to='/blogs' className='nav-link '>
								
								<p className=' pt-4 fs-15 navv  menu-responsive-herder '>	Blog</p>
								</NavLink>
							</li>

							<li className='nav-item m-0 p-0'>
								<NavLink activeClassName='active fw-medium' exact to='/contect' className='nav-link '>
								
								<p className=' pt-4 fs-15 navv  menu-responsive-herder '>	Connect</p>
								</NavLink>
							</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		
		</div>
	);
};

export default Header;

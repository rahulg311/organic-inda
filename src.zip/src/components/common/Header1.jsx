
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';

import ProductssSelling from '../../../components/Products/ProductssSelling';
// import ProductssSelling from '../../components/ProductssSelling/ProductssSelling';
// import ProductssSelling from '../../components/Products/HerbalSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const NewLauncher = () => {
	const { data, isLoading, error, doFetch } = useFetch();
	const [products, setProducts] = React.useState([]);
	const [currentPage, setCurrentPage] = React.useState(1);
	const productsSection = useRef();
    const[show1, setShow1] = useState(false);
    const[show2, setShow2] = useState(false);
    const[show3, setShow3] = useState(false);
    const[show4, setShow4] = useState(false);

	const nextPage = () => {
		setCurrentPage(currentPage + 1);
		doFetch(`product?page=${currentPage + 1}&limit=5`);
	};

	const prevPage = () => {
		if (currentPage === 1) {
			return;
		}
		setCurrentPage(currentPage - 1);
		doFetch(`product?page=${currentPage - 1}&limit=5`);
	};

	useEffect(() => {
		doFetch(`product?page=1&limit=5`);
	}, []);

	useEffect(() => {
		if (data) {
			setProducts(data.data);
		}
	}, [data]);

	return (
        <div className='mt-2 row '> 
        <div className='col-md-12 col-12'>
        {/* <div className=' position-relative'>
            <img
                src='https://images.unsplash.com/photo-1498837167922-ddd27525d352?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80'
                alt=''
                class='w-100 h-lg2'
            />
            <h1 className='translate-center-middle text-white bg-dark bg-opacity-25 p-4 rounded-4'>
                shop now
            </h1>
        </div> */}
        <>
        <div className='row   banner-herb  '>
			<div
				className=' col-md-12   d-flex justify-content-center h-420   align-items-center d-block optocity-b bg-dark  ' 
			
			>

				<h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong>NEW LAUNCHES</strong> </h1>
			</div>
		</div>
                </>
                <div className='container mt-10  '>
           
           <section className='row gy-6 '>
               <div className='col-12 col-md-2 col-lg-3 h-50  border'>
               <div className='row green-h'>
               <div className='col-12 pt-1'>
                   <p className='p-1 pt-2  fs-19 text-white'>Filter by</p>
               </div>
           </div>
           <div className=' row p-1  border text-muted'>
               <div className='col-10 mt-2 mb-2 fs-6 border-0 text-muted'>
                   Tulshi Infusion
                   
                   </div>
                   <div className='col-2 mt-2'>
                   <i class="fas fa-chevron-down" onClick={(e) =>setShow1(!show1)}></i>
                   </div>
{
   show1 == true && <>

   
   <ul class="list-group ">
 <li class="list-group-item border-none navv">Tulsi Tea</li>
 <li class="list-group-item border-none navv">Ashwagandha</li>
 <li class="list-group-item border-none navv">Darjiling Tea</li>
 <li class="list-group-item border-none navv">Tulsi Brahmi Tea</li>
 <li class="list-group-item border-none navv">View All</li>
</ul>
   </>
}

                   

           </div>
           <div className=' row p-1  border text-muted'>
               <div className='col-10 mt-2 mb-2 fs-6 border-0'>
               Herbs
                   
                   </div>
                   <div className='col-2 mt-2'>
                   <i class="fas fa-chevron-down" onClick={(e) =>setShow2(!show2)}></i>
                   </div>
{
   show2 == true && <>

   
   <ul class="list-group ">
 <li class="list-group-item border-none navv">Tulsi Tea</li>
 <li class="list-group-item border-none navv">Ashwagandha</li>
 <li class="list-group-item border-none navv">Darjiling Tea</li>
 <li class="list-group-item border-none navv">Tulsi Brahmi Tea</li>
 <li class="list-group-item border-none navv">View All</li>
</ul>
   </>
}

                   

           </div>
           <div className=' row p-1  border text-muted'>
               <div className='col-10 mt-2 mb-2 fs-6 border-0'>
               Health Benifits
                   
                   </div>
                   <div className='col-2 mt-2'>
                   <i class="fas fa-chevron-down" onClick={(e) =>setShow3(!show3)}></i>
                   </div>
{
   show3 == true && <>

   
   <ul class="list-group ">
 <li class="list-group-item border-none navv">Tulsi Tea</li>
 <li class="list-group-item border-none navv">Ashwagandha</li>
 <li class="list-group-item border-none navv">Darjiling Tea</li>
 <li class="list-group-item border-none navv">Tulsi Brahmi Tea</li>
 <li class="list-group-item border-none navv">View All</li>
</ul>
   </>
}

                   

           </div>
           <div className=' row p-1  border text-muted'>
               <div className='col-10 mt-2 mb-2 fs-6 border-0'>
               Best Sellers
                   
                   </div>
                   <div className='col-2 mt-2'>
                   <i class="fas fa-chevron-down" onClick={(e) =>setShow4(!show4)}></i>
                   </div>
{
   show4 == true && <>

   
   <ul class="list-group ">
 <li class="list-group-item border-none navv">Tulsi Tea</li>
 <li class="list-group-item border-none navv">Ashwagandha</li>
 <li class="list-group-item border-none navv">Darjiling Tea</li>
 <li class="list-group-item border-none navv">Tulsi Brahmi Tea</li>
 <li class="list-group-item border-none navv">View All</li>
</ul>
   </>
}

                   

           </div>
         
           {/* <div className='row p-1  border'>
           <div className='col-12 mt-2'>
               <select class='form-select mb-2 fs-6 border-0' >
                       <option selected>Herbs</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   </div>
              

           </div> */}
         
           {/* <div className='row p-1  border'>
           <div className='col-12 mt-2'>
               <select class='form-select mb-2 fs-6 border-0' >
                       <option selected>Health Benifits</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   </div>
          
           
            

           </div> */}
         {/* <div className='row p-1  '>
         <div className='col-12 mt-2'>
               <select class='form-select mb-2 fs-6 border-0' >
                       <option selected>Best Sellers</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   </div>
        
              

           </div> */}
         
          {/* <p className='pt-1 green-h-text fs-4'>Catagory</p>
                   <select class='form-select mb-2' aria-label='Default select example'>
                       <option selected>Tulshi infusion</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <select class='form-select mb-2' aria-label='Default select example'>
                       <option selected>Body Care</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <select class='form-select mb-2' aria-label='Default select example'>
                       <option selected>Detox</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <select class='form-select mb-2' aria-label='Default select example'>
                       <option selected>Herbal Formulations</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <select class='form-select' aria-label='Default select example'>
                       <option selected>Packeged Food</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <hr />
                   <select class='form-select' aria-label='Default select example'>
                       <option selected>Herbl</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <hr />
                   <select class='form-select' aria-label='Default select example'>
                       <option selected>Health</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select>
                   <hr />
                   <select class='form-select' aria-label='Default select example'>
                       <option selected>Health Sellars</option>
                       <option value='1'>One</option>
                       <option value='2'>Two</option>
                       <option value='3'>Three</option>
                   </select> */}
               </div>
               <div class='col-12 col-md-10 col-lg-9'>
                  
               <header>
                       <div className='row'>
                           <div className='col-md-12'>
                               <div className='container'>
                               <div className='row'>
                                   <div className='col-md-8 col-12'>
                                   <p className='fs-18 mt-2'>All products</p>
                                   </div>
                                   <div className='col-md-4 col-12'>
                                   <div class='d-flex align-items-center'>
                       <h6 className='mt-2 col-5  f-HelveticaNeue-Light'>    SORT BY</h6>
                           <select class='form-select w-auto  col-12 pb-3 pt-3  fs-16 f-HelveticaNeue-Ligh ' aria-label='Default select example'>
                               <option selected>Popularty</option>
                               <option value='1'>One</option>
                               <option value='2'>Two</option>
                               <option value='3'>Three</option>
                           </select>
                          
                       </div>
                                   </div>
                                   {/* <div className='hrrr mt-2'></div> */}
                               </div>
                               </div>
                           </div>
                       </div>
                   </header>
                  <div className='.b border mt-2 mb-2'>
                  <section style={{ borderTop: 'solid 3px #b39659' }}></section>
                      
                  </div>
                
                   
                   {/* <header class='d-flex justify-content-between align-items-center'>
                       <h6>All products</h6>
                       <div class='d-flex align-items-center'>
                           sort by
                           <select class='form-select w-auto ms-4' aria-label='Default select example'>
                               <option selected>Filter by</option>
                               <option value='1'>One</option>
                               <option value='2'>Two</option>
                               <option value='3'>Three</option>
                           </select>
                       </div>
                   </header> */}
                   {/* {isLoading ? (
                       <Loading className='w-100 center h-md' />
                   ) : (
                       <div>
                           <main class='mt-5' ref={productsSection}>
                               <div class='row'>
                                   {products.length >= 1 &&
                                       products.map((item) => {
                                           return <ProductCard item={item} />;
                                       })}
                               </div>
                           </main>
                           <div className='center mt-7'>
                               <nav aria-label='Page navigation example'>
                                   <ul class='pagination'>
                                       <li class='page-item cursor' onClick={prevPage}>
                                           <p class='page-link'>Previous</p>
                                       </li>
                                       <li class='page-item cursor' onClick={nextPage}>
                                           <p class='page-link px-4'>Next</p>
                                       </li>
                                   </ul>
                               </nav>
                           </div>
                       </div>
                   )} */}



                   <div className='row'>
                       <div className='col-md-3'>
                           <div className='box'>
                           <img src="assets/imgs/allherbs/saffron.jpg" alt="" />
                           <div className='content'>
                               <p>rahul</p>
                               <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex adipisci exercitationem rerum et repellat explicabo! Explicabo dolores consectetur dolore aut!</h1>
                           </div>
                           </div>
                       </div>
                       <div className='col-md-3'></div>
                       <div className='col-md-3'></div>
                       <div className='col-md-3'></div>
                       
                   </div>
               </div>
           </section>
       </div>
    </div>
    </div>
	);
};

export default NewLauncher;




import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import API from "../../api";
import Loading from "../Loading";
const Manu = () => {
  const [loading, SetLoading] = useState(true);
  const [shopBycat, setShopByCat] = useState([]);
  const [offer, setOffer] = useState([]);
  const [id, setid] = useState("");
  const shopByCategory = () => {
    SetLoading(true);
    let request = `get_menu`;
    API.get(request)
      .then((data) => {
        setShopByCat(data.data.data);
        setOffer(data.data.offer);
        SetLoading(false);
      })
      .catch((err) => {
        SetLoading(false);
      });
  };
  useEffect(() => {
    shopByCategory();
    console.log(shopBycat, "shopBycat");
  }, []);

  return (
    <div className="container ">
      <div className="row">
        <div className="col-md-2 col-6">
          <ul class="nav container  ">
            <li class="nav-item dropdown ">
              <button
                class="nav-link navhide fs-18 font-bold py-6px px-3 mt-2 me-4 dropdown-toggle active green-h border-none text-white"
                data-bs-toggle="dropdown"
                href="#"
                role="button"
                aria-expanded="false"
                data-bs-auto-close="outside"
              >
                Shop by Category
              </button>
              <ul class="dropdown-menu p-0 vw-100 container position-absolute shadow">
                <nav className=" h-100">
                  <ul className="list li active overflow-auto   h-180" id="style-2">
                    {shopBycat.length > 0 &&
                      shopBycat.map((key, index) => (
                        <Link to={`/productpage/:cat=${key.id}`}>
                          <li className="hover-background w-20 menu-responsive-w">
                            {" "}
                            <a className="" href="#">
                              {key.title}
                            </a>
                            {/* <!-- First Tier Drop Down --> */}
                            <ul>
                              {key.sub_cateory.length > 0 &&
                                key.sub_cateory.map((item, index) => (
                                  <Link to={`/productpage/:subid=${item.id}`}>
                                    <li className="hover-background">
                                      <a className="hover-background" href="#">
                                        {item.sub_category_title}
                                      </a>

                                      <ul>
                                        {item.product.length > 0 &&
                                          item.product.map((data, index) => (
                                            <li className="hover-background">
                                              <a
                                                className="hover-background"
                                                href="#"
                                              >
                                                {data.product_name}
                                              </a>
                                              <ul>
                                                <li>
                                                  <div className="row w-100">
                                                    <div className="col-md-6 img_fit1">
                                                      <div className="">
                                                        <p class="text-uppercase ls-4  ms-5 ps-4 w-100 text-dark-green text-center mt-3 mb-3 f-0-7 title-wrap ul-t">
                                                          {data.product_name}
                                                        </p>

                                                        <Link
                                                          to={`/productcart/:${data.product_slug}`}
                                                        >
                                                          {" "}
                                                          <img
                                                            src={data.img_url}
                                                            class="position-absolute img_fit "
                                                            data-box-shadow="0px 8px 6px -6px #d3cdcd"
                                                          />
                                                        </Link>
                                                      </div>
                                                    </div>
                                                    {offer.length > 0 &&
                                                      offer.map(
                                                        (item, index) => (
                                                          <div className="col-md-6 img_fit1 ">
                                                            <div className="">
                                                              <p class="text-uppercase ls-4  ms-3 ps-4 w-100 text-dark-green text-center mt-3 mb-3 f-0-7 title-wrap ul-t">
                                                                {
                                                                  item.offer_title
                                                                }
                                                              </p>

                                                              <Link
                                                                to={`/offer`}
                                                              >
                                                                {" "}
                                                                <img
                                                                  src={
                                                                    item.offer_image
                                                                  }
                                                                  class="position-absolute img_fit"
                                                                  data-box-shadow="0px 8px 6px -6px #d3cdcd"
                                                                />
                                                              </Link>
                                                            </div>
                                                          </div>
                                                        )
                                                      )}
                                                  </div>
                                                </li>
                                              </ul>
                                            </li>
                                          ))}
                                      </ul>
                                    </li>
                                  </Link>
                                ))}
                            </ul>
                          </li>
                        </Link>
                      ))}
                  </ul>
                </nav>
              </ul>
            </li>
          </ul>
        </div>

        <div className="col-md-10 col-6 ">
          {/* <ul  className=' btn-show list-group navbar-collapse mt-md-1 justify-content-between    '
						id='navbarSupportedContent'>
  <li class="list-group-item  "><Link
						
						className='nav-link navv fs-20 py-6px px-2 me-4 '
						aria-current='page'
						to='/offerpage'
					>
						Offers
					</Link>
					</li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/popular_product'>
			
			Popular Products
		</Link></li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/newlauncher'>
					
					New Launches
				</Link></li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/PRODUCTSPAGE'>
				
				Best Sellers
			</Link></li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/newlauncher'>
				
				Deal of the Week
			</Link></li>
</ul> */}

          <ul class="nav container rahul navhide    ">
            <li class="nav-item pt-3 ">
              <Link
                className="nav-link navv fs-15 py-6px px-2  ms-6 "
                aria-current="page"
                to="/offer"
              >
                Offers
              </Link>
            </li>

            <li class="nav-item pt-3  ">
              <Link
                className="nav-link fs-15 py-6px px-2 me-3 navv"
                to="/popular_product"
              >
                Popular Products
              </Link>
            </li>

            <li class="nav-item pt-3">
              <Link
                className="nav-link fs-15 py-6px px-2 me-3 navv"
                to="/newlauncher"
              >
                New Launches
              </Link>
            </li>

            <li class="nav-item pt-3">
              <Link
                className="nav-link fs-15 py-6px px-2  navv"
                to="/best_sellers"
              >
                Best Sellers
              </Link>
            </li>

            <li class="nav-item pt-3">
              <Link
                className="nav-link fs-15 py-6px px-2  navv"
                to="/combo_store"
              >
                Combo Store
              </Link>
            </li>

            <li class="nav-item pt-3">
              <Link className="nav-link fs-15 py-6px px-2  navv" to="/deal">
                Deal of the Week
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Manu;

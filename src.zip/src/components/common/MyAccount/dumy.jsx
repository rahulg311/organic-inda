import React, { Component } from 'react';
import PropTypes from 'prop-types';

class dumy extends Component {
    constructor(props) {
        super(props);

    }

    componentWillMount() {

    }

    componentDidMount() {

    }

    componentWillReceiveProps(nextProps) {

    }

    shouldComponentUpdate(nextProps, nextState) {

    }

    componentWillUpdate(nextProps, nextState) {

    }

    componentDidUpdate(prevProps, prevState) {

    }

    componentWillUnmount() {

    }

    render() {
        return (
            <div>


<div id="container">
  <nav>
    <ul>
    
      <li><a href="#">Web Design</a>
        {/* <!-- First Tier Drop Down --> */}
        <ul>
          <li><a href="#">Resources</a></li>
          <li><a href="#">Links</a></li>
          <li><a href="#">Tutorials</a>
            {/* <!-- Second Tier Drop Down --> */}
            <ul>
              <li><a href="#">HTML/CSS</a></li>
              <li><a href="#">jQuery</a></li>
              <li><a href="#">Other</a>
                {/* <!-- Third Tier Drop Down --> */}
                <ul>
                  <li><a href="#">Stuff</a></li>
                  <li><a href="#">Things</a></li>
                  <li><a href="#">Other Stuff</a></li>
                </ul>
              </li>
            </ul>
          </li>
        </ul>
      </li>
     
    </ul>
  </nav>
  <h1>Pure CSS Drop Down Menu</h1>
  <p> A simple dropdown navigation menu made with CSS Only. Dropdowns are marked with a plus sign ( + )</p>
</div>

            </div>
        );
    }
}

dumy.propTypes = {

};

export default dumy;
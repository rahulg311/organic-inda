<div className=' '>
				
				
				<ul class='nav container '>
					<li class='nav-item dropdown '>
						<button
							class='nav-link fs-18 font-bold py-6px px-3 mt-2 me-4 dropdown-toggle active green-h border-none text-white'
							data-bs-toggle='dropdown'
							href='#'
							role='button'
							aria-expanded='false'
							data-bs-auto-close='outside'
						>
							Shop by Category
						</button>
						<ul class='dropdown-menu vw-100 container position-absolute shadow'>
							<section class='row gy-5'>
								<div class='col-md-3  border-end'>
									<ul class='list-group'>
										<li class='list-group-item border-0'>TULSI TEASE & INFUISIONS</li>
										
										<li class='list-group-item border-0'>HERBAL FORMULATIONS</li>
										<li class='list-group-item border-0'>DETOX</li>
										<li class='list-group-item border-0'>PACKAGED FOOD</li>
										<li class='list-group-item border-0'>BODY CARE</li>
									</ul>
								</div>
								<div class='col-md-2 border-end'>
									<ul class='list-group'>
										<li class='list-group-item border-0'>An item</li>
										<li class='list-group-item border-0'>A second item</li>
										<li class='list-group-item border-0'>A third item</li>
										<li class='list-group-item border-0'>A fourth item</li>
										<li class='list-group-item border-0'>And a fifth one</li>
									</ul>
								</div>
								<div class='col-md-2  border-end'>
									<ul class='list-group'>
										<li class='list-group-item border-0'>An item</li>
										<li class='list-group-item border-0'>A second item</li>
										<li class='list-group-item border-0'>A third item</li>
										<li class='list-group-item border-0'>A fourth item</li>
										<li class='list-group-item border-0'>And a fifth one</li>
									</ul>
								</div>
								<div class='col-md-3 '>
									<img src='/assets/imgs/best-selling/1.png' alt='' className='w-100' />
								</div>
								<div class='col-3'></div>
							</section>
						</ul>
					</li>
				
					
				
					<li class='nav-item pt-2 ms-7'>
						<Link
						
							className='nav-link navv fs-20 py-6px px-2 me-4 '
							aria-current='page'
							to='/popular_product'
						>
							Offers
						</Link>
						
					</li>

					<li class='nav-item pt-2  '>
						<Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/productcategory'>
			
							Popular Products
						</Link>
					</li>

					<li class='nav-item pt-2'>
						<Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/herbs'>
					
							New Launches
						</Link>
					</li>

					<li class='nav-item pt-2'>
						<Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/best_sellers'>
				
							Best Sellers
						</Link>
					</li>

				
					<li class='nav-item pt-2'>
						<Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/combo_store'>
				
						Combo Store
						</Link>
					</li>

					<li class='nav-item pt-2'>
						<Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/deal'>
				
							Deal of the Week
						</Link>
					</li>

					

					

				</ul>
			</div>
import React, { useEffect, useState } from 'react'
import useAuth from '../../hooks/useAuth';
import { Link } from 'react-router-dom'
import { Badge } from '@material-ui/core';
// import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';

const TopNave = ({ }) => {
	const { user, userToken, userId, isLoading, doLogin, doLogout } = useAuth();
	const [showicon, setShowicon] = useState(false);
	const [checked, setchecked] = useState(false);
	const [totalItems, setTotalItems] = React.useState(0);
	const [cart, setCart] = React.useState(JSON.parse(localStorage.getItem("cart")));
	const handleChecked = () => {
		setchecked(!checked)
		console.log(checked)

	}
	const calculateTotalItems = () => {
		let totalItems = 0;
		cart?.forEach((item) => {
			totalItems += item.quantity;
		});
		setTotalItems(totalItems);

	};



	useEffect(() => {

		calculateTotalItems();

	}, [cart]);
	return (
		<div class='green-h py-2 position-fixed w-100 top-0 ' style={{ zIndex: '999' }}>
			<div class='container d-flex  justify-content-end text-white '>
				<div className="hamburger_Menu  ">
					<div className="menuToggle_Menu  ">
						<input type="checkbox"
							checked={checked}
							onClick={handleChecked}
						/>

						<span onClick={handleChecked}></span>
						<span onClick={handleChecked}></span>
						<span onClick={handleChecked}></span>

						<ul className="menu_Menu">
							<Link to="/shopbycategory" className="active">

								<li
									onClick={handleChecked}
								>Shop by Category</li>

							</Link>
							<Link to="/offer" className="active">

								<li onClick={handleChecked}>Offer</li>
							</Link>
							<Link to="/popular_product" className="active">

								<li onClick={handleChecked}>Popular Products</li>
							</Link>
							<Link to="/newlauncher" className="active">

								<li onClick={handleChecked}> New Launches</li>
							</Link>
							<Link to="/best_sellers" className="active">

								<li onClick={handleChecked}> Best Sellers</li>
							</Link>
							<Link to="/combo_store" className="active">

								<li onClick={handleChecked}> Combo Store</li>
							</Link>
							<Link to="/deal" className="active">

								<li onClick={handleChecked}>Deal of the Week</li>
							</Link>










						</ul>
					</div>
				</div>

				<div class='d-flex me-5'>
					<i class='fab btn p-0 text-white fa-instagram fs-6 me-4'></i>
					<i class='fab btn p-0 text-white fa-facebook fs-6 me-4'></i>
					<i class='fab btn p-0 text-white fa-twitter fs-6 me-4'></i>
					<i class='fab btn p-0 text-white fa-linkedin fs-6 me-4'></i>
				</div>
				<div class='d-flex '>
					<i class='fas text-white fa-map-marker-alt btn p-0 fs-6 me-3'></i>

					{/* <Link to='/carts'>
					<Badge badgeContent={totalItems} color="error">
						<ShoppingCartIcon style={{color:"white", marginTop:"4px", height:"22px"}} />
						</Badge>
					</Link> */}
				</div>
				{userToken ? (
					<div class='d-flex align-items-center ms-3 '>
						<i class='fas text-white fa-comment-dots btn p-0 fs-6 me-3'></i>

						<div class='dropdown'>
							<button
								class='btn p-0 fs-6 text-white'
								type='button'
								id='dropdownMenuButton1'
								data-bs-toggle='dropdown'
								aria-expanded='false'
							>
								<i class='fas fa-user-alt'></i>
							</button>
							<ul class='dropdown-menu pb-0' aria-labelledby='dropdownMenuButton1'>
								<li>
									<Link class='dropdown-item ' to={`/myaccount`}>
										{user.user_full_name}
									</Link>
								</li>
								<li>
									<p
										class='dropdown-item mb-6px cursor'
										onClick={() => {
											doLogout();
										}}
									>
										Logout
									</p>
								</li>
							</ul>
						</div>
					</div>
				) : (
					<Link to='/login' class='btn px-3 py-1 center fs-12 btn-outline-light ms-4'>
						Login
					</Link>
				)}
			</div>
		</div>
	);
}

export default TopNave
{/* <div>
<button
	className='navbar-toggler  btn-show  '
	type='button'
	data-bs-toggle='collapse'
	data-bs-target='#navbarSupportedContent'
	aria-controls='navbarSupportedContent'
	aria-expanded='false'
	aria-label='Toggle navigation'
>
	<i class="fas fa-bars" onClick={(e) => setShowicon(!showicon)}></i>
</button>
{showicon == true && <>
<h1>rahul</h1>
	<ul className='ul-margin-left' >
		<li class="list-group-item  "><Link

			className='nav-link navv fs-20 py-6px px-2 me-4 '
			aria-current='page'
			to='/offer'
		>
			Offer
		</Link>
		</li>
		<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/popular_product'>

			Popular Products
		</Link></li>
		<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/newlauncher'>

			New Launches
		</Link></li>
		<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/best_sellers'>

			Best Sellers
		</Link></li>
		<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/combo_store'>

			Combo Store
		</Link></li>
		<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2  navv  ' to='/deal'>

			Deal of the Week
		</Link></li>
	</ul>

</>

}
</div> */}
import React from 'react'
import { useState } from 'react';
import { Link } from 'react-router-dom'
const Manu = () => {
	const [showicon, setShowicon] = useState(false);
	return (
		<div className='container '>
			<div className='row'>
				<div className='col-md-2 col-6'>
					<ul class='nav container  '>
						<li class='nav-item dropdown '>
							<button
								class='nav-link fs-18 font-bold py-6px px-3 mt-2 me-4 dropdown-toggle active green-h border-none text-white'
								data-bs-toggle='dropdown'
								href='#'
								role='button'
								aria-expanded='false'
								data-bs-auto-close='outside'
							>
								Shop by Category
							</button>
							<ul class='dropdown-menu vw-100 container position-absolute shadow'>
								{/* <section class='row gy-5'>
								<div class='col-md-3  border-end'>
									<ul class='list-group'>
										<li class='list-group-item border-0'>TULSI TEASE & INFUISIONS</li>
										
										<li class='list-group-item border-0'>HERBAL FORMULATIONS</li>
										<li class='list-group-item border-0'>DETOX</li>
										<li class='list-group-item border-0'>PACKAGED FOOD</li>
										<li class='list-group-item border-0'>BODY CARE</li>
									</ul>
								</div>
								<div class='col-md-2 border-end'>
									<ul class='list-group'>
										<li class='list-group-item border-0'>An item</li>
										<li class='list-group-item border-0'>A second item</li>
										<li class='list-group-item border-0'>A third item</li>
										<li class='list-group-item border-0'>A fourth item</li>
										<li class='list-group-item border-0'>And a fifth one</li>
									</ul>
								</div>
								<div class='col-md-2  border-end'>
									<ul class='list-group'>
										<li class='list-group-item border-0'>An item</li>
										<li class='list-group-item border-0'>A second item</li>
										<li class='list-group-item border-0'>A third item</li>
										<li class='list-group-item border-0'>A fourth item</li>
										<li class='list-group-item border-0'>And a fifth one</li>
									</ul>
								</div>
								<div class='col-md-3 '>
									<img src='/assets/imgs/best-selling/1.png' alt='' className='w-100' />
								</div>
								<div class='col-3'></div>
							</section> */}

								{/* <nav>
    <ul>
	
								
									<ul class='list-group'>
										<li class='list-group-item border-0'>TULSI TEASE & INFUISIONS
										<ul>
          
		  <li><a className='hover-background' href="#">Other</a>
			
			<ul>
			  <li><a className='hover-background' href="#">Stuff</a>
			  <ul>
				  <li><a className='hover-background' href="#">Things</a></li>
			  <li><a className='hover-background' href="#">Other Stuff</a></li>
			  </ul>
			  </li>
			  <li><a className='hover-background' href="#">Things</a></li>
			  <li><a className='hover-background' href="#">Other Stuff</a></li>
			</ul>
		  </li>
		</ul></li>
										
										<li class='list-group-item border-0'>HERBAL FORMULATIONS</li>
										<li class='list-group-item border-0'>DETOX</li>
										<li class='list-group-item border-0'>PACKAGED FOOD</li>
										<li class='list-group-item border-0'>BODY CARE</li>
									</ul>
								
							
     
     
    </ul>
  </nav> */}








								<nav>
									<ul>

										<li><a className='hover-background' href="#">TULSI TEASE & INFUISIONS</a>

											{/* <!-- First Tier Drop Down --> */}
											<ul>
												<li><a className='hover-background' className='hover-background' href="#">Wellness Infusion</a>
													<ul>
														<li><a className='hover-background' href="#">Tulsi Cleanse 25 Tea Bags</a>
															<ul>
																<li><div className='row w-100'>
																	<div className='col-md-6'>
																		<img className='w-100 h-100 pt-5' src="/assets/imgs/Product111.png" alt="" />
																	</div>
																	<div className='col-md-6'>
																		<img className='w-100 h-100 pt-5' src="/assets/imgs/s4.png" alt="" />
																	</div>
																</div></li>

															</ul>
														</li>
														<li><a className='hover-background' href="#">Tulsi Lax 25 Tea Bags</a></li>
														<li><a className='hover-background' href="#">Tulsi Sleep 25 Tea Bags</a></li>
													</ul>

												</li>
												<li><a className='hover-background' href="#">Tulsi Green Teas</a></li>
												<li><a className='hover-background' href="#">Tulsi Infusion</a>
													{/* <!-- Second Tier Drop Down --> */}
													<ul>
														<li><a className='hover-background' href="#">HTML/CSS</a></li>
														<li><a className='hover-background' href="#">jQuery</a></li>
														<li><a className='hover-background' href="#">Other</a>
															{/* <!-- Third Tier Drop Down --> */}
															<ul>
																<li><a className='hover-background' href="#">Stuff</a></li>
																<li><a className='hover-background' href="#">Things</a></li>
																<li><a className='hover-background' href="#">Other Stuff</a></li>
															</ul>
														</li>
													</ul>
												</li>
												<li><a className='hover-background' href="#">Speciality Tea</a></li>
												<li><a className='hover-background' href="#">All</a></li>
											</ul>
										</li>
										<li><a className='hover-background' className='hover-background' href="#">HERBAL FORMULATIONS</a></li>
										<li><a className='hover-background' href="#">DETOX</a></li>
										<li><a className='hover-background' href="#">PACKAGED FOOD</a>

										</li>
										<li><a className='hover-background' href="#">BODY CARE</a></li>

									</ul>
								</nav>















							</ul>
						</li>
					</ul>

				</div>

				<div className='col-md-10 col-6 '>
					<button
						className='navbar-toggler  btn-show ms-10 mt-2 '
						type='button'
						data-bs-toggle='collapse'
						data-bs-target='#navbarSupportedContent'
						aria-controls='navbarSupportedContent'
						aria-expanded='false'
						aria-label='Toggle navigation'
					>
						<i class="fas fa-bars" onClick={(e) => setShowicon(!showicon)}></i>
					</button>
					{showicon == true && <>
						<ul className='ul-margin-left' >
							<li class="list-group-item  "><Link

								className='nav-link navv fs-20 py-6px px-2 me-4 '
								aria-current='page'
								to='/offer'
							>
								Offers
							</Link>
							</li>
							<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/popular_product'>

								Popular Products
							</Link></li>
							<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/newlauncher'>

								New Launches
							</Link></li>
							<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/best_sellers'>

								Best Sellers
							</Link></li>
							<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/combo_store'>

								Combo Store
							</Link></li>
							<li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2  navv  ' to='/deal'>

								Deal of the Week
							</Link></li>
						</ul>

					</>

					}
					{/* <ul  className=' btn-show list-group navbar-collapse mt-md-1 justify-content-between    '
						id='navbarSupportedContent'>
  <li class="list-group-item  "><Link
						
						className='nav-link navv fs-20 py-6px px-2 me-4 '
						aria-current='page'
						to='/offerpage'
					>
						Offers
					</Link>
					</li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/popular_product'>
			
			Popular Products
		</Link></li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-5 navv' to='/newlauncher'>
					
					New Launches
				</Link></li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/PRODUCTSPAGE'>
				
				Best Sellers
			</Link></li>
  <li class="list-group-item"><Link className='nav-link fs-20 py-6px px-2 me-4 navv' to='/newlauncher'>
				
				Deal of the Week
			</Link></li>
</ul> */}

					<ul class='nav container rahul navhide    '
					>
						<li class='nav-item pt-2 '>

							<Link

								className='nav-link navv fs-12 py-6px  ms-3 '
								aria-current='page'
								to='/offer'
							>
								Offers
							</Link>

						</li>

						<li class='nav-item pt-2  '>
							<Link className='nav-link fs-15 py-6px px-2 me-3 navv' to='/popular_product'>

								Popular Products
							</Link>
						</li>

						<li class='nav-item pt-2'>
							<Link className='nav-link fs-15 py-6px px-2 me-3 navv' to='/newlauncher'>

								New Launches
							</Link>
						</li>

						<li class='nav-item pt-2'>
							<Link className='nav-link fs-15 py-6px px-2  navv' to='/best_sellers'>

								Best Sellers
							</Link>
						</li>


						<li class='nav-item pt-2'>
							<Link className='nav-link fs-15 py-6px px-2  navv' to='/combo_store'>

								Combo Store
							</Link>
						</li>

						<li class='nav-item pt-2'>
							<Link className='nav-link fs-15 py-6px px-2  navv' to='/deal'>

								Deal of the Week
							</Link>
						</li>





					</ul>


				</div>
			</div>



		</div>
	);
}

export default Manu
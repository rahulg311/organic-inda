import React from 'react'

const Banner = (props) => {
	console.log(props.slider, "slider")

	return (
		<div className='border  border-3 border-success'>

			<div id='carouselExampleControls' class='carousel slide' data-bs-ride='carousel'>
				<div class='carousel-inner'>
					{
						props.slider.map((item, index) => (

							index+1 == item.banner_id ?
							<div class='carousel-item active '>
								<img src={item.banner_image} class='d-block w-100' alt={index} />
							</div>
							:
							<div class='carousel-item'>
								<img src={item.banner_image} class='d-block w-100' alt={index} />
							</div>

						))
					}


				</div>
				<button
					class='carousel-control-prev'
					type='button'
					data-bs-target='#carouselExampleControls'
					data-bs-slide='prev'
				>
					<span class='carousel-control-prev-icon' aria-hidden='true'></span>
					<span class='visually-hidden'>Previous</span>
				</button>
				<button
					class='carousel-control-next'
					type='button'
					data-bs-target='#carouselExampleControls'
					data-bs-slide='next'
				>
					<span class='carousel-control-next-icon' aria-hidden='true'></span>
					<span class='visually-hidden'>Next</span>
				</button>
			</div>
		</div>
	);
}

export default Banner

import React from 'react';
import Loading from '../Loading';
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';
import { Link } from 'react-router-dom';

import BlogCard from '../blog/BlogCard';

const Blogs = (props) => {

	return (
		<section

		>

			<div className='container mt-5 mb-7'>
				<div className='row'>
					<div className='col-md-6 '>
						<div className=' row mb-5'>
							<div className='col-md-12'>
								<Link to={`/blog/${props.blog[0].blog_slug}`}><img src={props.blog[0].blog_image} alt="" className='w-100 border h-300  img-fluid' /></Link>

								<h6 className=' mt-4 text-success f-HelveticaNeue-Light fw-bold fs-14'> {props.blog[0].date}</h6>
								<Link to={`/blog/${props.blog[0].blog_slug}`}><h1 className=' fw-bold f-MinionPro-Regular fs-17 p-0 m-0 '>{props.blog[0].blog_title}</h1></Link>
								<div  className='text-muted f-HelveticaNeue-Light f-1 pt-1'  dangerouslySetInnerHTML={{ __html: props.blog[0].blog_description }}>
								</div>
								<Link to={`/blog/${props.blog[0].blog_slug}`}><button style={{ border: 0, background: "0" }}> <span className='text-success fs-16 ' style={{ fontWeight: "bold" }}>...Read More</span></button></Link>


							</div>




						</div>


					</div>

					<div className='col-md-6'>
					
						<div className='row'>

							<div className='col-md-6 '>
								<Link to={`/blog/${props.blog[1].blog_slug}`}><img className='w-100 ' src={props.blog[1].blog_image} /></Link>
							</div>
							<div className='col-md-6 '>
								<h6 className=' text-success f-HelveticaNeue-Light fw-bold fs-14'> {props.blog[1].date}</h6>
								<Link to={`/blog/${props.blog[1].blog_slug}`}><h5 className='fw-bold f-MinionPro-Regular fs-17 p-0 m-0 '>{props.blog[1].blog_title}</h5></Link>
								<div  className='text-muted f-HelveticaNeue-Light f-1 pt-1'  dangerouslySetInnerHTML={{ __html: props.blog[1].blog_description }}>
								</div>
								<Link to={`/blog/${props.blog[1].blog_slug}`}><button style={{ border: 0, background: "0" }}> <span className='text-success fs-16 ' style={{ fontWeight: "bold" }}>...Read More</span></button></Link>

							</div>
						</div>
						<div className='row mt-5 '>

							<div className='col-md-6  '>
								<Link to={`/blog/${props.blog[2].blog_slug}`}><img className='w-100' src={props.blog[1].blog_image} /></Link>
							</div>
							<div className='col-md-6 '>
								<h6 className=' text-success f-HelveticaNeue-Light fw-bold fs-14'> {props.blog[2].date}</h6>
								<Link to={`/blog/${props.blog[2].blog_slug}`}><h5 className='fw-bold f-MinionPro-Regular fs-17 p-0 m-0  '>{props.blog[2].blog_title}</h5></Link>
								<div  className='text-muted f-HelveticaNeue-Light f-1 pt-1'  dangerouslySetInnerHTML={{ __html: props.blog[2].blog_description }}>
								</div>
								<Link to={`/blog/${props.blog[2].blog_slug}`}><button style={{ border: 0, background: "0" }}> <span className='text-success fs-16 ' style={{ fontWeight: "bold" }}>...Read More</span></button></Link>

							</div>
						</div>

					</div>
				</div>
			</div>
		</section>
	);
};

export default Blogs;

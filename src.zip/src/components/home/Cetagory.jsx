import React from 'react'
import { Link } from "react-router-dom"

const Cetagory = (props) => {
	return (
		<div class=' ' >
			<header>
				<div className='text-center   '>

					<p className=' f-MinionPro-Regular font-responsive-f fs-1 latter-space  text-space text-success fw-bolder '>KNOW YOUR CATEGORY </p>
				</div>
				<div class=' ' >
					<div className=' hrrr'></div>
					<div className='hrr hrrr'></div>
					<div className='text-center'>
						<img src='/assets/imgs/media/1.svg' alt='' className='w-80px' />
					</div>
					<div className='row  background_pro'
					//  style={{
					// 	backgroundImage: "url('assets/imgs/catagury.png')", backgroundRepeat: " no-repeat",
					// 	backgroundSize: "100% 100%"
					// }}
					>
						<div className='col-md-12 mb-4'>
							<div className='container mt-4 w-70 menu-responsive-w '>
								<section class='row '>
									{
										props.category && props.category.map((item, index) => (
											<div class='col-12 col-md-6 col-lg-4 mb-5 '>

												<Link to={`/productpage/:cat=${item.category_id}`}>	<img
													src={item.category_image}
													class='w-100 rounded-3'
													alt=''
												/></Link>
												<div class='text-center mt-5'>
													<Link to={`/productpage/:cat=${item.category_id}`} className='btn f-MinionPro-Regular fs-14 btn-warr text-white  pt-2 '>
														SHOP NOW
													</Link>
												</div>
											</div>

										))
									}

								</section>
							</div>
						</div>
					</div>

				</div>
			</header>
		</div>
	);
}

export default Cetagory

import React from 'react'
import { Link } from 'react-router-dom';

const Herbs = (props) => {
    return (
			<section className='mt-5 '  >
				
		
				<p className='  font-responsive-1 mx-auto text-center f-whitney-boldd green-h-textt f-2-1'>
					"If there is peace in your mind, you will <br /> find peace with everybody. " - HL POONJA
				</p>
				<div className='text-center mt-0 pt-0' >
							<img src='/assets/imgs/bor.png' alt='' className='w-35 menu-responsive-90 ' />
						</div>
				<div className='bg-success mt-5 text-center text-white py-1 '  style={{ backgroundImage: "url('assets/imgs/hr.png')"}}>
					<h4 className='f-MinionPro-Regular  f-1-8 latter-space  text-space text-white pt-4 fw-bolder font-responsive-f' >KNOW YOUR HERBS</h4>
				</div>
				<div className='text-center'>
							<img src='/assets/imgs/media/1.svg' alt='' className='w-80px' />
						</div>
				
				<div className='mt-8 container' >
					<p className='w-md-50 mx-auto text-center  fs-14 text-muted f-HelveticaNeue-Roman'>
					ORGANIC INDIA products are made from a carefully curated selection of herbs cultivated by our organic farmer partners in India. All ORGANIC INDIA herbs are grown using ancient Ayurvedic bio-regenerative methods to maximize efficacy. Learn about each herb’s characteristics and the associated traditional Ayurvedic lore by exploring our herb pages.
					</p>
				</div>
				

				<main className='container mt-4 d-flex justify-content-center' >
				<div className="row w-90 " >
					{
						props.herb&& props.herb.map((item, index)=>(
							<div className="col-md-3 col-6 mb-3">
                            <img className="w-100 " src={item.herb_image} alt="1" />
               
                            </div>

						))
					}
				
                          
                        </div>
				</main>
				
				<div className='center my-4 pb-5'>
					 	<Link to='/herbs' className='text-white '>
						 <button className='btn px-6 pt-3 btn-warr  rounded-4 text-white f-MinionPro-Regular fs-13'>
					VIEW ALL
					</button>		</Link>
				</div>
				<div className=' text-white py-6   ' style={{ backgroundImage: "url('assets/imgs/hr.png')"}}>
					
				
				
				</div>
				<div className='b'></div>
				<div className=''></div>
			</section>
		);
}

export default Herbs

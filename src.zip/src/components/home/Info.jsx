import React from 'react'

const Info = () => {
	return (

		<>
			<div className='p-5  py-7  rounded-3  bg-opacity-10'  style={{ backgroundImage: "url('assets/imgs/info.png')"}}>
				<section className='row gy-7 '>
				<div className='col-md-6 col-12 '>
						{/* <video className='w-100 rounded-3 b' controls muted autoplay>
							<source src='https://www.youtube.com/embed/QB0e33xBekU' />
						</video> */}
						<iframe className="w-100 rounded-3 b" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" frameborder="0" height="315" src="https://www.youtube.com/embed/QB0e33xBekU" width="560"></iframe>
					</div>
					{/* <div className='col-md-6 col-12 text-center d-flex flex-column align-items-center justify-content-center'>
						<h1 className='text-success'>HEALTY CONSIOUS LIVING</h1>
						<p className='mt-4 w-90'>
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, alias! Voluptatum,
							explicabo aspernatur officiis possimus, est facilis non architecto aliquid quas
							commodi quibusdam consequatur corporis minus, dolores eveniet eligendi iure?s
						</p>
					</div> */}
					<div className='col-md-6 col-12 d-flex align-items-center justify-content-center'>
						<div className='col-md-8 col-12'>
						<p className='green-h-textt f-MinionPro-Regular fs-25 fw-bold font-responsive-20  '>HEALTHY CONSCIOUS LIVING</p>
						<p className='mt-5 f-HelveticaNeue-Light fs-13 '>
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, alias! Voluptatum,
							explicabo aspernatur officiis possimus, est facilis non architecto aliquid quas
							commodi quibusdam consequatur corporis minus, dolores eveniet eligendi iure?s
						</p>
						</div>

					</div>

				</section>

			</div>
			<div className='b'></div>
		</>
	);
}

export default Info

import React from 'react';
import { Link } from 'react-router-dom';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import '@splidejs/splide/dist/css/themes/splide-skyblue.min.css';

const SellingProduct = ({ title }) => {
	return (
		<div class='  green-dark  text-white py-8'>
			<header>
				<div className='text-center mb-5 pb-3'>
					<p className='display-6  font-bold '>{title}</p>
				</div>
			</header>

			<div className='container w-75'>
				<Splide
					options={{
						rewind: true,
						gap: '8rem',
						perPage: 4,
						pagination: false,
						drag: false,
						perMove: 3,
						breakpoints: {
							1100: {
								perPage: 2,
							},
							680: {
								perPage: 1,
							},
						},
						classes: {
							arrows: '',
							arrow: `splide__arrow text-white `,
							prev: 'splide__arrow--prev your-class-prev p-2 ',
							next: 'splide__arrow--next   p-2 ',
						},
					}}
				>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/carts'>
								<img src='/assets/imgs/best-selling/1.png' class='rounded-3 ' alt='' />
							</Link>
							<Link to='/carts'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-15 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>

					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/carts'>
								<img src='/assets/imgs/best-selling/2.png' class='rounded-3 ' alt='' />
							</Link>
							<Link to='/carts'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-15 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
							
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/carts'>
								<img src='/assets/imgs/best-selling/3.png' class='rounded-3 ' alt='' />
							</Link>
							<Link to='/carts'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-15 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
							
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/carts'>
								<img src='/assets/imgs/best-selling/4.png' class='rounded-3 ' alt='' />
							</Link>
							<Link to='/carts'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-15 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/carts'>
								<img src='/assets/imgs/best-selling/2.png' class='rounded-3 ' alt='' />
							</Link>
							<Link to='/carts'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-15 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/carts'>
								<img src='/assets/imgs/best-selling/3.png' class='rounded-3 ' alt='' />
							</Link>
							<Link to='/carts'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-15 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>
				</Splide>
			</div>
		</div>
	);
};

export default SellingProduct;

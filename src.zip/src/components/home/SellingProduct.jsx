import React from 'react';
import { Link } from 'react-router-dom';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import '@splidejs/splide/dist/css/themes/splide-skyblue.min.css';

const SellingProduct = (props) => {
	return (
		<div class='  green-dark  text-white py-8'>
			<header>
				<div className='text-center mb-5 pb-3'>
					<p className='display-6  font-bold '>{props.title}</p>
				</div>
			</header>

			<div className='container w-80 '>
				<Splide
					options={{
						rewind: true,
						gap: '4rem',
						perPage: 4,
						pagination: false,
						drag: false,
						perMove: 3,
						breakpoints: {
							1100: {
								perPage: 2,
							},
							680: {
								perPage: 1,
							},
						},
						classes: {
							arrows: '',
							arrow: `splide__arrow text-white `,
							prev: 'splide__arrow--prev your-class-prev  ',
							next: 'splide__arrow--next    ',
						},
					}}
				>
					{
						props.best_selling_product && props.best_selling_product.map((item , index)=>(
							<SplideSlide>
						<div className='center flex-column'>
							<Link to={`/productcart/:${item.product_slug}`}>
								<img src={item.product_image} class='rounded-3 w-260 ' alt='' />
							</Link>
							<Link to={`/productcart/:${item.product_slug}`}>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>

						))
					}
					

					{/* <SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/2.png' class='rounded-3 w-260' alt='' />
							</Link>
							<Link to='/productcart'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
							
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/3.png' class='rounded-3 w-260 ' alt='' />
							</Link>
							<Link to='/productcart'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
							
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/4.png' class='rounded-3 w-260 ' alt='' />
							</Link>
							<Link to='/productcart'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/2.png' class='rounded-3 w-260 ' alt='' />
							</Link>
							<Link to='/productcart'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide>
					<SplideSlide>
						<div className='center flex-column w-100'>
							<Link to='/productcart'>
								<img src='/assets/imgs/best-selling/3.png' class='rounded-3 w-260 ' alt='' />
							</Link>
							<Link to='/productcart'>
							<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
							</Link>
						
						</div>
					</SplideSlide> */}
				</Splide>
			</div>
		</div>
	);
};

export default SellingProduct;

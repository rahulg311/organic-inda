/* Global Constants */
export const APP_Prefix = "organicindia59_";
export const APP_NAME = "Organic India";

export const paymentMode = {'Online': 1,'COD': 2,'Paypal': 3,'Bank Deposit': 4,'PrePaid': 5};
export const shippingMethod = {'Standard COD': 1,'Expedited COD': 2,'Standard Prepaid': 3,'Expedited Prepaid': 4,'Priority COD': 5,'Priority Prepaid': 6};

export const Email_Validation_Regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export const Mobile_Validation_Regex = /^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$/;
export const Password_Validation_Regex = /^[A-Za-z0-9$%_@#]{8,16}$/;
export const Password_Validation_Message = 'Password should be atleast 8 characters long contains only special characters $%_@#';
export const LettersOnly = /^[A-Za-z_ ]{1,}$/;
export const Numbers_Only_Regex = /^[0-9]{1,}$/;
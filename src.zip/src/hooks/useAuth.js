import React, { useEffect, useState } from 'react';

const useAuth = () => {
	const [userToken, setUserToken] = useState(null);
	const [user, setUser] = useState(null);
	const [userId, setUserId] = useState(null);
	const [isLoading, setLoading] = useState(false);

	const doLogin = (user, userToken, userId) => {
		setUserToken(userToken);
		setUserId(userId);
		setUser(user);

		localStorage.setItem('user', JSON.stringify(user));
		localStorage.setItem('userToken', userToken);
		localStorage.setItem('userId', userId);
	};

	const doLogout = () => {
		setUserToken(null);
		setUserId(null);
		setUser(null);

		localStorage.removeItem('user');
		localStorage.removeItem('userToken');
		localStorage.removeItem('userId');
		window.location.reload()
	};

	const getUserId=()=>{
		return localStorage.getItem('userId');
	}

	const getUserToken = () => {
		return localStorage.getItem('userToken');
	};

	const getUser= () => {
		return JSON.parse(localStorage.getItem('user'));
	}

	useEffect(() => {
		const localUserToken = localStorage.getItem('userToken');
		const localUserId = localStorage.getItem('userId');
		const localUser = JSON.parse(localStorage.getItem('user'));
		if (localUserToken && localUserId && localUser) {
			setUserToken(localUserToken);
			setUserId(localUserId);
			setUser(localUser);
		}
		setLoading(false);
	}, []);

	return {
		user,
		userToken,
		userId,
		isLoading,
		doLogin,
		doLogout,
		getUserToken,
		getUserId,
		getUser,
	};
};

export default useAuth;

import { useState, useEffect } from 'react';
import axios from 'axios';
import { END_POINT } from '../routes/paths';
import { notification } from '../utils/notification';

function useFetch(url) {
	const [data, setData] = useState(null);
	const [isLoading, setLoading] = useState(null);
	const [error, setError] = useState(null);
	
	useEffect(() => {
		setLoading(true);
		setData(null);
		setError(null);
		axios
			.get(END_POINT+url)
			.then((res) => res.data)
			.then((result) => {
				setLoading(false);
				setError(null);
				setData(result);
			})
			.catch((err) => {
				setLoading(false);
				setData(null);
				setError('An error occurred. Awkward..');
			});
	}, [url]);

	const doFetch = (url) => {
		setLoading(true);
		setData(null);
		setError(null);
		axios

			.get(END_POINT + url)
			.then((res) => res.data)
			.then((result) => {
				setLoading(false);
				setError(null);
				setData(result);
			})
			.catch((err) => {
				setLoading(false);
				setData(null);
				let notify = notification({
					type: 'error',
					message: 'Something went wrong',
				});
				notify();
			});
	};

	return { data, isLoading, error, doFetch };
}
export default useFetch;

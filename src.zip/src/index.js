import React, { Suspense } from 'react';

import ReactDOM from 'react-dom';
import { BrowserRouter as Router,} from 'react-router-dom';
import { Provider } from 'react-redux';
import App from './App';
import store from './store/';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import 'react-tabs/style/react-tabs.css';





import "./assets/scss/bootstrap.scss";
import "./assets/css/style.css";
import Loading from './components/Loading';

ReactDOM.render(
	<Suspense fallback={<Loading className="vw-100 vh-90 center"/>}>
		<Provider store={store}>
			<Router>
				<App />
			</Router>
		</Provider>
	</Suspense>,
	document.getElementById('root'),
);

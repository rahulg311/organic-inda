export const END_POINT = 'https://divashudh.com/api/';
export const products = '/products';
export const product = '/product/:id';
export const herbs = '/herbs';
export const login = '/login';
export const signup = '/signup';
export const blog = '/blog/:id';
export const blogs = '/blogs';
export const cart = '/cart';
export const carts = '/carts';
export const profile = '/profile';
export const edit_profile = '/edit-profile';
export const checkout = '/checkout';
export const thankyou = '/thankyou';
export const popular_product = '/popular_product';
export const payment = '/payment';  
export const myaccount = '/myaccount';
export const myaddress = '/myaddress';
export const myorder = '/myorder';
export const mywallet = '/mywallet';
export const productcategory = '/productcategory';
export const productpage = '/productpage';
export const offer = '/offer';
export const newlauncher = '/newlauncher';
export const productcart = '/productcart';
export const ourstory = '/ourstory';
export const aboutthecompany = '/aboutthecompany';
export const organic = '/organic';
export const contect = '/contect';
export const meetfarmers = '/meetfarmers';
export const consciousness = '/consciousness';
export const regenerative = '/regenerative';
export const wholeherb = '/wholeherb';
export const best_sellers='/best_sellers';
export const combo_store = '/combo_store';
export const  deal_of_the_week = '/deal';
export const faqs = '/faqs';
export const onlinethankyou='/onlinethankyou';
export const failed = '/failed';
export const shopbycategory = '/shopbycategory'















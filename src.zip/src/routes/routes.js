import { lazy } from 'react';
import Blog from '../views/pages/Blog/Blog';
import MyAddress from '../views/pages/MyAccount/MyAddress';
import MyOrder from '../views/pages/MyAccount/MyOrder';
import {
	
	products,
	payment,
	ourstory,
	shopbycategory,
	organic,
	contect,
	faqs,
	wholeherb,
	regenerative,
	meetfarmers,
	consciousness,
	aboutthecompany,
	popular_product,
	productcart,
	offer,
	newlauncher,
	best_sellers,
	deal_of_the_week,
	combo_store,
	productpage,
	productcategory,
	herbs,
	login,
	signup,
	blog,
	myaccount,
	myaddress,
	myorder,
	mywallet,
	blogs,
	cart,
	carts,
	profile,
	edit_profile,
	product,
	checkout,
	thankyou, 
	onlinethankyou,
	failed,
} from './paths';

export const AuthRoutes = [
	{
		path: login,
		title: 'Login',
		component: lazy(() => import('../views/auth/Login')),
	},
	{
		path: signup,
		title: 'Signup',
		component: lazy(() => import('../views/auth/SignUp')),
	},
];



export const DashboardRoutes = [
	{
		path: '/',
		title: 'Home',
		exact: true,
		component: lazy(() => import('../views/pages/home')),
	},
	{
		path: products,
		title: 'Products',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Products')),
	},
	{
		path: payment,
		title: 'Payment',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Payment')),
	},
	{
		path: offer,
		title: 'popular_product',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Offer')),
	},
	{
		
		path: faqs,
		title: 'Faqs',
		component: lazy(() => import('../views/pages/OurStory/Faqs')),
	},
	{
		path: productcart,
		title: 'Productcart',
		component: lazy(() => import('../views/pages/Productcart')),
	},
	{
		path: ourstory,
		title: 'OurStory',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/OurStory')),
	},
	{
		path: aboutthecompany,
		title: 'AbouttheCompany',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/AbouttheCompany')),
	},
	{
		path: organic,
		title: 'Organic',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/Organic')),
	},
	{
		path: meetfarmers,
		title: 'MeetFarmers',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/MeetFarmers')),
	},
	{
		path: consciousness,
		title: 'Consciousness',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/Consciousness')),
	},
	{
		path: 	regenerative,
		title:'Regenerative',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/Regenerative')),
	},
	{
		path: 	wholeherb,
		title:'Wholeherb',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/Wholeherb')),
	},
	

	{
		
		path: contect,
		title: 'Contect',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OurStory/Contect')),
	},
	
	
	{
		path: product,
		title: 'Products',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Product')),
	},
	{
		path: checkout,
		title: 'CHECKOUT',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Checkout')),
	},
	{
		path: thankyou,
		title: 'THANKYOU',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Thankyou')),
	},
	{
		path: onlinethankyou,
		title: 'onlinethankyou',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/OnlThankYou')),
	},
	{
		path: failed,
		title: 'failed',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Cancel')),
	},
	
	{
		path: herbs,
		title: 'Herbs',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Herbs')),
	},
	{
		path: blog,
		title: 'Blog',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Blog/Blog')),
	},
	{
		path: blogs,
		title: 'Blogs',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Blog/Blogs')),
	},
	{
		path: popular_product,
		title: 'popular_product',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/MenuLink/Papular_Product')),
	},
	{
		path: newlauncher,
		title: 'NewLauncher',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/MenuLink/NewLauncher')),
	},
		{
		path: myaccount,
		title: 'MyAcoount',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/MyAccount/MyAccount')),
	},

	{
		path: mywallet,
		title: 'MyWallet',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/MyAccount/MyWallet')),
	},
	{
		path: myorder,
		title: 'MyOrder',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/MyAccount/MyOrder')),
	},
	{
		path: myaddress,
		title: 'MyAddress',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/MyAccount/MyAddress')),
	},

	{
		path:carts,
		title: 'Carts',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Carts')),
	},
	{
		path: cart,
		title: 'Cart',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Cart')),
	},
	
	{
		path: profile,
		title: 'Cart',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/Profile')),
	},
	{
		path: edit_profile,
		title: 'Cart',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/EditProfile')),
	},
	{
		path: productcategory,
		title: 'productcategory',
		exact: true,
		strict:true,
		component: lazy(() => import('../views/pages/ProductCategory/ProductCategory')),
	},{
		path: best_sellers,
		title: 'best_sellers',
		component: lazy(() => import('../views/pages/BestSeller/BestSeller')),
	},
	{
		path: combo_store,
		title: 'combo_store',
		component: lazy(() => import('../views/pages/ComboStore/ComboStore')),
	},
	{
		path: deal_of_the_week,
		title: 'deal_of_the_week',
		exact:true,
		component: lazy(() => import('../views/pages/DealofWeek/Dealoftheweek')),
	},
	{
		path: productpage,
		title: 'productpage',
		component: lazy(() => import('../views/pages/ProductsPage/ProductsPage')),
	},
	// {
	// 	path: shopbycategory,
	// 	title: 'ShopByCategory',
	// 	component: lazy(() => import('../views/pages/ShopByCategory/ShopByCategory')),
	// },
];

export const Routes = [
	...AuthRoutes,
	{
		path: '/',
		title: '',
		component: lazy(() => import('../views/pages/')),
	},


];
import React, { useEffect } from 'react';
import { Link } from "react-router-dom"
import usePost from '../../hooks/usePost';
import Loading from '../../components/Loading';
import { notification } from '../../utils/notification';
import useAuth from '../../hooks/useAuth';

const Login = ({ }) => {
	const { isLoading, error, response, doPost } = usePost();
	const { user, userToken, userId, isLoading: isLoading2, doLogin, doLogout } = useAuth();
	const handleSubmit = (e) => {
		e.preventDefault();
		const { mobile, password } = e.target;
		doPost('user_login', {
			mobile: mobile.value,
			password: password.value,
		});
	};

	useEffect(() => {
		if (response && response.status === 'error') {
			response?.error && response?.error.forEach((error) => {
				const notify = notification({
					type: 'error',
					message: error,
				});
				notify();
			});
			const notify = notification({
				type: 'error',
				message: response.message,
			});
			notify();

		}
		if (response && response.status === 'success') {
			const notify = notification({
				type: 'success',
				message: 'Login Successful',
			});
			notify();
			doLogin(response.data[0], response.data[0].remember_token, response.data[0].id);
		}
	}, [response]);

	useEffect(() => {
		if (userToken) {
			window.location.href = '/';
		}
	}, [userToken])

	return (
		<div style={{
			backgroundImage: "url('assets/imgs/catagury1.png')", backgroundRepeat: " no-repeat",
			backgroundSize: "100% 100%"
		}}>
			{isLoading && <Loading />}
			<div className='row justify-content-center m-4'>
				<div className='col-sm-4'>
					<div className="card">
						<div className="card-harder border-bottom">
							<h3 className='text-center m-0'>Login</h3>
						</div>
						<div className="card-body">
						<form action='' onSubmit={handleSubmit}>
					<div class='mb-3'>
						<label for='exampleFormControlInput1' class='form-label'>
							Email Address / Mobile No.*
						</label>
						<input
							type='text'
							class='form-control'
							id='exampleFormControlInput1'
							placeholder='mobile'
							name='mobile'
						/>
					</div>
					<div class='mb-3'>
						<label for='exampleFormControlInput1' class='form-label'>
							Password
						</label>
						<input
							type='password'
							class='form-control'
							id='exampleFormControlInput1'
							placeholder='password'
							name='password'
						/>
					</div>
					<div class='mt-4'>
						<button type='submit' class=' btn-success w-100 ' disabled={isLoading}>
							login 
						</button>
					</div>
				</form>
							<div className='mt-4'>
								<p>Forget Password?</p>
							</div>
							<div className='mt-4'>
								Sign up If you are not
								<Link to='/signup' className='ms-3 fw-bold'>
									Registered
								</Link>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	);
};

export default Login;
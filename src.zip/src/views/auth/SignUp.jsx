import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import usePost from '../../hooks/usePost';
import {notification} from "../../utils/notification";
import Loading from "../../components/Loading";
import useAuth from '../../hooks/useAuth';

const SignUp = ({ history }) => {
	const { isLoading, error, response, doPost } = usePost();
	const { userToken } = useAuth();
	const handleSubmit = (e) => {
		e.preventDefault();
		if (e.target.password.value !== e.target.password2.value) {
			let notify = notification({
				type: 'error',
				message: 'Passwords do not match',
			});
			notify();
			return;
		} else {
			const data = {
				full_name: e.target.name.value,
				email: e.target.email.value,
				mobile: e.target.mobile.value,
				password: e.target.password.value,
			};
			doPost('user_register', data);
		}
	};

	useEffect(() => {
		if (response && response.status === 'error') {
			response.error &&
				response.error.forEach((error) => {
					let notify = notification({
						type: 'error',
						message: error,
					});
					notify();
				});
			response.message &&
				[response.message].forEach((error) => {
					let notify = notification({
						type: 'error',
						message: error,
					});
					notify();
				});
		} else if (response && response.status === 'success') {
			let notify = notification({
				type: 'success',
				message: 'User registered successfully',
			});
			notify();
			history.push('/login');
		}
	}, [response, error]);

	useEffect(() => {
		if (userToken) {
			history.push('/');
		}
	}, [userToken]);

	return (
		<div style={{
			backgroundImage: "url('assets/imgs/catagury1.png')", backgroundRepeat: " no-repeat",
			backgroundSize: "100% 100%"
		}}>
			{isLoading &&<Loading />}

			<div className='row justify-content-center m-4'>
			<div className='col-sm-4'>
				<div className="card">
					<div className="card-harder border-bottom">
						<h3 className='text-center m-0'>Sign Up</h3>
					</div>
					<div className="card-body">
					<form action='' onSubmit={handleSubmit}>
						<div class='mb-3'>
							<label for='exampleFormControlInput1' class='form-label'>
								Name
							</label>
							<input
								type='text'
								class='form-control'
								id='exampleFormControlInput1'
								placeholder='Name'
								name='name'
							/>
						</div>
						<div class='mb-3'>
							<label for='exampleFormControlInput1' class='form-label'>
								Email
							</label>
							<input
								type='email'
								class='form-control'
								id='exampleFormControlInput1'
								placeholder='Email Id'
								name='email'
							/>
						</div>
						<div class='mb-3'>
							<label for='exampleFormControlInput1' class='form-label'>
								Mobile No
							</label>
							<input
								type='number'
								class='form-control'
								id='exampleFormControlInput1'
								placeholder='Number'
								name='mobile'
							/>
						</div>
						<div class='mb-3'>
							<label for='exampleFormControlInput1' class='form-label'>
								Password
							</label>
							<input
								type='password'
								class='form-control'
								id='exampleFormControlInput1'
								placeholder='Password'
								name='password'
							/>
						</div>
						<div class='mb-3'>
							<label for='exampleFormControlInput1' class='form-label'>
								Confirm Password
							</label>
							<input
								type='password'
								class='form-control'
								id='exampleFormControlInput1'
								placeholder='Confirm Password'
								name='password2'
							/>
						</div>
						<div class='mt-4'>
							<button type='submit' class='btn btn-success w-100' disabled={isLoading}>
							Sign up
							</button>
						</div>
					</form>
					</div>
				</div>
			</div>
			</div>
		</div>
	);
};

export default SignUp
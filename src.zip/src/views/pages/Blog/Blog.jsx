import moment from 'moment';
import React, { useState, useEffect } from 'react';
import Loading from '../../../components/Loading';
import api from '../../../api';
import { Link } from 'react-router-dom';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import '@splidejs/splide/dist/css/themes/splide-skyblue.min.css';


const Blog = ({ match }) => {
	const [loading, SetLoading] = useState(true)
	const [blogDetailsData, setBlgDataDetls] = useState([])
	const [likeDataLst, SetLikeDataLst] = useState([])

	const blogDetails = () => {
		SetLoading(true)
		let request = `blog_details?blog_slug=${match.params.id}`
		api.get(request).then(data => {
			console.log(data, "data detalis")
			setBlgDataDetls(data.data.data)
			SetLikeDataLst(data.data.data.products)
			SetLoading(false)
		}).catch((err) => {
			console.log(" error")
			SetLoading(false)
		})

	}


	useEffect(() => {
		blogDetails()
	}, []);

	return (<>
		{
			loading && <Loading />
		}
		<div className='container mt-8'>

			<div className='row'>
				<div className="card p-0 mb-5">
					<img
						src={
							blogDetailsData?.image
								? blogDetailsData?.image
								: 'https://developer.fbw.center/assets/no-image.png'
						}
						className='card-img-top img-fluid rounded mx-auto d-block obg-fit'
						alt='blog' style={{ height: "350px",  backgroundSize: "100% 100%" }}
					/>
					<div className="card-body border-top d-flex justify-content-center">
						<div className="w-75 w-xs-100">
						<h1 className="blog-h2">{blogDetailsData?.title}</h1>
						<div className='fs-16'>

							<p style={{ fontWeight: "bold" }}> <i className='fas fa-clock me-2'></i>{moment(blogDetailsData?.date).format('DD-MM-YYYY')}</p>
						</div>
						<p className='lead ' dangerouslySetInnerHTML={{ __html: blogDetailsData?.description }}></p>
					</div>
					</div>
				</div>
			</div>


		</div>
		<div className='row green-dark  text-white py-8'>
			<div className='container w-50'>

				<Splide
					options={{
						rewind: true,
						gap: '4rem',
						perPage: 4,
						pagination: false,
						drag: false,
						perMove: 3,
						breakpoints: {
							1100: {
								perPage: 2,
							},
							680: {
								perPage: 1,
							},
						},
						classes: {
							arrows: '',
							arrow: `splide__arrow text-white `,
							prev: 'splide__arrow--prev your-class-prev  ',
							next: 'splide__arrow--next    ',
						},
					}}
				>
					{
						likeDataLst && likeDataLst.map((item, index) => (
							<SplideSlide>
								<div className='center flex-column'>
									<Link to={`/productcart/:${item.product_slug}`} >
										<img style={{ width: "150px", height: "150px", background: 0 }} src={item.product_image} class='rounded-3 w-260 ' alt='' />
									</Link>
									<Link to={`/productcart/:${item.product_slug}`} >
										<button class='btn f-Whitney-Medium btn-warr text-white fs-12 rounded-3 ps-4  mt-2 '>SHOP NOW</button>
									</Link>

								</div>
							</SplideSlide>
						))
					}
				</Splide>




			</div>
		</div>

	</>);
};

export default Blog;

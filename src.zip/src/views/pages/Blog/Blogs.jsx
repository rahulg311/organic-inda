import React from 'react';
import { useState } from 'react';
import BlogCard from '../../../components/blog/BlogCard';
import Loading from '../../../components/Loading';
import useAuth from "../../../hooks/useAuth";
import { Link } from 'react-router-dom';
import api from '../../../api';


const Blogs = () => {
	const [loading, SetLoading] = useState(true)
	const [page, setPage] = useState(1)
	const [blogData, setBlogData] = useState([])
	const [totalData, setTotalData] = useState('')
	const [blogCatLst, setBlgCatLst] = useState([])
	const [indx, setIndx] = useState('0')
	const [slug ,  setSlugId] = useState('')

	const remainingTime = (time) => {
		const start_datetime = new Date(time);
		const current_time = new Date();
		const totalSeconds = Math.floor(((current_time) - start_datetime) / 1000);
		const totalMinutes = Math.floor(totalSeconds / 60);
		const totalHours = Math.floor(totalMinutes / 60);
		const totalDays = Math.floor(totalHours / 24);
		const totalMonth = Math.floor(totalDays / 30);
		const totalYear = Math.floor(totalMonth / 12)
		const hours = totalHours - (totalDays * 24);
		const minutes = totalMinutes - (totalDays * 24 * 60) - (hours * 60);
		const seconds = totalSeconds - (totalDays * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);
		if (totalYear > 0) {
			return totalYear + (totalYear > 1 ? 'Year' : "Years")
		}
		else if (totalMonth > 0) {
			return totalMonth + (totalMonth > 1 ? 'Month' : "Months")
		}
		else if (totalDays > 0) {
			return totalDays + (totalDays > 1 ? ' Days' : ' Day');
		} else if (hours > 0) {
			return (hours + ' hrs ' + minutes + (minutes > 1 ? ' Mins' : ' Min'));
		} else if (minutes > 0) {
			return minutes + (minutes > 1 ? ' Mins ' : ' Min ') + seconds + (seconds > 1 ? ' Secs' : 'Sec');
		} else {
			return seconds + (seconds > 1 ? ' Secs' : 'Sec');
		}
	}

	const Loadmore = () => {
		setPage(page + 1)
	}

	const blogList = () => {
		SetLoading(true)
		let request = `get_blog?page_no=${page}`
		api.get(request).then(data => {
			setTotalData(data.data.all_blog)
			if (page == 1) {
				setBlogData(data.data.data)
			}
			else {
				setBlogData([...blogData, ...data.data.data])
			}

			SetLoading(false)
		}).catch((err) => {
			console.log(" error")
			SetLoading(false)
		})

	}
	const blogCatListbySlug = (blogSlug) => {
		SetLoading(true)
		let request = `blog_list?blog_category_slug=${blogSlug}&page_no=${page}`
		api.get(request).then(data => {
			console.log(data, "blogCatListbySlug")
			
			setTotalData(data.data.all_blog)
			if(page ==  1){
				setBlogData(data.data.data)
			}
			else {
				setBlogData([...blogData ,...data.data.data])
			}
			SetLoading(false)
		}).catch((err) => {
			console.log(" error")
			SetLoading(false)
		})

	}
	const blogCategoryList = () => {
		SetLoading(true)
		let request = `blog_category`
		api.get(request).then(data => {
			setBlgCatLst(data.data.data)
			SetLoading(false)
		}).catch((err) => {
			console.log(" error")
			SetLoading(false)
		})

	}
	const selctCategory = (id, slug) => {
		console.log(id)
		setIndx(id)
		setPage(1)
		console.log(slug, "slug")
		blogCatListbySlug(slug)
		setSlugId(slug)
	}

	React.useEffect(() => {
		blogList()
		blogCategoryList()
	}, []);
	React.useEffect(() => {
		slug=='' ?blogList(): blogCatListbySlug(slug)
	}, [page]);
	return (
		<>
			{
				loading &&
				<Loading />
			}
			<div className='row bg-secondary'>
				<div className='card card-header bg-secondary'>
					<h5 className='text-center m-0'>Blog</h5>
				</div>
			</div>
			<div className='container'>
				<div className='row mb-5 mt-3'>
					<div className='card'>
						<div className='card-body p-0'>
							<div className='row'>
								<div className='col-sm-9 p-0' style={{ borderRight: "1px solid #ced4da" }}>
									{
										blogData ? blogData.map((data, index) => (
											<div className="row g-0 border-bottom">
												<div className="col-md-4 p-2">
												<Link to={`/blog/${data.blog_slug}`}>
													<img src={data.media_file_path} className="img-fluid rounded-start" alt="..." style={{ height: "100%" }} />
													</Link>
												</div>
												<div className="col-md-8 p-2">
													<div className="card-body">
													<Link to={`/blog/${data.blog_slug}`}><h5 className="card-title">{data.blog_title}</h5></Link>
														<p dangerouslySetInnerHTML={{ __html: data.blog_description }} className="card-text"></p>
														<Link to={`/blog/${data.blog_slug}`}><button style={{ border: 0, background: "0" }}> <span className='text-success fs-16 ' style={{ fontWeight: "bold" }}>...Read More</span></button></Link>
														<p className="card-text"><small className="text-muted">Last updated {remainingTime(data.date)} ago</small></p>
													</div>
												</div>
											</div>

										)) :
											<div className='row mt-2 mb-2 align-items-center ' style={{ height: "50vh", alignItem: "center" }}>
												<h5 className='text-center '>No Data Found </h5></div>

									}


									{
										blogData && (blogData.length < totalData) && <div className='col-sm-12 p-4'>
											<div className='d-grid gap-2'>
												<button onClick={() => Loadmore()} className='btn btn-outline-success'>Load More</button>
											</div>
										</div>
									}

								</div>
								<div className="col-sm-3 p-0">
									<div class="card p-0 border-0">
										<div className='card-header border-bottom'>
											<h5 className='m-0 text-center'>Bolg Category</h5>
										</div>
										<ul class="list-group list-group-flush border-bottom">
											{
												blogCatLst && blogCatLst.map((data, index) => (
													<li class={indx == data.id ? "list-group-item active" : "list-group-item"} onClick={() => selctCategory(data.id, data.slug)}>{data.title}</li>
												))
											}
											{/* <li class="list-group-item active">An item</li>
										<li class="list-group-item">A second item</li>
										<li class="list-group-item">A third item</li> */}
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>





		</>
	);
};

export default Blogs;

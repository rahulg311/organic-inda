import React from 'react';
import BlogCard from '../../../components/blog/BlogCard';
import Loading from '../../../components/Loading';
import useAuth from "../../../hooks/useAuth";
import usePost from '../../../hooks/usePost';

const Blogs = () => {
	const { getUserToken,getUserId } = useAuth();
	const { response, isLoading, error, doPost } = usePost();

	React.useEffect(() => {
		const header = {
			headers: {
				'TOKEN-KEY': getUserToken(),
				id: getUserId(),
			},
		};
		const data = { page_num: '1' };
		doPost(`get_blog`, data, header);
	}, []);

	return (
		<>
                    <div className='container '>
						<div className='row'>
                            <div className='col-md-12'>
                        <div className='container border rounded-3'>
                            <div className='row'>
                            <div className='col-md-6 p-2 '>
                                <h5>BUY 2 SUPPLEMENTS <br />
                                    GET 15% OFF
                                </h5>
                            </div>
                            <div className='col-md-6 p-2 '>
                            <h5>BUY 4 TEAS <br />
                                    GET 20% OFF
                                </h5>
                            </div>
                            </div>
                        </div>
        
                        </div>
                        </div>
                        <div className='row'>
                            <div className='col-md-12'>
                                <h5 className='text-success text-center mt-4 mb-4'> Shop By Category</h5>
                               
                            </div>
                        </div>
                        <hr />
                        <div class='row mt-7 '>
						<div class='col-12 col-md-6 col-lg-2 '>
							<div class='card mb-4'>
								<img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
								<div class='card-body mt-1 text-center bg-success rounded-bottom'>
									<h5 class='card-title'>
										<a href='#'>Amlaki</a>
									</h5>
								</div>
							</div>
						</div>
						<div class='col-12 col-md-6 col-lg-2  '>
							<div class='card mb-4'>
								<img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
								<div class='card-body mt-1 text-center bg-success rounded-bottom'>
									<h5 class='card-title'>
										<a href='#'>Amlaki</a>
									</h5>
								</div>
							</div>
						</div>
						<div class='col-12 col-md-6 col-lg-2  '>
							<div class='card mb-4'>
								<img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
								<div class='card-body mt-1 text-center bg-success rounded-bottom'>
									<h5 class='card-title'>
										<a href='#'>Amlaki</a>
									</h5>
								</div>
							</div>
						</div>
                        <div class='col-12 col-md-6 col-lg-2  '>
							<div class='card mb-4'>
								<img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
								<div class='card-body mt-1 text-center bg-success rounded-bottom'>
									<h5 class='card-title'>
										<a href='#'>Amlaki</a>
									</h5>
								</div>
							</div>
						</div>
						<div class='col-12 col-md-6 col-lg-2  '>
							<div class='card mb-4'>
								<img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100'  />
								<div class='card-body mt-1 text-center bg-success rounded-bottom'>
									<h5 class='card-title'>
										<a href='#'>Amlaki</a>
									</h5>
								</div>
							</div>
						</div>
                        <div class='col-12 col-md-6 col-lg-2  '>
							<div class='card mb-4'>
								<img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
								<div class='card-body mt-1 text-center bg-success rounded-bottom'>
									<h5 class='card-title'>
										<a href='#'>Amlaki</a>
									</h5>
								</div>
							</div>
						</div>
                        </div>
                        <div className='row mt-4 mb-4'>
                            <div className='col-md-12'>
                        <div className='container border rounded-3'>
                            <div className='row'>
                            <div className='col-md-4 p-2 '>
                            <img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
                            </div>
                            <div className='col-md-4 p-2 '>
                            <img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
                            </div>
                            <div className='col-md-4 p-2 '>
                            <img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
                            </div>
                            </div>
                        </div>
        
                        </div>
                        </div>
                        <div className='row'>
                            <div className='col-md-12'>
                                <h5 className='text-success text-center mt-4 mb-4'> Herbal Formulations</h5>
                               
                            </div>
                        </div>
                        <hr />
                        <div className='row mt-5 mb-5'>
                            <div className='col-md-12'>
                        <div className='container border rounded-3'>
                            <div className='row'>
                            <div className='col-md-6  '>
                            <img src='/assets/imgs/no-image.png' alt='' class='card-img-top h-md w-100' />
                           
                            </div>
                            <div className='col-md-6 p-2 '>
                                <div className='row mt-7'>
                                    <div className='col-md-7 col-12'>
                                    <h5 className=''>7 DAYS DETOX PROGRAM <br />
                            TO TRANSFORM YOURSELF
                                </h5>
                                <p className='m-0 p-0'>A paragraph is a series of related sentences developing a central idea, called Try to think about paragraphs in terms</p>
                                <button type="button" class="btn btn-success rounded-4 m-4">Shop Now</button>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
        
                        </div>
                        </div>

                        









						{/* Products Section */}
						<section class='position-relative'>
							<div class='background-ornaments-9 l--10 t-50 background-ornaments'></div>
							<div class='container mt-5 mb-5 pt-3 pb-3'>
								<div class='row gx-8'>
									<div class='col-md-4 sidebar'>
                                        <div className='container'>
                                        <div className='row bg-success rounded'>
                                            <div className='col-md-12'>
                                                <h5 className='text-white mt-2'>FILTER BY</h5>
                                            </div>
                                        </div>
										<div s>
											<div class='br-0'>
												<select class='form-select' aria-label='Default select example'>
													<option selected>Filter by</option>
													<option value='1'>One</option>
													<option value='2'>Two</option>
													<option value='3'>Three</option>
												</select>
											</div>
											<div class='mt-3'>
												<select class='form-select' aria-label='Default select example'>
													<option selected>Category</option>
													<option value='1'>One</option>
													<option value='2'>Two</option>
													<option value='3'>Three</option>
												</select>
											</div>
										</div>
									</div>
                                    </div>

								
								</div>
							</div>
						</section>
						{/* Products Section */}
                        </div>
					</>
	);
};

export default Blogs;

import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import failed from '../../assets/failed.png';

const CancelPayment  = () => {
    const  currentUrl = window.location.href;
    const [ Ordid , setOrdId ] =useState("")
    useEffect(() => {
        setOrdId(currentUrl.split('=').pop())
        window.localStorage.removeItem('cart');

    }, []);

    return (
       
        <div className='row justify-content-center m-8'>

            <div className='col-sm-3 border text-center'>
              <img style={{height:"80px", width:"80px"}} src={failed}/>

                <h5>your payment  failed </h5>
                <h7>your order id  #{Ordid} </h7>

                <NavLink to="/" className="btn btn-outline-success btn-sm mt-2 mb-2"><i className="fa fa-arrow-left"></i> Go Back to Home</NavLink>
            </div>

        </div>
       

    );
};


export default CancelPayment;
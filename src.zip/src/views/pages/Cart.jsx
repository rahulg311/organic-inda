import React, { useEffect } from 'react';
import Loading from '../../components/Loading';
import ProductCard from '../../components/Cart/ProductCard';
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';
import { NavLink } from 'react-router-dom';

const Cart = () => {
	const { response, isLoading, doPost } = usePost();
	const [cart, setCart] = React.useState([]);
	const [total, setTotal] = React.useState(0);
	const [totalItems, setTotalItems] = React.useState(0);
	const { getUserToken, getUserId } = useAuth();

	const calculateTotalItems = () => {
		let totalItems = 0;
		cart?.forEach((item) => {
			totalItems += item.quantity;
		});
		setTotalItems(totalItems);
	};

	const calculateTotal = () => {
		let total = 0;
		cart?.forEach((item) => {
			total += item.actualPrice * item.quantity;
		});
		setTotal(total);
	};

	const getCart = () => {
		const cart = JSON.parse(localStorage.getItem('cart'));
		setCart(cart);
	};

	const updateCart = (cart) => {
		localStorage.setItem('cart', JSON.stringify(cart));
		setCart(cart);
	};

	const deleteProduct = (productId) => {
		const cart = JSON.parse(localStorage.getItem('cart'));
		const newCart = cart.filter((product) => product.id !== productId);
		updateCart(newCart);
	};

	const incrementProduct = (productId) => {
		const cart = JSON.parse(localStorage.getItem('cart'));
		const newCart = cart?.map((product) => {
			if (product.id === productId) {
				const quantity = product.quantity + 1;
				product.quantity = quantity;
				product.price = product.actualPrice * quantity;
			}
			return product;
		});
		updateCart(newCart);
	};

	const decrementProduct = (productId) => {
		const cart = JSON.parse(localStorage.getItem('cart'));
		const newCart = cart?.map((product) => {
			if (product.id === productId) {
				const quantity = product.quantity <= 1 ? 1 : product.quantity - 1;
				product.quantity = quantity;
				product.price = product.actualPrice * quantity;
			}
			return product;
		});
		updateCart(newCart);
	};

	useEffect(() => {
		getCart();
		if (getUserToken()) {
			addToCart();
		}
	}, []);

	/* add to cart api */
	const addToCart = (e) => {

		if (getUserToken()) {
			const cart = JSON.parse(localStorage.getItem('cart'));
			let prds_id = [];
			let quantity = [];

			cart?.map((c) => {
				prds_id.push(c.id);
				quantity.push(c.quantity);
			});

			const data = {
				'user_id': getUserId(),
				'product_id': prds_id.join(','),
				'quantity': quantity.join(',')
			};

			doPost('add_to_cart', data);

		}

	};
	/* add to cart api */

	useEffect(() => {
		calculateTotal();
		calculateTotalItems();
	}, [cart]);

	return (
		<div class='container mt-5'>
			<div class='row gy-5 gx-8'>
				<div class='col-md-8 col-12'>
					<div class='card border-0 py-0 '>
						<div class='card-header mb-3 px-5 bg-secondary bg-opacity-10'>

		{!cart && <NavLink to="/products" className="btn btn-outline-success btn-sm mt-2">Go Back to Shop</NavLink>}

							{cart?.length !== 0 ? (
								<h5 class='mb-1'>My Cart {totalItems}</h5>
							) : (
								<>
									<h5 class='mb-0'>Empty Cart</h5>
									<NavLink to="/products" className="btn btn-outline-success btn-sm mt-2">Go Back to Shop</NavLink>
								</>
							)}
						</div>
						<section class='px-lg-4 px-4'>
							{isLoading ? (
								<Loading size='sm' className='center my-4' />
							) : (
								cart?.map((item, index) => {
									return (
										<ProductCard
											item={item}
											deleteProduct={deleteProduct}
											decrementProduct={decrementProduct}
											incrementProduct={incrementProduct}
										/>
									);
								})
							)}
						</section>
					</div>
				</div>
				{cart?.length !== 0 && (
					<div class='col-md-4 col-12'>
						<div class='card'>
							<div class='card-header bg-secondary bg-opacity-10'>
								<h5 class='card-title mb-0'>Price Details</h5>
							</div>
							<div class='card-body'>
								<div class='d-flex justify-content-between mb-2'>
									<small>price ({totalItems} items)</small>
									<small>₹{total}</small>
								</div>

								<div class='d-flex justify-content-between mb-2'>
									<small>Discount</small>
									<small>0</small>
								</div>
								<div class='d-flex justify-content-between mb-2'>
									<small>Delivery Charges</small>
									<small>Free</small>
								</div>
							</div>
							<footer class='card-footer px-0'>
								<div class='d-flex bg-secondary px-3 py-10px bg-opacity-10 justify-content-between mb-2'>
									<h5 class='mb-0'>Total Amount</h5>
									<h5 class='mb-0'>₹{total}</h5>
								</div>
								<div class='px-3 my-4'>
									<a class='btn btn-success py-7px fs-15 w-100' href="/checkout">
										<span>Continue Checkout</span>
									</a>
								</div>
								<div class='px-3 border-top mt-3 pt-3'>
									<i class='fas fa-shield-alt me-3'></i>
									<span>Secure Payment</span>
								</div>
							</footer>
						</div>
					</div>
				)}
			</div>
		</div>
	);
};

export default Cart;

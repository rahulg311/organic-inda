import React, { useEffect, useRef } from "react";
import useFetch from "../../hooks/useFetch";
import Loading from "../../components/Loading";
import ProductCard from "../../components/Products/ProductCard";
import ProductssSelling from "../../components/Products/ProductssSelling";
import useAuth from "../../hooks/useAuth";
import usePost from "../../hooks/usePost";
import { useState } from "react";

import { NavLink } from "react-router-dom";
import { notification } from "../../utils/notification";
import api from "../../api";

const Carts = () => {
  const getId = JSON.parse(localStorage.getItem("user"));
  const { response, isLoading, doPost } = usePost();
  const [cart, setCart] = React.useState([]);
  const [total, setTotal] = React.useState(0);
  const [totalItems, setTotalItems] = React.useState(0);
  const { getUserToken, getUserId } = useAuth();

  const calculateTotalItems = () => {
    let totalItems = 0;
    cart?.forEach((item) => {
      totalItems += item.quantity;
    });
    setTotalItems(totalItems);
  };

  const calculateTotal = () => {
    let total = 0;
    cart?.forEach((item) => {
      total += item.actualPrice * item.quantity;
    });
    setTotal(total);
  };

  // const getCart = () => {
  //     const cart = JSON.parse(localStorage.getItem('cart'));
  //     setCart(cart);
  // };

  const DeleteProduct = (prodId) => {
    console.log(getId, "check id ");
    let request = {
      url: "delete_cart",
      headers: {
        "TOKEN-KEY": getId.remember_token,
        id: getId.id,
      },
      data: { product_id: prodId },
    };
    api
      .postOtherApi(request)
      .then((data) => {
        console.log("check product detail :", data.data.message);
        const notify = notification({
          type: "success",
          message: data.data.message,
        });
        notify();
      })
      .catch((err) => {
        console.log(" error");
        const notify = notification({
          type: "error",
          message: "Address is required",
        });
        notify();
      });
  };
  const updateCart = (cart) => {
    localStorage.setItem("cart", JSON.stringify(cart));
    console.log("inUpdate card ", cart);
    setCart(cart);
  };

  const deleteProduct = (productId) => {
    console.log(productId, "productid check");
    getId && DeleteProduct(productId);
    const cart = JSON.parse(localStorage.getItem("cart"));
    const newCart = cart.filter((product) => product.id !== productId);
    console.log("in delete newCard ", newCart);
    updateCart(newCart);
  };

  const incrementProduct = (productId) => {
    const cart = JSON.parse(localStorage.getItem("cart"));
    const newCart = cart?.map((product) => {
      if (product.id === productId) {
        const quantity = product.quantity + 1;
        product.quantity = quantity;
        product.price = product.actualPrice * quantity;
        addToCartApi(product);
      }
      return product;
    });
    updateCart(newCart);
  };

  const decrementProduct = (productId) => {
    console.log(productId, "in decrements");
    let flag = true;
    const cart = JSON.parse(localStorage.getItem("cart"));
    const newCart = cart?.map((product) => {
      if (product.id === productId) {
        if (product.quantity == 1) {
          flag = false;
          deleteProduct(productId);
        } else if (product.quantity > 1) {
          flag = true;
          const quantity = product.quantity > 1 && product.quantity - 1;
          product.quantity = quantity;
          product.price = product.actualPrice * quantity;
          addToCartApi(product);
        }
      }
      return product;
    });

    flag == true && updateCart(newCart);
  };

  useEffect(() => {
    // const cartdemo = JSON.parse(localStorage.getItem('cart'));
    // console.log("cartdemoutkarshcheck:",cartdemo)
    const cart = JSON.parse(localStorage.getItem("cart"));
    setCart(cart);
    // getCart();
    // if (getUserToken()) {
    //     addToCart();
    // }
  }, []);

  // const addToCart = (e) => {

  //     if (getUserToken()) {
  //         const cart = JSON.parse(localStorage.getItem('cart'));
  //         console.log('carererer ', cart);

  //         let prds_id = [];
  //         let quantity = [];

  //         cart?.map((c) => {
  //             prds_id.push(c.id);
  //             quantity.push(c.quantity);
  //             const data = {
  //                 'user_id': getUserId(),
  //                 'product_id': c.id,
  //                 'quantity': c.quantity
  //             };
  //             const headers = {
  //                 headers: {
  //                     'TOKEN-KEY': getUserToken(),
  //                     id: getUserId(),
  //                 },
  //             };

  //             doPost('add_to_cart', data, headers);
  //         });

  //     }

  // };

  const addToCartApi = (item) => {
    if (getUserToken()) {
      /* send cart to api */
      const data = {
        user_id: getUserId(),
        product_id: item.id,
        quantity: item.quantity,
      };

      const headers = {
        headers: {
          "TOKEN-KEY": getUserToken(),
          id: getUserId(),
        },
      };

      doPost("add_to_cart", data, headers);
      /* send cart to api */
    }
  };

  useEffect(() => {
    calculateTotal();
    calculateTotalItems();
    // addToCart()
  }, [cart]);

  return (
    <div className=" mt-5">
      <div className="row   whitec ">
        <div className="col-md-8  mb-3">
          <div className="container">
            <div className="row border bg-white rounded-4">
              <div className="col-md-12">
                <div className="row pt-1 text-black  border rounded-1">
                  <div className="col-md-12">
                    {cart && cart?.length !== 0 ? (
                      <p className="p-1 f-HelveticaNeue-Light fs-5">
                        {" "}
                        My Cart {totalItems}
                      </p>
                    ) : (
                      <>
                        <h6 class="text-center">My Cart</h6>
                        <div className="row">
                          <hr></hr>
                        </div>
                        <p className="text-center">
                          No Product Added in Your Cart
                        </p>
                        <NavLink
                          to="/offer"
                          className="btn btn-outline-success btn-sm mt-2 mb-4"
                          style={{ marginLeft: "43%" }}
                        >
                          Go Back to Shop
                        </NavLink>
                      </>
                    )}
                  </div>
                </div>
                {/* <hr className="m-0 p-0 w-100"/> */}

                {/* Product list starts here */}

                {cart &&
                  (cart?.length !== 0 || !cart == "null") &&
                  cart.map((item, index) => (
                    <>
                      <div className="row  mt-5 mb-2">
                        <div className="col-md-2 col-6 ">
                          <img
                            className="w-100 h-100 "
                            src={item.media_file_path}
                            alt=""
                          />
                        </div>
                        <div className="col-md-5 col-6">
                          <p className="m-0 f-HelveticaNeue-Light fs-6 fw-bold">
                            {" "}
                            {item.prd_title}{" "}
                          </p>
                          <p className="m-0   f-HelveticaNeue-Light fs-13">
                            90 ct.bottle{" "}
                          </p>
                          <p className="m-0 mt-2 fs-6">
                            <i class="fas fa-rupee-sign me-2"></i>
                            <span className="h-5 pt-2 fs-6 ">{item.price}</span>
                          </p>
                        </div>
                        <div className="col-md-5 col-12 mt-5 ">
                          <p className="text-center f-HelveticaNeue-Light  fw-bold">
                            Delivery within 3 days
                          </p>
                        </div>
                      </div>
                      {/* /* Product name */}

                      {/* add to cart */}

                      <div class=" row align-items-center m-0 p-0 mt-4">
                        {/* <div className=" col-md-2 col-12  w-20 menu-responsive-w">
                                <div class="d-flex ">
                                    <span class="input-group-btn m-2   ">
                                        <button type="button" class="quantity-left-minus btn  btn-number border rounded-circle" data-type="minus" data-field="">
                                            <span class="glyphicon glyphicon-minus"><i class="fas fa-minus fs-12"></i></span>
                                        </button>
                                    </span>
                                   <p className='border text-center mt-2  pt-1 pb-1 ps-3 pe-3'>0</p>
                                    <span class="input-group-btn m-2">
                                        <button type="button" class="quantity-right-plus btn  btn-number border rounded-circle" data-type="plus" data-field="">
                                            <span class="glyphicon glyphicon-plus"><i class="fas fa-plus fs-12"></i></span>
                                        </button>
                                    </span>
                                </div>
                            </div> */}
                        <div className=" col-md-2 col-12   menu-responsive-w">
                          <nav class="mb-0 mb-3">
                            <ul class="pagination mb-0 pagination-sm">
                              <li
                                class="page-item cursor"
                                onClick={() => {
                                  decrementProduct(item.id);
                                }}
                              >
                                <span class="page-link">-</span>
                              </li>
                              <li class="page-item">
                                <span class="page-link"> {item.quantity}</span>
                              </li>
                              <li
                                class="page-item cursor"
                                onClick={() => incrementProduct(item.id)}
                              >
                                <span class="page-link">+</span>
                              </li>
                            </ul>
                          </nav>
                        </div>

                        {/* add to cart */}

                        {/* wishlist */}
                        <div class="mt-1 col-md-2 m-0 col-6 m-0 p-0">
                          <p className="fs-16 ms-5">
                            {" "}
                            <i class="far fa-heart text-danger pe-2"></i>
                            <span className=" f-HelveticaNeue-Light  ">
                              Wishlist
                            </span>
                          </p>
                        </div>
                        {/* wishlist */}

                        {/* delete */}
                        <div class="mt-1 col-md-2 col-6 m-0">
                          <p
                            className="fs-16"
                            onClick={() => deleteProduct(item.id)}
                          >
                            {" "}
                            <i class="fas fa-trash pe-2   text-danger"></i>{" "}
                            <span className="f-HelveticaNeue-Light">
                              Delete
                            </span>
                          </p>
                        </div>
                        {/* delete */}
                      </div>
                      {/* border line */}
                      {/* <div className="border-green-lines mt-2 mb-2"></div> */}
                      {/* border line */}
                      {/* add to cart */}

                      {/* Product list ends here */}
                    </>
                  ))}

                {cart?.length > 0 && (
                  <div class="d-grid  col-12 col-md-4 text-center mx-auto mt-4 mb-5 mt-3">
                    <button
                      class="btn green-h text-white f-HelveticaNeue-Light fs-15"
                      type="button"
                    >
                      <NavLink to="/payment" className="text-white">
                        CONTINUE CHECKOUT{" "}
                      </NavLink>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        {/* slider 2 */}
        <div class="col-md-4 col-12 mb-4">
          <div className="container">
            <div class="card">
              <div class="card-header bg-secondary bg-opacity-10">
                <h5 class="card-title mb-0">Price Details</h5>
              </div>
              <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                  <small>Price ({totalItems} items)</small>

                  <small>₹{total}</small>
                </div>
                <div class="d-flex justify-content-between mb-2">
                  <small>Discount</small>
                  <small>₹ 0</small>
                </div>
                <div class="d-flex justify-content-between mb-2">
                  <small>Delivery Charges</small>
                  <small>Free</small>
                </div>
              </div>
              <footer class="card-footer px-0">
                <div class="d-flex bg-secondary px-3 py-10px bg-opacity-10 justify-content-between mb-2">
                  <h5 class="mb-0">Total Amount</h5>
                  <h5 class="mb-0">₹{total}</h5>
                </div>

                <div class="px-3 border-top mt-3 pt-3">
                  <p className="green-h-text">
                    You will Save ₹ 545 on the Order{" "}
                  </p>
                  <i class="fas fa-shield-alt me-3"></i>
                  <span>Secure Payment</span>
                </div>
              </footer>
            </div>
          </div>
        </div>
      </div>
      {/* slider 1 */}
    </div>
  );
};

export default Carts;

import React, { useEffect } from 'react';
import Loading from '../../components/Loading';
import ProductCard from '../../components/Cart/ProductCard';
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';
import { NavLink } from 'react-router-dom';

import { Accordion } from 'react-bootstrap';

const Checkout = ({ history }) => {
    const { response, isLoading, doPost } = usePost();
    const [cart, setCart] = React.useState([]);
    const [total, setTotal] = React.useState(0);
    const [totalItems, setTotalItems] = React.useState(0);
    const { getUserToken, getUserId } = useAuth();
    const [userData, setUserData] = React.useState(null);
    const [address, setAddress] = React.useState(13);
    const [shippingMethod, setShippingMethod] = React.useState(2);
    const [orderNumber, setOrderNumber] = React.useState('OI' + Math.floor(Math.random() * (9999 - 1111 + 1) + 1111) + new Date().getUTCMilliseconds());

    const [btnDisable, setBtnDisable] = React.useState(false);

    const { AllowAddAddress, setAllowAddAddress } = React.useState(0);

    const calculateTotalItems = () => {
        let totalItems = 0;
        cart.forEach((item) => {
            totalItems += item.quantity;
        });
        setTotalItems(totalItems);
    };

    const calculateTotal = () => {
        let total = 0;
        cart.forEach((item) => {
            total += item.actualPrice * item.quantity;
        });
        setTotal(total);
    };

    const getCart = () => {
        const cart = JSON.parse(localStorage.getItem('cart'));
        setCart(cart);
    };

    const updateCart = (cart) => {
        localStorage.setItem('cart', JSON.stringify(cart));
        setCart(cart);
    };

    const deleteProduct = (productId) => {
        const cart = JSON.parse(localStorage.getItem('cart'));
        const newCart = cart.filter((product) => product.id !== productId);
        updateCart(newCart);
    };

    const incrementProduct = (productId) => {
        const cart = JSON.parse(localStorage.getItem('cart'));
        const newCart = cart.map((product) => {
            if (product.id === productId) {
                const quantity = product.quantity + 1;
                product.quantity = quantity;
                product.price = product.actualPrice * quantity;
            }
            return product;
        });
        updateCart(newCart);
    };

    const decrementProduct = (productId) => {
        const cart = JSON.parse(localStorage.getItem('cart'));
        const newCart = cart.map((product) => {
            if (product.id === productId) {
                const quantity = product.quantity <= 1 ? 1 : product.quantity - 1;
                product.quantity = quantity;
                product.price = product.actualPrice * quantity;
            }
            return product;
        });
        updateCart(newCart);
    };

    /* handle change */
    const handleChange = (e) => {

    }
    /* handle change */

    /* pay */
    const pay = () => {

    }
    /* pay */

    /* Checkout */
    const finalCheckout = async () => {

        let prds_id = [];

        let prds_qty = [];

        let prds_sku = [];

        userData?.cart_info?.map((p) => {
            prds_id.push(p.id);
            prds_qty.push(p.cart_quantity);
            prds_sku.push(p.prd_slug);
        });

        const shippingStandard = 1;
        setBtnDisable(true);

        const headers = {
            headers: {
                'TOKEN-KEY': getUserToken(),
                id: getUserId(),
            },
        };

        const data = {
            'user_id': getUserId(),
            'product_id': prds_id.join(','),
            //'product_sku': prds_sku.join(','),
            'remark': '',
            'qty': prds_qty.join(','),
            'payment_mode': shippingMethod,
            'shipping_id': address,
            /* 'shipping_address_line1': '',
            'shipping_address_line2': '',
            'shipping_postal_code': '',
            'shipping_state': 1,
            'shipping_city': 1, */
            /* 'billing_address_name': '',
            'billing_address_line1': '',
            'billing_address_line2': '',
            'billing_postal_code': '',
            'billing_state': 1,
            'billing_city': 1, */
            'billing_id': 1,
            'item_discount': 0,
            'order_number': orderNumber,
            'shipping_method': shippingStandard,
            'payment_status': shippingMethod
        };

        const order_res = await doPost('order_create', data, headers);

        if (order_res) {
            setBtnDisable(false);
            history.push({
                pathname: '/thankyou',
                state: { heading: 'Thank you for your order', subheading: 'Your Order has been created for Order ID : ' + order_res.data.message }
            });
        }
    }
    /* Checkout */

    useEffect(() => {
        getCart();
        checkout();
        if (!getUserToken()) {
            history.push('/login');
            return;
        }
    }, []);

    /* get user detail */
    const checkout = async () => {

        const data = {
            'user_id': getUserId(),
            'token': getUserToken(),
        };

        const user_data = await doPost('checkout', data);

        setUserData(user_data?.data);

    }
    /* get user detail */

    useEffect(() => {
        calculateTotal();
        calculateTotalItems();
    }, [cart]);

    return (

        /*  */
        <>
            {/* slider 1 */}
            <div className="container">
                <div className="row mt-4">
                    <div className="col-md-7">



                        {/* accordion */}
                        <Accordion defaultActiveKey="0">

                            <Accordion.Item eventKey="0">
                                {/* address */}
                                <Accordion.Header>Delivery Address</Accordion.Header>
                                <Accordion.Body>
                                    <div className="row bg-white mt-3">

                                        {userData?.address_info != "" &&

                                            userData?.address_info.map((address) => {
                                                return <div className="col-md-6 border m-2 ">
                                                    <div className="row">
                                                        <div className="col-md-9 col-8 m-2">
                                                            <h6 className="mb-0">{address.address_user_address}</h6>
                                                            <p className="mb-0">
                                                                {address.city_name}
                                                            </p>
                                                            <p className="mb-0">
                                                                {address.address_user_address1}
                                                            </p>
                                                            <p className="mb-0">
                                                                {address.state_name}
                                                            </p>
                                                            <p className="mb-0">
                                                                {address.address_pincode}
                                                            </p>
                                                        </div>

                                                        <div className="col-md-2 col-2 ">
                                                            <div class="form-check pt-2 pb-2">
                                                                <input className="form-check-input" type="radio" name="address" value={address.id} id="flexRadioDefault1" onChange={(e) => setAddress(address.id)} checked />
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            })


                                        }

                                    </div>

                                    {/* <div className="d-grid gap-2 col-8 col-md-12 mx-auto mt-3">
                                        <button className="btn btn-outline-success" type="button" data-toggle="modal" data-target="#exampleModal">ADD NEW</button>
                                    </div> */}

                                </Accordion.Body>
                                {/* address */}
                            </Accordion.Item>

                            <Accordion.Item eventKey="1">

                                {/* payment option */}
                                <Accordion.Header>Payment Option</Accordion.Header>
                                <Accordion.Body>
                                    <div className="row">
                                        <div className="col-md-12 border ">
                                            <div className="form-check p-2 ms-2">
                                                <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={(e) => { setShippingMethod(1) }} />
                                                <label className="form-check-label  f-Whitney-Medium " for="flexRadioDefault1">
                                                    Online
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-md-12  border mt-2 mb-2">
                                            <div className="form-check p-2 ms-2">
                                                <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onChange={(e) => { setShippingMethod(2) }} checked/>
                                                <label className="form-check-label  f-Whitney-Medium " for="flexRadioDefault1">
                                                    Cash On Delivary
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </Accordion.Body>
                                {/* payment option */}

                            </Accordion.Item>
                        </Accordion>
                        {/* accordion */}


                        {/* action buttons starts here */}
                        <div className="row mt-4">
                            <div className="col-md-12 d-flex ">

                                <h6 className="ms-2">
                                    <i className="las la-check-circle mt-2 me-2"></i>Safe & Secure payment
                                </h6>
                            </div>
                        </div>

                        <div className="row mt-2 mb-2">
                            <div className="col-md-12  col-6 mx-auto d-grid gap-2 d-md-flex justify-content-md-center">

                                {shippingMethod != 2 &&
                                    <button type="button" class="btn btn-success" onClick={(e) => pay()} disabled={(btnDisable) ? true : false}>Continue</button>
                                }

                                {shippingMethod == 2 &&
                                    <button type="button" class="btn btn-success" onClick={(e) => finalCheckout()} disabled={(btnDisable) ? true : false}>
                                        Place Order
                                    </button>
                                }

                            </div>
                        </div>
                        {/* action buttons ends here */}

                    </div>
                    {/* slider 2 */}

                    {/* sidebar */}
                    <div className="col-md-4 mb-5 ">
              
						<div class='card'>
							<div class='card-header bg-secondary bg-opacity-10'>
								<h5 class='card-title mb-0'>Cart Details</h5>
							</div>
							<div class='card-body f-0-9'>


								 {userData?.cart_info?.length > 0 && userData?.cart_info?.map((c) => {
                                        return <div className="d-flex mt-2">

                                            <img className="h-50px" src={(c.media_file_path) ? c.media_file_path : `assets/imgs/banner.png`} alt={c.prd_title} />

                                            <div className="ms-1">
                                                <p className="m-0 f-0-9">{c.prd_title}</p>
                                                <p className="m-0 f-0-9">Qty: {c.cart_quantity}</p>
                                            </div>

                                            <div className="ms-auto">
                                                <i className="fa fa-inr"></i> {c.prd_selling_price}
                                            </div>

                                        </div>
                                    })}

                                    {/* cart details ends here */}

                                    <hr />

                                    {/* subtotal starts here */}
                                    <div className="row">
                                        <div className="col-md-9 col-8">
                                            <h6>Sub Total</h6>
                                        </div>
                                        <div className="col-md-3 d-flex col-4">
                                            
                                            <h6><i class="fa fa-inr"></i> {
                                                userData?.sub_total
                                            }</h6>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-md-9 col-8">
                                            <h6>Grand Total</h6>
                                        </div>
                                        <div className="col-md-3 d-flex col-4">
                                            
                                            <h6><i class="fa fa-inr"></i> {
                                                userData?.sub_total
                                            }</h6>
                                        </div>
                                    </div>

							</div>
							
						</div>
				
                    </div>
                    {/* sidebar */}

                </div>
            </div>
            {/* slider 1 */}


            {/* checkout */}


           
        </>
        /*  */
    );
};

export default Checkout;

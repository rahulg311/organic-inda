import React, { useEffect, useRef, useState } from "react";
import API from "../../../api";
import { Link } from "react-router-dom";
import usePost from "../../../hooks/usePost";
import useAuth from "../../../hooks/useAuth";
import Loading from "../../../components/Loading";
import { notification } from "../../../utils/notification";

const ComboStore = () => {
  var currentUrl = window.location.href;
  const [products, setProducts] = React.useState([]);
  const [loading, SetLoading] = useState(true);
  const [navCount, setCount] = useState([]);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [id, setId] = useState(0);
  const [value, setValue] = useState(0);
  const [category, setCategory] = useState([]);
  const { getUserToken, getUserId } = useAuth();
  const { response, doPost } = usePost();
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);
  const [show4, setShow4] = useState(false);
  const [urlid, setUrlid] = useState(currentUrl.split(":").pop());
  // const [homeUrl, setHomeUrl]= useState(currentUrl.split(':').pop())

  const nextPage = () => {
    if (navCount.length > currentPage) {
      setCurrentPage(currentPage + 1);
    }
  };
  const prevPage = () => {
    if (currentPage === 1) {
      return;
    }
    setCurrentPage(currentPage - 1);
  };
  const navicount = (count) => {
    let item = [];
    var i = 0;
    while (count > 0) {
      count = count - 12;
      i = i + 1;
      item.push(i);
    }
    setCount(item);
  };

  const productList = () => {
    SetLoading(true);
    let request = `product?page=${currentPage}&limit=12`;
    API.get(request)
      .then((data) => {
        setProducts(data.data.data);
        navicount(data.data.count);
        SetLoading(false);
      })
      .catch((err) => {
        SetLoading(false);
      });
  };
  const categoryApi = () => {
    let request = "getcategorysubcategory";
    API.get(request)
      .then((data) => {
        const newData = data.data.data.map((key, index) => {
          return { ...key, status: false };
        });
        setCategory(newData);
      })
      .catch((err) => {});
  };
  const catProductList = (key) => {
    SetLoading(true);
    let request = `product?page=${currentPage}&limit=12&sub_category_id=${key}`;
    API.get(request)
      .then((data) => {
        setProducts(data.data.data);
        navicount(data.data.count);
        SetLoading(false);
      })
      .catch((err) => {
        SetLoading(false);
      });
  };
  const subProductList = (key) => {
    SetLoading(true);
    let request = `product?page=${currentPage}&limit=12&sub_category_id=${key}`;
    API.get(request)
      .then((data) => {
        setProducts(data.data.data);
        navicount(data.data.count);
        SetLoading(false);
      })
      .catch((err) => {
        SetLoading(false);
      });
  };
  const onTap = (item, index) => {
    let data = [...category];
    data[index].status = item.status == false ? true : false;
    setCategory(data);
  };

  const onChangeFiltr = (value) => {
    let request = `product?page=${currentPage}&limit=12&filter_price=${value}`;
    API.get(request)
      .then((data) => {
        setProducts(data.data.data);
        navicount(data.data.count);
        SetLoading(false);
      })
      .catch((err) => {
        SetLoading(false);
      });
  };
  const addToCart = async (item) => {
    SetLoading(true);
    const notify = notification({
      type: "success",
      message: "one item added",
    });
    notify();
    setTimeout(() => {
      window.location.reload();
    }, 1000);
    const getCardData = JSON.parse(localStorage.getItem("cart"));
    if (getCardData) {
      const checkItem = getCardData.find((e) => e.id === item.id);

      if (checkItem) {
        const newCardData = getCardData.map((item) => {
          if (item.id === checkItem.id) {
            const quantity = item.quantity + 1;
            item.quantity = quantity;
            item.price = item.actualPrice * quantity;
            addToCartApi(item);
          }
          return item;
        });
        localStorage.setItem("cart", JSON.stringify(newCardData));
        setTimeout(() => {
          SetLoading(false);
        }, 500);
        return;
      } else {
        item["quantity"] = 1;
        addToCartApi(item);

        localStorage.setItem("cart", JSON.stringify(item));
      }

      const newCardData = [
        ...getCardData,
        {
          ...item,
          quantity: 1,
          price: item.prd_mrp,
          actualPrice: item.prd_mrp,
        },
      ];
      localStorage.setItem("cart", JSON.stringify(newCardData));
      setTimeout(() => {
        SetLoading(false);
      }, 500);

      return;
    }
    const newCardData = [
      { ...item, quantity: 1, price: item.prd_mrp, actualPrice: item.prd_mrp },
    ];
    localStorage.setItem("cart", JSON.stringify(newCardData));
    setTimeout(() => {
      SetLoading(false);
    }, 500);
    return;
  };

  const addToCartApi = (item) => {
    if (getUserToken()) {
      /* send cart to api */
      const data = {
        user_id: getUserId(),
        product_id: item.id,
        quantity: item.quantity,
      };

      const headers = {
        headers: {
          "TOKEN-KEY": getUserToken(),
          id: getUserId(),
        },
      };

      doPost("add_to_cart", data, headers);
      /* send cart to api */
    }
  };
  useEffect(() => {
    productList();
    categoryApi();
    setUrlid(currentUrl.split(":").pop());
  }, []);
  useEffect(() => {
    productList();
  }, [currentPage]);
  useEffect(() => {
    setUrlid(currentUrl.split(":").pop());
    // setHomeUrl(currentUrl.split(':').pop())
  }, [currentUrl]);

  useEffect(() => {
    if (urlid.includes("cat")) {
      catProductList(urlid.split("=").pop());
      setId(urlid.split("=").pop());
      setValue(3);
      setCurrentPage(1);
    } else if (urlid.includes("subid")) {
      subProductList(urlid.split("=").pop());
      setValue(4);
      setId(urlid.split("=").pop());
      setCurrentPage(1);
    }
  }, [urlid]);
  // useEffect(()=>{
  //     if(homeUrl.includes("homecat")){
  //         catProductList(homeUrl.split('=').pop());
  //         setHomeUrl(homeUrl.split('=').pop())
  //           setValue(3);
  //           setCurrentPage(1)
  //     }

  // },[homeUrl])

  return (
    <>
      {loading && <Loading />}
      <div className="mt-2 row ">
        <div className="col-md-12 col-12">
          {/* <div className=' position-relative'>
        <img
            src='https://images.unsplash.com/photo-1498837167922-ddd27525d352?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80'
            alt=''
            class='w-100 h-lg2'
        />
        <h1 className='translate-center-middle text-white bg-dark bg-opacity-25 p-4 rounded-4'>
            shop now
        </h1>
    </div> */}
          <>
            <div className="row  banner-herb  ">
              <div className=" col-md-12   d-flex justify-content-center h-420   align-items-center d-block optocity-b bg-dark  ">
                <h1 className="text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4">
                  {" "}
                  <strong className="f_r_24">COMBO STORE</strong>{" "}
                </h1>
              </div>
            </div>
          </>
          <div className="containe mt-10 px_7 ">
            <section className="row gy-6 ">
              <div className="col-12 col-md-2 col-lg-3 h-50  border">
                <div className="row green-h">
                  <div className="col-12 pt-1">
                    <p className="p-1 pt-2  fs-19 text-white">Filter by</p>
                  </div>
                </div>
                {category.length > 0 &&
                  category.map((item, index) => (
                    <div className=" row p-1  border text-muted">
                      <div
                        className="col-10 mt-2 mb-2 fs-14 border-0 text-muted"
                        style={{ cursor: "pointer" }}
                        onClick={() => {
                          item.sub_cateory.length == 0 &&
                            catProductList(item.id);
                          setId(item.id);
                          setValue(3);
                          setCurrentPage(1);
                        }}
                      >
                        {item.title}
                      </div>
                      {item.sub_cateory.length > 0 && (
                        <div className="col-2 mt-2">
                          <i
                            class="fas fa-chevron-down"
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              onTap(item, index);
                            }}
                          ></i>
                        </div>
                      )}

                      {item.status == true && (
                        <>
                          <ul class="list-group " style={{ cursor: "pointer" }}>
                            {item.sub_cateory &&
                              item.sub_cateory.map((item, index) => (
                                <li
                                  class="list-group-item border-none navv"
                                  onClick={() => {
                                    subProductList(item.id);
                                    setValue(4);
                                    setId(item.id);
                                    setCurrentPage(1);
                                  }}
                                >
                                  {item.sub_category_title}
                                </li>
                              ))}
                          </ul>
                        </>
                      )}
                    </div>
                  ))}
                <div className=" row p-1  border text-muted">
                  <div className="col-10 mt-2 mb-2 fs-14 border-0">Herbs</div>
                  <div className="col-2 mt-2">
                    <i
                      class="fas fa-chevron-down"
                      onClick={(e) => setShow2(!show2)}
                    ></i>
                  </div>
                  {show2 == true && (
                    <>
                      <ul class="list-group ">
                        <li class="list-group-item border-none navv">
                          Tulsi Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          Ashwagandha
                        </li>
                        <li class="list-group-item border-none navv">
                          Darjiling Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          Tulsi Brahmi Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          View All
                        </li>
                      </ul>
                    </>
                  )}
                </div>
                <div className=" row p-1  border text-muted">
                  <div className="col-10 mt-2 mb-2 fs-14 border-0">
                    Health Benifits
                  </div>
                  <div className="col-2 mt-2">
                    <i
                      class="fas fa-chevron-down"
                      onClick={(e) => setShow3(!show3)}
                    ></i>
                  </div>
                  {show3 == true && (
                    <>
                      <ul class="list-group ">
                        <li class="list-group-item border-none navv">
                          Tulsi Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          Ashwagandha
                        </li>
                        <li class="list-group-item border-none navv">
                          Darjiling Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          Tulsi Brahmi Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          View All
                        </li>
                      </ul>
                    </>
                  )}
                </div>
                <div className=" row p-1  border text-muted">
                  <div className="col-10 mt-2 mb-2 fs-14 border-0">
                    Best Sellers
                  </div>
                  <div className="col-2 mt-2">
                    <i
                      class="fas fa-chevron-down"
                      onClick={(e) => setShow4(!show4)}
                    ></i>
                  </div>
                  {show4 == true && (
                    <>
                      <ul class="list-group ">
                        <li class="list-group-item border-none navv">
                          Tulsi Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          Ashwagandha
                        </li>
                        <li class="list-group-item border-none navv">
                          Darjiling Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          Tulsi Brahmi Tea
                        </li>
                        <li class="list-group-item border-none navv">
                          View All
                        </li>
                      </ul>
                    </>
                  )}
                </div>

                {/* <div className='row p-1  border'>
       <div className='col-12 mt-2'>
           <select class='form-select mb-2 fs-14 border-0' >
                   <option selected>Herbs</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               </div>
          

       </div> */}

                {/* <div className='row p-1  border'>
       <div className='col-12 mt-2'>
           <select class='form-select mb-2 fs-6 border-0' >
                   <option selected>Health Benifits</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               </div>
      
       
        

       </div> */}
                {/* <div className='row p-1  '>
     <div className='col-12 mt-2'>
           <select class='form-select mb-2 fs-6 border-0' >
                   <option selected>Best Sellers</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               </div>
    
          

       </div> */}

                {/* <p className='pt-1 green-h-text fs-4'>Catagory</p>
               <select class='form-select mb-2' aria-label='Default select example'>
                   <option selected>Tulshi infusion</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <select class='form-select mb-2' aria-label='Default select example'>
                   <option selected>Body Care</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <select class='form-select mb-2' aria-label='Default select example'>
                   <option selected>Detox</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <select class='form-select mb-2' aria-label='Default select example'>
                   <option selected>Herbal Formulations</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <select class='form-select' aria-label='Default select example'>
                   <option selected>Packeged Food</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <hr />
               <select class='form-select' aria-label='Default select example'>
                   <option selected>Herbl</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <hr />
               <select class='form-select' aria-label='Default select example'>
                   <option selected>Health</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select>
               <hr />
               <select class='form-select' aria-label='Default select example'>
                   <option selected>Health Sellars</option>
                   <option value='1'>One</option>
                   <option value='2'>Two</option>
                   <option value='3'>Three</option>
               </select> */}
              </div>
              <div class="col-12 col-md-10 col-lg-9">
                <header>
                  <div className="row">
                    <div className="col-md-8 col-12">
                      <p className="fs-18 mt-2 ps-2 p--0">All products</p>
                    </div>
                    <div className="col-md-4 col-12">
                      <div class="d-flex align-items-center">
                        <h6
                          className="mt-2 col-7 col-md-5
                                                      f-HelveticaNeue-Light fs--1"
                        >
                          {" "}
                          SORT BY
                        </h6>
                        <select
                          class="form-select w-auto  col-12 pb-3 pt-3  fs_12 f-HelveticaNeue-Ligh "
                          aria-label="Default select example"
                          onChange={(e) => {
                            setValue(e.target.value);
                            onChangeFiltr(e.target.value);
                          }}
                        >
                          <option selected>Popularty</option>
                          <option value="1">Price Low to High</option>
                          <option value="2">Price High to Low</option>
                          <option value="3">Rating</option>
                        </select>
                      </div>
                    </div>
                    {/* <div className='hrrr mt-2'></div> */}
                  </div>
                </header>
                <div className=".b border mt-2 mb-2">
                  <section style={{ borderTop: "solid 3px #b39659" }}></section>
                </div>

                {/* <header class='d-flex justify-content-between align-items-center'>
                   <h6>All products</h6>
                   <div class='d-flex align-items-center'>
                       sort by
                       <select class='form-select w-auto ms-4' aria-label='Default select example'>
                           <option selected>Filter by</option>
                           <option value='1'>One</option>
                           <option value='2'>Two</option>
                           <option value='3'>Three</option>
                       </select>
                   </div>
               </header> */}
                <div className="containe">
                  <div className="row mt-2 mb-5">
                    {products &&
                      products.map((key, index) => (
                        <>
                          <div class="col-md-4 rahull cursor p-0 mb-4">
                            <div class="contentt ">
                              <Link to={`/productcart/:${key.prd_slug}`}>
                                <div class="contentt-overlay w-100 h-100 "></div>{" "}
                                <img
                                  src={key.media_file_path}
                                  class=" w-100 h-100 obg-fit contentt-image"
                                  data-box-shadow="0px 8px 6px -6px #d3cdcd"
                                  style={{ width: "50px", height: "50px" }}
                                />
                              </Link>
                              {/* <img class="contentt-image" src="https://images.unsplash.com/photo-1433360405326-e50f909805b3?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=359e8e12304ffa04a38627a157fc3362"/> */}
                              <div class="contentt-details fadeIn-bottom">
                                <h3 class="contentt-title mt-6">
                                  <button
                                    type="button"
                                    class=" btn_1  btn-warr rounded-1"
                                    onClick={() =>
                                      addToCart({
                                        id: key.id,
                                        quantity: 1,
                                        prd_title: key.prd_title,
                                        prd_mrp: key.prd_selling_price,
                                        media_file_path: key.media_file_path,
                                      })
                                    }
                                  >
                                    ADD TO CARD
                                  </button>
                                </h3>
                                <p class="contentt-text">
                                  <button
                                    type="button"
                                    class=" btn_1  ps-6 pe-6 green-h rounded-1"
                                  >
                                    BUY NOW
                                  </button>
                                </p>

                                {/* <p className="text-center m-0">
                                <span className="fs-16 text-dark">
                                  Price{" "}
                                </span>
                                <span className="fs-16 text-dark">
                                  <i className="las la-rupee-sign text-dark"></i>
                                  {key.prd_selling_price}
                                </span>
                              </p> */}
                              </div>
                            </div>
                            <p class="text-uppercase ls-4 text-dark-green text-center mt-3 mb-3 fs-14 f-w-600 title-wrap">
                              <Link to={`/productcart/:${key.prd_slug}`}>
                                {" "}
                                {key.prd_title}
                              </Link>
                            </p>
                            {/* <div class="img-box  position-relative product-box p-2">

                                                <div className=' 'style={{margin:"5px"}} >
                                                    <p class="text-uppercase ls-4 text-dark-green text-center mt-3 mb-3 f-0-7 title-wrap">{key.prd_title}</p>

                                                    <Link to={`/productcart/:${key.prd_slug}`} >   <img src={key.media_file_path} class="w-100 obg-fit" data-box-shadow="0px 8px 6px -6px #d3cdcd"  style={{width:"50px", height:"50px"}}/></Link>
                                                </div>

                                              
                                                <div className="position-relative">
                                                    <div className="price-block">
                                                        <div className="d-flex justify-content-between">
                                                            <button className="btn btn-1 btn-sm f-0-6 me-1 w-50 p-1"onClick={()=>addToCart({ id: key.id, quantity: 1, prd_title: key.prd_title,  prd_mrp: key.prd_selling_price , media_file_path: key.media_file_path})} >Add to Cart</button>

                                                            <button className="btn btn-1 btn-sm f-0-6 w-50 p-1" >Buy Now</button>
                                                        </div>

                                                        <p className="text-center m-0">
                                                            <span className='fs-12'>
                                                            ₹ </span>
                                                            <span className='fs-12'>
                                                                <i className="las la-rupee-sign"></i>{key.prd_selling_price}
                                                            </span>
                                                        </p>
                                                    </div>
                                                </div>
                                                
                                            </div> */}
                          </div>
                        </>
                      ))}
                  </div>

                  {/* <!-- border bottom --> */}
                  <div className=".b border mt-2 mb-2">
                    <section
                      style={{ borderTop: "solid 3px #b39659" }}
                    ></section>
                  </div>

                  {/*  <!-- pagination --> */}
                  <div class="ms-auto me-auto d-block w-fit-content mt-2 mb-5">
                    <ul class="pagination">
                      <li class="page-item  page-nav">
                        <a
                          class="page-link border-none"
                          href="#"
                          onClick={prevPage}
                        >
                          <i class="fa fa-angle-left"></i>
                        </a>
                      </li>
                      {navCount &&
                        navCount.map((key, index) => (
                          <li class="page-item ">
                            <a
                              class="page-link border-none"
                              href="#"
                              onClick={() => setCurrentPage(key)}
                            >
                              {key}
                            </a>
                          </li>
                        ))}
                      {/* <li class="page-item "><a class="page-link border-none" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link border-none" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link border-none" href="#">3</a></li> */}
                      <li class="page-item">
                        <a
                          class="page-link border-none page-nav"
                          href="#"
                          onClick={nextPage}
                        >
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                  {/* <!-- pagination --> */}
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </>
  );
};

export default ComboStore;

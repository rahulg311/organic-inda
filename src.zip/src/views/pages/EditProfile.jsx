import React from 'react'
import Loading from '../../components/Loading';
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';
import { notification } from '../../utils/notification';

const EditProfile = ({ history }) => {
	const {doPost } = usePost();
	const { user, getUserId, getUserToken } = useAuth();
	const [loading, setLoading] = React.useState(false);
	const handleSubmit = async (e) => {
		setLoading(true);
		e.preventDefault();

		if (!getUserToken()) {
			history.push('/login');
			return;
		}

		const headers = {
			headers: {
				'TOKEN-KEY': getUserToken(),
				id: getUserId(),
			},
		};
		const { user_full_name, user_email, user_mobile, password } = e.target;
		const data = {
			user_id: getUserId(),
			user_full_name: user_full_name.value,
			user_email: user_email.value,
			user_mobile: user_mobile.value,
			password: password.value,
		};

		const response = await doPost('update_profile', data, headers);
		if (response?.status == 'success') {
			const notify = notification({
				type: 'success',
				message: 'Profile updated successfully',
			});
			notify();

			const updatedUser = {
				...user,
				user_full_name: user_full_name.value,
				user_email: user_email.value,
				user_mobile: user_mobile.value,
			};
			localStorage.setItem('user', JSON.stringify(updatedUser));
			setLoading(false);
		} else {
			const notify = notification({
				title: 'error',
				message: 'Something went wrong',
			});
			notify();
			setLoading(false);
		}
	};

	return (
		<div className='w-md-lg2 p-2 mt-8 w-md mx-auto'>
			<div className='card p-4'>
				<div className='card-header mb-0 '>
					<h3 className='mb-0'>Edit Profile</h3>
				</div>
				<div className='card-body'>
					<form onSubmit={handleSubmit}>
						<div className='form-group mb-4'>
							<label class='form-label' htmlFor='name'>
								Name
							</label>
							<input
								type='text'
								className='form-control'
								id='name'
								name='user_full_name'
								defaultValue={user?.user_full_name}
							/>
						</div>
						<div className='form-group mb-4'>
							<label class='form-label' htmlFor='email'>
								Email address
							</label>
							<input
								type='email'
								className='form-control'
								id='email'
								aria-describedby='emailHelp'
								name='user_email'
								defaultValue={user?.user_email}
							/>
						</div>
						<div className='form-group mb-4'>
							<label class='form-label' htmlFor='phone'>
								Phone Nummber
							</label>
							<input
								type='number'
								className='form-control'
								id='phone'
								aria-describedby='emailHelp'
								name='user_mobile'
								defaultValue={user?.user_mobile}
							/>
						</div>
						<div className='form-group mb-4'>
							<label class='form-label' htmlFor='password'>
								Change Password
							</label>
							<input
								type='password'
								className='form-control'
								id='password'
								name='user_password'
								defaultValue={''}
							/>
						</div>
						<button ype='submit' className='btn w-100 mt-5 btn-success' disabled={loading}>
							{loading ? <Loading size='sm' /> : 'Edit'}
						</button>
					</form>
				</div>
			</div>
		</div>
	);
};

export default EditProfile

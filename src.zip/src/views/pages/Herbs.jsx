import React, { useState } from 'react'
import { useEffect } from 'react';
import API from '../../api'
import Loading from '../../components/Loading'

const Herbs = () => {
	const [loading, SetLoading] = useState(true);
	const [HarbsDetails, setHarbsDetails] = useState([]);


	const HerbsDetails = () => {
		SetLoading(true)
		let request = `herbs`
		API.get(request).then(data => {
			SetLoading(false)
			setHarbsDetails(data.data.data)
		}).catch((err) => {
			SetLoading(false)
		})

	}
	useEffect(() => {
		HerbsDetails()
	}, [])
	return (
		<div className=''>
			{/* <div className=' position-relative'>
					<img
						src='https://images.unsplash.com/photo-1506260408121-e353d10b87c7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1528&q=80'
						alt=''
						class='w-100 h-lg2'
					/>
					<h1 className='translate-center-middle text-white bg-dark bg-opacity-25 p-4 '>
						Our Herbs
					</h1>
				</div> */}
			<div className='row   banner-herb '>
				<div
					className=' col-md-12   d-flex justify-content-center height-220 h-420 align-items-center d-block optocity-b bg-dark  '

				>

					<h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4 '> <strong className='fs-w-25'>OUR  HERBS</strong> </h1>
				</div>
			</div>
			<div className='row' style={{ background: "url('assets/imgs/herbbg.png')", backgroundSize: "cover" }}>
				<div className='col-md-12'>
					<main class='container mt-5 '>
						<div className='row mb-2' >
							<div className='col-md-8 col-12'>
								<p className='fs-15 os-pagecontent-p '>
									Parag Agrawal is an Indian-American technology executive, and the chief executive
									officer of Twitter since November 2021. Agrawal joined Twitter as distinguished
									software engineer in 2011 and became the chief technology officer in 2017 Parag
									Agrawal is an Indian-American technology executive, and the chief executive officer
									of Twitter since November 2021.
								</p>
							</div>
						</div>
					</main>
				</div>
			</div>


			<div className='row'>
				<div className='col-md-12'>
					<img src=" /assets/imgs/hrr.png" alt="r" className='img-fluid ' />
				</div>
			</div>



			<div className='row' >
				<div className='col-md-12'>
					<main class='container  mb-5  '>
						<div class=''>
						<div className='text-center' >
								<p className='f-2-1 fs--22'>Explore Our Herbs</p>
								<p className='fs-6 text-muted fs--17' >View  on herb page by on an Image below.</p>
							</div>
						</div>

						<div className="container bg-white mt-5 m-top-15">

							<div className="row mb-1 ">
								{
									HarbsDetails &&

									HarbsDetails.map((key, index) => (
										<div className="col-md-3 mb-2 col-6">

											<img className="w-100 b-brown" src={key.herb_image} alt="1" />

										</div>

									))

								}

							</div>

						</div>


					</main>
				</div>
			</div>

			<div className='row gap-0'>

				<div className='col-md-5 pink-color d-flex justify-content-center  align-items-center '>
					<div className=" container w-75 w-xs-100 ">
						<div className='row  xs'>
							<div className='col-md-12'>
								<h3 className="text-white  font-bold mt-5  pt-5 pb-3 font-f display-5">Teas & Infusions </h3>
								<p className="text-white ">The holy basil plant is a small annual or short-lived perennial shrub, up to 1 metre (3.3 feet) in height. The stems are hairy and bear simple toothed or entire leaves oppositely along the stem. The fragrant leaves are green or purple, depending on the variety. The small purple or white tubular flowers have green or purple sepals and are borne in terminal spikes. The fruits are nutlets and produce numerous seeds. The holy basil plant is a small annual or short-lived perennial shrub, up to 1 metre (3.3 feet) in height.</p>
								{/* <div class="d-grid gap-2 col-md-7 col-12 mx-auto pb-5">
				<button class="btn btn-backround text-white  fs-18 mt-6" type="button">Shop Teas & Infusions</button>
			 </div> */}
								<button type="button" class="btn btn-outline-pink-color w-xs-100 fs-xs border-white ps-6 rounded-4 pe-6 fs-4 mt-5 pl-2 pr-2 mb-4  ms-1 text-white display-3">SHOP TULSI INFUSION</button>

							</div>
						</div>

					</div>
				</div>
				<div className='col-md-7 m-0 p-0'>

					<img src="assets/imgs/HERB.png" alt="" className=' w-100 h-100' />


				</div>
			</div>
			<section style={{ borderTop: 'solid 10px #b39659' }}></section>



			{/* <div class='container'>
					<div class='row gx-7 bg-secondary rounded-4  bg-opacity-25 mt-8 gy-md-0 gy-7 py-md-5'>
						<div class='col-md-6'>
							<h1 class='text-center'>Featured Herb :Tulsi</h1>
							<p>
								The holy basil plant is a small annual or short-lived perennial shrub, up to 1
								metre (3.3 feet) in height. The stems are hairy and bear simple toothed or
								entire leaves oppositely along the stem. The fragrant leaves are green or
								purple, depending on the variety. The small purple or white tubular flowers
								have green or purple sepals and are borne in terminal spikes. The fruits are
								nutlets and produce numerous seeds. The holy basil plant is a small annual or
								short-lived perennial shrub, up to 1 metre (3.3 feet) in height. The stems are
								hairy and bear simple toothed or entire leaves oppositely along the stem. The
								fragrant leaves are green or purple, depending on the variety. The small purple
								or white tubular flowers have green or purple sepals and are borne in terminal
								spikes. The fruits are nutlets and produce numerous seeds.
							</p>
						</div>
						<div class='col-md-6'>
							<img src='/assets/imgs/no-image.png' class='w-100 h-lg rounded-4'></img>
						</div>
					</div>
				</div> */}

		</div>
	);
}

export default Herbs

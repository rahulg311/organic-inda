import React from 'react';
import Loading from '../../../components/Loading';
import { Link } from 'react-router-dom';
import api from '../../../api'
import { useState } from 'react';
import { notification } from '../../../utils/notification';
import moment from 'moment';

const MyFile = () => {
   const getId = JSON.parse(localStorage.getItem('user'));
   const [name, setName] = useState(getId?getId.user_full_name:'')
   const [dob, setDob] = useState(getId?getId.dob:'')
   const [gender, setGender] = useState(getId?getId.gender:'')
   const [oldPassword, setOldPassword] = useState("")
   const [newPassword, setNewPassword] = useState("")
   const [confirmPassword, setConfirmPassword] = useState("")
   const [loading, setLoading] = useState(false)


   const UpdateProfileApi = () => {
      const getCartData = JSON.parse(localStorage.getItem('cart'));
      setLoading(true)
      let request = {
         url: 'update_profile',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { "name": name, "user_id": getId.id, "gender": gender, "dob": dob, }

      }
      api.postOtherApi(request).then(response => {
         setLoading(false)
         if (response.status == 200 && response.data.status == "success") {
            const notify = notification({
               type: 'success',
               message: response.data.message,
            });
            notify();

         } else {
            const notify = notification({
               type: 'error',
               message: "Date of Birth and Gender are required",
            });
            notify();
         }

      }).catch((err) => {
         const notify = notification({
            type: 'error',
            message: err.message,
         });
         notify();

      })
   }


   const ChangePasswordApi = () => {
      setLoading(true)
      let request = {
         url: 'changepssword',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { "old_password": oldPassword, "new_password": newPassword, "confirm_password": confirmPassword }

      }
      api.postOtherApi(request).then(response => {
         setOldPassword("")
         setNewPassword("")
         setConfirmPassword("")
         setLoading(false)
         if (response.status == 200 && response.data.status == "success") {

            const notify = notification({
               type: 'success',
               message: response.data.message,
            });
            notify();

         } else if (response.data.status == "error") {
            const notify = notification({
               type: 'error',
               message: response.data.error[0],
            });
            notify();
         }

         else {
            const notify = notification({
               type: 'error',
               message: response.data.error[0],
            });
            notify();
         }

      }).catch((err) => {
         const notify = notification({
            type: 'error',
            message: err.error[0],
         });
         notify();

      })
   }

   return (
      <>
      {
 getId ? <div className="">
 {
    loading && <Loading />
 }
 <div className='row border-color mt-4'>
    <div className='col-md-12'>
       <div className='container'>
          <div className="row ">
             <div className="col-md-9 col-6  ">
                <h4  className="  pt-4 f-HelveticaNeue-Light f-s-14">My Account </h4>
             </div>
             <div className="col-md-3 col-6 ">
                <h4 className=" pt-4  f-HelveticaNeue-Light f-s-14 ">home / <span className='green-h-text'>My Account</span></h4>
             </div>
          </div>
       </div>
    </div>
 </div>
 <div className='container'>
    <div className="row   whitec ">
       {/* slider 2 */}
       <div className="col-md-3 mt-5  whitec mb-2 ">
          <div className="row ">
             <div className="col-md-12 ">
                <ul class="nav flex-column ">
                   <li class="nav-item  ">

                      <Link class="nav-link green-h text-white " to={"./myaccount"}>Profile</Link>
                   </li>
                   <li class="nav-item">
                      <Link  class="nav-link f-s-12 " to={"./myorder"}>My Order</Link>
                   </li>
                   <li class="nav-item">
                      <Link  class="nav-link f-s-12 " to={"./myaddress"}>My Address</Link>

                   </li>
                   <li class="nav-item">
                      <Link  class="nav-link f-s-12 " to={"./mywallet"}>Wallet / Coupons</Link>

                   </li>
                </ul>
             </div>
          </div>
       </div>
       <div className="col-md-8 mt-2  mb-4">
          <div className="row  mt-4  bg-white">
             <div className="col-md-12">
                <div className="row pt-2 text-black  ">
                   <div className="col-md-12">
                      <h4 className=" text-danger f-HelveticaNeue-Light f-s-14"> For Corporate Offers. Please contact 9519000106</h4>
                      <hr />
                   </div>
                </div>

                <div className="row ">
                   <div className="col-md-6 ">
                      <h6  className="fs-14" >EDIT PROFILE</h6>

                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-2 pt-1 pt-1" for="name">Name:</label>
                         <div class="col-sm-8">
                            <input type="text" class="form-control" placeholder="Enter First Name" name="name" id="name" value={name} onChange={(e) => setName(e.target.value)} />

                         </div>
                      </div>
                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-2 pt-1" for="name">Email:</label>
                         <div class="col-sm-8">
                            <input type="email" class="form-control" placeholder="Enter Email" name="name" id="name" value={getId.user_email} />

                         </div>
                      </div>
                      <div class="row form-group mt-4">
                         <label class="control-label col-sm-2 pt-1">Mobile:</label>
                         <div class="col-sm-8">
                            <input type="text" class="form-control" placeholder="Enter Mobile No" name="name" id="name" value={getId.user_mobile} />

                         </div>
                      </div>
                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-2 pt-1" for="name">DOB:</label>
                         <div class="col-sm-8">
                            <input value={dob} type="date" class="form-control" placeholder="Enter First Name" name="dob" id="dob" onChange={(e) => setDob(e.target.value)} />
                            
                         </div>
                      </div>
                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-2" for="dob_day">Gender:</label>
                         <div class="col-sm-8">
                            <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" onChange={(e) => setGender("male")} checked={gender == "male" ? true : false} />
                               <label class="form-check-label" for="inlineRadio1">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                               <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" onChange={(e) => setGender("female")} checked={gender == "female" ? true : false} />
                               <label class="form-check-label" for="inlineRadio2">Female</label>
                            </div></div>
                      </div>


                      <div class="mt-1 mb-4">
                         <button onClick={() => UpdateProfileApi()} type="button" class="btn btn-outline-secondary rounded-0 ps-7 mt-3 pe-7 text-dark pl-5 pr-5 mt-4 border-2"> Save Change </button>
                      </div>
                   </div>
                   <div className="col-md-6  ">
                      <h6 className=" fs-14" >CHANGE PASSWORD</h6>
                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-5 pt-1 pt-1" for="name">Old Password:</label>
                         <div class="col-sm-7">
                            <input type="password" class="form-control" placeholder="Enter Old Password" name="name" id="name" onChange={(e) => setOldPassword(e.target.value)} value={oldPassword} />

                         </div>
                      </div>
                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-5 pt-1" for="name">New Password:</label>
                         <div class="col-sm-7">
                            <input type="Password" class="form-control" placeholder="Enter New Password" name="name" id="name" onChange={(e) => setNewPassword(e.target.value)} value={newPassword} />

                         </div>
                      </div>
                      <div class="row form-group mt-2">
                         <label class="control-label col-sm-5 pt-1" for="name">Confirm Password:</label>
                         <div class="col-sm-7">
                            <input type="password" class="form-control" placeholder="Enter Confirm Password" name="name" id="name" onChange={(e) => setConfirmPassword(e.target.value)} value={confirmPassword} />

                         </div>
                      </div>
                      <button onClick={() => ChangePasswordApi()} type="button" class="btn green-h text-white border-2 rounded-0 ps-5 mt-2 pe-5 text-dark pl-5 pr-5  ">Change Password</button>
                   </div>
                </div>
                {/* 
            <div class="d-grid gap-2 col-12 text-center mx-auto mt-4 mb-4">
               <button class="btn btn-success" type="button" onClick = {(e) => this.pushPage(e)}>CONTINUE CHECKOUT </button>
            </div>
            */}
             </div>
          </div>
       </div>
    </div>
 </div>
</div>:window.location.href = "/login"
 
      }
     
     
      
      </> );
};

export default MyFile;

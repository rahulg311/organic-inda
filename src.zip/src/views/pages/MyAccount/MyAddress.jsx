
import React from 'react';
import useAuth from "../../../hooks/useAuth";
import { Link } from 'react-router-dom';
import usePost from '../../../hooks/usePost';
import { useState } from 'react';
import api from '../../../api';
import { notification } from '../../../utils/notification';
import { useEffect } from 'react';

const MyAddress = () => {
   const { getUserToken, getUserId } = useAuth();
   const getId = JSON.parse(localStorage.getItem('user'));
   const { response, isLoading, error, doPost } = usePost();
   const [firstName, setFastName] = useState("")
   const [lastName, setLastName] = useState("")
   const [address, setAddress] = useState("")
   const [address_line_2, setAddress2] = useState("")
   const [pincode, setPincode] = useState("")
   const [statevalue, setStates] = useState("")
   const [stateId , setStateId]= useState('')
   const [ cityId , setCityId]= useState('')
   const [city, setCity] = useState("")
   const [phone, setPhone] = useState("")
   const [gst_number, setGstNumber] = useState("")
   const [addressList, setAddressList] = useState([])
   const [addressId, setAddressId] = useState("")
   const [editbtn, setEditbtn] = useState(false)
   const [getState, setGetState] = useState([])
   const [getCity, setGetCity]= useState()

   const onSelectState = () =>{
      CityApi(document.getElementById("Select_State").value);
  }
  const onSelectCity = () =>{
   setCity(document.getElementById("Select_City").value);
  
}
   const StateApi = () =>{
      let request = `get_states`
      api.get(request).then(data => {
          setGetState(data.data.data)
      }).catch((err) => {
      })

  }

  const CityApi = (cid) =>{
   setStates(cid)
   let request = `get_cities?state_id=${cid}`
   api.get(request).then(data => {
       setGetCity(data.data.data)
       
   }).catch((err) => {
   })
  }
   
   const AddressLstApi = () => {
      let request = {
         url: 'get_address',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { user_id: getId.id }

      }
      api.postOtherApi(request).then(response => {
         if (response.status == 200 && response.data.status == "success") {
            setAddressList(response.data.data)
            // const notify = notification({
            //    type: 'success',
            //    message: "Successfully",
            // });
            // notify();

         } else {
            const notify = notification({
               type: 'error',
               message: response.data.message,
            });
            notify();
         }

      })

   }

   const editAdd = (key) => {
      setEditbtn(true)
      setFastName(key.first_name)
      setLastName(key.last_name)
      setAddress(key.address_line_1)
      setAddress2(key.address_line_2)
      setPincode(key.pincode)
      setStates(key.state_id)
      CityApi(key.state_id)
      setCity(key.city_id)
      setPhone(key.mobile)
      setGstNumber(key.gst)
      setAddressId(key.address_id)
      // setCityId(key.city_id)
      // setStateId(key.state_id)
   }

   const UPdateAddressApi = () => {
      let request = {
         url: 'updateaddress',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { "first_name": firstName, "last_name": lastName, "address": address, "address_line_2": address_line_2, "pincode": pincode, "state": statevalue, "city": city, "phone": phone, "gst_number": gst_number, "address_id": addressId }

      }
      api.postOtherApi(request).then(response => {
         if (response.status == 200 && response.data.status == "success") {
            const notify = notification({
               type: 'success',
               message: response.data.message,
            });
            notify();
            window.location.reload();


         } else {
            const notify = notification({
               type: 'error',
               message: response.data.message,
            });
            notify();
         }

      })
   }


   const EditAddressApi = () => {
      let request = {
         url: 'editaddress',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { "user_id": getId.id, "address_id": addressId }

      }
      api.postOtherApi(request).then(response => {
         if (response.status == 200 && response.data.status == "success") {
            const notify = notification({
               type: 'success',
               message: response.data.message,
            });
            notify();

         } else {
            const notify = notification({
               type: 'error',
               message: response.data.message,
            });
            notify();
         }

      })
   }
   const deleteAddressApi = (id) => {
      let request = {
         url: 'deleteaddress',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { "user_id": getId.id, "address_id": id }

      }
      api.postOtherApi(request).then(response => {
         if (response.status == 200 && response.data.status == "success") {
            const notify = notification({
               type: 'success',
               message: response.data.message,
            });
            notify();
            window.location.reload();

         } else {
            const notify = notification({
               type: 'error',
               message: response.message,
            });
            notify();
         }
      })
   }
   const AddAddressApi = () => {

      let request = {
         url: 'add_address',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { "first_name": firstName, "last_name": lastName, "address": address, "address_line_2": address_line_2, "pincode": pincode, "state": statevalue, "city": city, "phone": phone, "gst_number": gst_number }

      }
      api.postOtherApi(request).then(response => {
         if (response.status == 200 && response.data.status == "success") {
            window.location.reload();
            const notify = notification({
               type: 'success',
               message: response.data.message,
            });
            notify();

         } 
         else if(response.data.status == "error"){
            const notify = notification({
               type: 'error',
               message: response.data.error[0],
            });
            notify();
         }
         
         
         else {
            const notify = notification({
               type: 'error',
               message: response.data.message,
            });
            notify();
         }

      })
   }

   useEffect(() => {
      StateApi()
      AddressLstApi()
   }, []);

  

   return (
      <div className="">
         <div className='row border-color mt-7'>
            <div className='col-md-12'>
               <div className='container'>
                  <div className="row ">
                     <div className="col-md-9  ">
                        <h4 className="  pt-4 f-HelveticaNeue-Light">My Account </h4>
                     </div>
                     <div className="col-md-3 ">
                        <h4 className=" pt-4  f-HelveticaNeue-Light ">home / <span className='green-h-text'>My Account</span></h4>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div className='container'>
            <div className="row   whitec ">
               {/* slider 2 */}
               <div className="col-md-3 mt-5  whitec mb-5 m-4">
                  <div className="row ">
                     <div className="col-md-12 ">
                        <ul class="nav flex-column ">
                           <li class="nav-item  ">

                              <Link class="nav-link  " to={"./myaccount"}>Profile</Link>
                           </li>
                           <li class="nav-item">
                              <Link class="nav-link " to={"./myorder"}>My Order</Link>
                           </li>
                           <li class="nav-item">
                              <Link class="nav-link green-h text-white " to={"./myaddress"}>My Address</Link>

                           </li>
                           <li class="nav-item">
                              <Link class="nav-link  " to={"./mywallet"}>Wallet / Coupons</Link>

                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div className="col-md-8 m-4">
                  <div className="row border mt-4  bg-white">
                     <div className="col-md-12">
                        <div className="row pt-2 text-black  border">
                           <div className="col-md-12">
                              <h4 className="p-2 text-danger f-HelveticaNeue-Light"> For Corporate Offers. Please contact 9519000106</h4>
                           </div>
                        </div>
                        <div className="row mt-4 mb-4">
                           <div className="col-md-5">
                              <h6 className="pb-4 fs-14" > Your Save Address</h6>
                              <div className="row">
                                 
                                    {
                                       addressList && addressList.map((key, index) => (
                                          <div className="col-md-12 col-12 mb-2">
                                             <div className='card'>
                                                <div className='card-body'>
                                                   <h5 className="m-0">{key.first_name} {key.last_name}</h5>
                                                   <p className='m-0  fs-12'>Address: {key.address_line_1},{key.city_name},{key.state_name},{key.pincode} </p>
                                                   {key.address_line_2  && <p className='m-0 fs-12'>Address Line 2:{key.address_line_2},{key.city_name},{key.state_name},{key.pincode} </p>} 
                                                   <p className='m-0  fs-12'>Mobile No: {key.mobile}</p> 
                                                   {key.gst && <p className='m-0 fs-12'>GST-No {key.gst}</p>}
                                                   <button style={{width:"50px", fontSize:"11px",marginTop:"5px", marginRight:"5px"}} type="button" class="btn btn-success text-white p-1 mr-2" onClick={() => editAdd(key)}>Edit</button>
                                                   <button style={{width:"70px", fontSize:"11px",marginTop:"5px"}} type="button" class="btn  btn-danger text-white p-1 " onClick={() => deleteAddressApi(key.address_id)}>Delete</button>
                                                </div>
                                             </div>
                                          </div>

                                       ))
                                    }
                                   
                              </div>
                           </div>


                           <div className="col-md-7">
                              <h6 className="pb-4 fs-14" >New Address?</h6>
                              <div className='card'>
                                 <div className='card-body'>
                                 <div className="row ">
                                 <div className="col-md-6 col-12 mt-2">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Enter Name" onChange={(e) => setFastName(e.target.value)} value={firstName} />
                                 </div>
                                 <div className="col-md-6 col-12  mt-2">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Last Name" onChange={(e) => setLastName(e.target.value)} value={lastName} />
                                 </div>
                              </div>
                              <div className="row ">
                                 <div className="col-md-12 col-12 mt-2">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Enter Address" onChange={(e) => setAddress(e.target.value)} value={address} />
                                 </div>
                                 <div className="col-md-12 col-12 mt-2">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder=" Address line 2..." onChange={(e) => setAddress2(e.target.value)} value={address_line_2} />
                                 </div>

                              </div>

                              <div className="row ">
                                 <div className="col-md-4 col-12 mt-2">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Pin Code" onChange={(e) => setPincode(e.target.value)} value={pincode} />
                                 </div>
                                 <div className="col-md-4 col-12 mt-2">
                                    {/* <div  style={{width:"30px"}} > */}
                                    <select  id="Select_State" className='form-control '  onChange={onSelectState} value={statevalue} >
                                    <option >Select State</option>
                                       {
                                          
                                          getState&& getState.map((key, index)=>(
                                             <option value={key.id} >{key.state_name}</option>
                                          ))
                                       }
                                   

                                      

                                    </select>
                                    {/* <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Select state" onChange={(e) => setStates(e.target.value)} value={state} /> */}
                                 </div>
                                 <div className="col-md-4 col-12 mt-2">
                                    <select  id="Select_City" className='form-control ' onChange={onSelectCity} value={city} >
                                    <option>Select city</option>
                                       { getCity && getCity.map((key, index)=>(
                                          <option value={key.id} >{key.city_name}</option>
                                       ))}
                                    </select>
                                    {/* <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="City" onChange={(e) => setCity(e.target.value)} value={city} /> */}
                                 </div>
                              </div>
                              <div className="row " >
                                 <div className="col-md-6 col-12 mt-2 ">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Enter Mobile No" onChange={(e) => setPhone(e.target.value)} value={phone} />
                                 </div>
                                 <div className="col-md-6 col-12 mt-2">
                                    <input type="text" id="inputPassword6" class="form-control " aria-describedby="passwordHelpInline" placeholder="Enter GST Number" onChange={(e) => setGstNumber(e.target.value)} value={gst_number} />
                                 </div>
                              </div>

                              <p className='text-danger fs-14 mt-3 mb-2'>Note : In case of Wrong GST NUMBER.Order to be treated as B2C.</p>
                              {
                                 editbtn ? <button onClick={() => UPdateAddressApi()} type="button" class="btn btn-outline-success  pl-5 pr-5 mt-4 ">Edit Address</button> :
                                    <button onClick={() => AddAddressApi()} type="button" class="btn btn-outline-success  pl-5 pr-5 mt-4 ">Save Address</button>
                              }
                                 </div>
                              </div>

                           </div>
                        </div>
                        {/* 
      <div class="d-grid gap-2 col-12 text-center mx-auto mt-4 mb-4">
         <button class="btn btn-success" type="button" onClick = {(e) => this.pushPage(e)}>CONTINUE CHECKOUT </button>
      </div>
      */}
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
};

export default MyAddress;

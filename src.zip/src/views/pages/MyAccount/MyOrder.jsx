import React from 'react';
import Loading from '../../../components/Loading';
import { Link } from 'react-router-dom';
import api from '../../../api';
import { useState } from 'react';
import { notification } from '../../../utils/notification';

const MyOrder = () => {
   const getId = JSON.parse(localStorage.getItem('user'));
   const [orderData, setOrderData] = useState([]);
   const [loading, setLoading] = useState(false)
   const [comment, setComment] = useState("")
   const [rat, setRating] = useState('')
   const [podId, setProdId] = useState("")

   const ReviewApi = () => {
      let request = {
         url: 'save_product_rating',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { product_id: podId, start_rating: rat, comment: comment }
      }
      setLoading(true)
      api.postOtherApi(request).then(response => {
         setLoading(false)
         if (response.status == 200 && response.data.status == "success") {
            const notify = notification({
               type: 'success',
               message: response.data.msg,
            });
            notify();
         }
      })
   }

   const OrderLstApi = () => {
      let request = {
         url: 'orderdetails',
         headers: {
            "TOKEN-KEY": getId.remember_token,
            "id": getId.id
         },
         data: { user_id: getId.id }

      }
      setLoading(true)
      api.postOtherApi(request).then(response => {
         setLoading(false)
         if (response.status == 200 && response.data.status == "success") {
            setOrderData(response.data.data)
         }
      })


   }

   React.useEffect(() => {
      OrderLstApi()
   }, []);
   return (<>
      <div className="">
         {
            loading && <Loading />
         }
         <div className='row border-color mt-4'>
            <div className='col-md-12'>
               <div className='container'>
                  <div className="row ">
                     <div className="col-md-9  col-6 ">
                        <h4 className="  pt-4 f-HelveticaNeue-Light f-s-14">My Account </h4>
                     </div>
                     <div className="col-md-3 col-6 ">
                        <h4 className=" pt-4  f-HelveticaNeue-Light f-s-14 ">Home / <span className='green-h-text'>My Account</span></h4>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div className='container '>

            {/* slider 2 */}
            <div className='row whitec'>
            <div className="col-md-3 mt-5  whitec mb-5 ">
         <div className="row ">
            <div className="col-md-12 ">
            <ul class="nav flex-column ">
                  <li class="nav-item  ">
                      
                     <Link class="nav-link f-s-12 " to={"./myaccount"}>Profile</Link>
                  </li>
                  <li class="nav-item">
                     <Link class="nav-link green-h text-white f-s-12" to={"./myorder"}>My Order</Link>
                  </li>
                  <li class="nav-item">
                  <Link class="nav-link f-s-12" to={"./myaddress"}>My Address</Link>
                    
                  </li>
                  <li class="nav-item">
                  <Link class="nav-link f-s-12 " to={"./mywallet"}>Wallet / Coupons</Link>
                   
                  </li>
               </ul>
            </div>
         </div>
      </div>
               <div className="col-md-9">
                  <div className="col-md-12 orderdataset">
                     <div className="row p-2">
                        <div className="col-xs-2 col-md-2"><b>Order ID</b></div>
                        <div className="col-xs-2 col-md-2"><b>Date Placed</b></div>
                        <div className="col-xs-2 col-md-2"><b>Order status</b></div>
                        <div className="col-xs-2 col-md-2"><b>Items</b></div>
                        <div className="col-xs-2 col-md-2"><b>Total</b></div>
                        <div className="col-xs-2 col-md-2 text-right"><b>Details</b></div>
                     </div>
                  </div>
                  <div class="accordion" id="accordionExample" style={{ padding: 0 }}>
                     {
                        orderData && orderData.map((key, index) => (
                           <>
                              <div class="accordion-item">
                                 <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target={"#collapseOne" + index} aria-expanded="true" aria-controls={"#collapseOne" + index} style={{ borderRadius: 0 }}>
                                       <div class="row" style={{ background: "none", border: 0 }}>
                                          <div class="col-xs-2 col-md-2" style={{ width: "100px" }}><b>{key.order_id}</b></div>
                                          <div class="col-xs-2 col-md-2" style={{ width: "125px" }}><b>{key.order_date}</b></div>
                                          <div class="col-xs-2 col-md-2" style={{ width: "165px" }}><b>{key.order_status}</b></div>
                                          <div class="col-xs-2 col-md-2" style={{ width: "130px" }}><b>{key.items}</b></div>
                                          <div class="col-xs-2 col-md-2" style={{ width: "100px" }}><b>₹{key.total_amount}</b></div>
                                          {/* <div class="col-xs-2 col-md-2"><b>Details</b></div> */}

                                       </div>



                                    </button>
                                 </h2>
                                 <div id={"collapseOne" + index} class="accordion-collapse collapse mb-2" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                       <div class="row" style={{ background: 0, border: 0 }}>
                                          <div class="col-xs-2 col-md-2"><b>Image</b></div>
                                          <div class="col-xs-2 col-md-2" style={{ width: "180px" }}><b>Name</b></div>
                                          <div class="col-xs-2 col-md-2"><b>Qty</b></div>
                                          <div class="col-xs-2 col-md-2"><b>Unit price</b></div>
                                          <div class="col-xs-2 col-md-2"><b>Total Amount </b></div>
                                       </div>
                                       {
                                          key.orders_details &&
                                          key.orders_details.map((key, index) => (
                                             <div class="row mb-3" style={{ background: 0, border: 0 }}>
                                                <div class="col-xs-2 col-md-2"><img style={{ height: "45px", width: "40px" }} src={key.image_path} /></div>
                                                <div class="col-xs-2 col-md-2" style={{ width: "180px" }}>{key.title}</div>
                                                <div class="col-xs-2 col-md-2">{key.qty}</div>
                                                <div class="col-xs-2 col-md-2">₹ {key.unit_price}</div>
                                                <div class="col-xs-3 col-md-3" style={{ display: "flex", flexDirection: "row" }}><span>₹ {key.total_price} </span> <button onClick={() => { setProdId(key.product_id); setComment(""); setRating(0) }} type="button" class=" bg-info  text-white border-0 " data-bs-toggle="modal" data-bs-target="#staticBackdrop" style={{ height: "25px", marginLeft: "15px" }} >Review</button></div>

                                             </div>
                                          ))
                                       }
                                    </div>
                                    <div style={{ display: "flex", flexDirection: "row", justifyContent: "space-between" }}>
                                       <div style={{ height: "fit-content", background: "#f0f2f5", width: "30%", padding: 10 }}>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Shiping Address:</p>
                                          <p style={{ fontSize: "12px", fontWeight: "normal" }}>{key.address_line_1}</p>
                                       </div>
                                       <div style={{ height: "fit-content", background: "#f0f2f5", width: "30%", padding: 10 }}>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Billing Address:</p>
                                          <p style={{ fontSize: "12px", fontWeight: "normal" }}>{key.pincode},{key.city_name} ,{key.state_name}, {key.country_name}</p>
                                       </div>
                                       <div style={{ background: "#f0f2f5", width: "30%", padding: 10, display: "flex", flexDirection: "column", justifyContent: "right" }}>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Total Item Prices: ₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.total_amount}</span></p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Shipping:₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.shipping}</span></p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Payment Mode: <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.payment_mode}</span></p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Express Delivery:₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.express_delivery}</span> </p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Cod:₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.cod}</span></p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Discount:₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.discount}</span></p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Reward Points:₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.reward_points}</span></p>
                                          <p style={{ fontSize: "12px", fontWeight: "bold" }}>Total Payment:₹ <span style={{ fontSize: "12px", fontWeight: "normal" }}>{key.total_amount}</span> </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>





                           </>

                        ))
                     }
                  </div>

                  {
                     orderData.length < 0 &&
                     <div className="col-md-12">
                        <p className="text-center">No Order Found !</p>
                     </div>
                  }
               </div>
            </div>

         </div>

      </div>


      <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
               {/* <div class="text-right cross float-right" >
                <i class="fa fa-times mr-2"></i> </div> */}
               <div className='modal-header'>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
               </div>
               {/* <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> */}
               <div class="card-body text-center"> <img src=" https://i.imgur.com/d2dKtI7.png" height="100" width="100" />
                  <div class="comment-box text-center">
                     <h4>Add a comment</h4>
                     <div class="rating">
                        <input type="radio" name="rating" checked={rat == 5 ? true : false} value={rat} onClick={() => setRating(5)} id="5" />
                        <label for="5"></label>
                        <input type="radio" name="rating" checked={rat == 4 ? true : false} value={rat} onClick={() => setRating(4)} id="4" />
                        <label for="4"></label> <input type="radio" name="rating" checked={rat == 3 ? true : false} value={rat} onClick={() => setRating(3)} id="3" />
                        <label for="3"></label> <input type="radio" name="rating" checked={rat == 2 ? true : false} value={rat} onClick={() => setRating(2)} id="2" />
                        <label for="2"></label> <input type="radio" name="rating" checked={rat == 1 ? true : false} value={rat} onClick={() => setRating(1)} id="1" />
                        <label for="1"></label> </div>
                     <div class="comment-area"> <textarea onChange={(e) => setComment(e.target.value)} value={comment} class="form-control" placeholder="what is your view?" rows="4"></textarea> </div>
                     <div class="text-center mt-4"> <button class="btn btn-success send px-5" data-bs-dismiss="modal" onClick={() => ReviewApi()}>Send Reviews <i class="fa fa-long-arrow-right ml-1"></i></button> </div>
                  </div>
               </div>
            </div>
         </div>
      </div>

   </>);
};

export default MyOrder;

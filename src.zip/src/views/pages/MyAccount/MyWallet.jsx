import React from 'react';
import Loading from '../../../components/Loading';
import { Link } from 'react-router-dom';
import { NavLink } from 'react-router-dom';

const MyWallet = () => {
	return (
      <div className="">
           <div className='row border-color mt-7'>
              <div className='col-md-12'>
           <div className='container'>
        <div className="row ">
           <div className="col-md-9  ">
              <h4 className="  pt-4 f-HelveticaNeue-Light">My Account </h4>
           </div>
           <div className="col-md-3 ">
              <h4 className=" pt-4  f-HelveticaNeue-Light ">home / <span className='green-h-text'>My Account</span></h4>
           </div>
        </div>
        </div>
        </div>
        </div>
        <div className='container'>
        <div className="row   whitec ">
           {/* slider 2 */}
           <div className="col-md-3 mt-5  whitec mb-5 m-4">
              <div className="row ">
                 <div className="col-md-12 ">
                 <ul class="nav flex-column ">
                       <li class="nav-item  ">
                           
                          <Link class="nav-link  " to={"./myaccount"}>Profile</Link>
                       </li>
                       <li class="nav-item">
                          <Link class="nav-link " to={"./myorder"}>My Order</Link>
                       </li>
                       <li class="nav-item">
                       <Link class="nav-link " to={"./myaddress"}>My Address</Link>
                         
                       </li>
                       <li class="nav-item">
                       <Link class="nav-link green-h text-white " to={"./mywallet"}>Wallet / Coupons</Link>
                        
                       </li>
                    </ul>
                 </div>
              </div>
           </div>
        
              <div class="col-sm-6   mt-7 mb-7 profile_edit">
			<div class="profile_edit_div">
				<p className='fs-14'>Total Remain ₹ (Valid till 31 March 2022)</p>
            <h4 className='green-h-text' >0 ₹</h4>
				<br/>
				<p className='fs-14'>Total Credit ₹</p>
				<h4 className='green-h-text' >0 ₹</h4>

				<p className='fs-14'>Total Debit ₹</p>
				<h4 className='green-h-text'>0 ₹</h4><hr/>
				
				*Note:You can use 10% of wallet points per order.
			</div>
			
		</div>
              </div>
           </div>
        </div>
       
	);
};

export default MyWallet;

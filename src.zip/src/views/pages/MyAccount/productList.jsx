import React from "react"


const ProductList = (props) => {

    return (<>
        <div style={{ position: "fixed", height: "100vh", width: "100%", background: "gray", opacity: 1.0, top: 0, left: 0, alignItems: "center", justifyContent: "center", display: "flex", zIndex: "2" }}>
            <div style={{ display: "flex", flexDirection: "column", position: "absolute", background: "white", height: "70vh", width: "80%" }}>
                { props.data&& props.data.map((key,index)=>(<>
                    <div style={{ display: "flex", flexDirection: "row", justifyContent:"space-between", padding:15 }}>
                    <div style={{ display: "flex", flexDirection: "column" ,justifyContent:"space-between" }}>
                        <p>{key.title}</p>
                       {/* <img src={}/> */}
                    </div>
                    <div>
                        <p>Name</p>
                        <p></p>
                    </div>
                    <div>
                        <p>quantity</p>
                    </div>
                    <div>
                        <p> unit prise</p>
                    </div>
                    <div>
                        <p>total prise</p>
                    </div>

                </div>
                </>

                ))
                  }
                <div>

                </div>
            </div>
        </div>

    </>)
}

export default ProductList;
import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import checkmark from '../../assets/check-mark.png';

const OnlineThankyou = () => {
    const  currentUrl = window.location.href;
    const [ Ordid , setOrdId ] =useState("")
    useEffect(() => {
      setOrdId(currentUrl.split('=').pop())
        window.localStorage.removeItem('cart');

    }, []);

    return (
       
        <div className='row justify-content-center m-8'>

            <div className='col-sm-3 border text-center'>
              <img style={{height:"80px", width:"80px"}} src={checkmark}/>

                <h1 > Thank  You !</h1>
                <h4> Your payment is successfully !</h4>
                <h5>your order id  #{Ordid} </h5>
               

                <NavLink to="/" className="btn btn-outline-success btn-sm mt-2 mb-2"><i className="fa fa-arrow-left"></i> Go Back to Home</NavLink>
            </div>

        </div>
       

    );
};


export default OnlineThankyou;


import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const AbouttheCompany = () => {
   
    return (
        
        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>
               
      
                {/* <div class=" ourstory-title blue-gray">
    <div class="container">
        <div class="row pt-2 pb-2 ">
            <div class="col-md-9">
                <span className='fs-30  Whitney-Medium'>
                   Our Story
                </span>
            </div>
            <div class="col-md-3" align="right">
              
            </div>
        </div>
    </div>
</div> */}
<div className='row green-h'>
    <div className='col-12'>

    
    <div className='container '>
<nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
<a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon float-end fs-15"></span>
    </button>
  <div class="container-fluid green-h col-12">
   
    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
      <div class=" green-h w-100 ">
      <ul class="nav d-flex justify-content-around green-h">
                    <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                    <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class="nav-res green-h "><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
      </div>
    </div>
  </div>
 
</nav>
{/* <div className=' row  p-3'>
<div class="col-12" >
<ul class="nav d-flex justify-content-around">
                    <li class="active "><Link className='text-white' to="/aboutthecompany">About Us</Link></li>
                    <li class=""><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class=""><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class=""><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class=""><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
            </div>
</div> */}


</div>
</div>
</div>



<div class=" ourstory ">
    {/* <nav class="">
        <div class="">
          
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav ourstorynav d-flex">
                    <li class="active"><a href="https://www.organicindia.com/about-the-company">About Us</a></li>
                    <li class=""><a href="https://www.organicindia.com/meet-the-farmers">Meet the Farmers</a></li>
                    <li class=""><a href="https://www.organicindia.com/consciousness-in-action">Consciousness in Action</a></li> 
                    <li class=""><a href="https://www.organicindia.com/regenerative-agriculture">Regenerative Agriculture</a></li> 
                    <li class=""><a href="https://www.organicindia.com/whole-herb">Whole Herb</a></li> 
                </ul>   
            </div>
        </div>
    </nav> */}
    <div className='row h-420  height-220   '  style={{background:"url('https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg')", backgroundSize:"cover"}}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25' >OUR STORY</strong> </h1>
                        </div>
                    </div>
        {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
    </div>
    <div class="px-10 pxx-5 os-pagecontent" id="showcurrentversion">
    <div class="col-md-12 ourstorypagenav">
        <Link to="/ourstory" class="btn btn-default aboutusinnerbutton " role="button">Vision &amp; Mission</Link>
        <Link to="/aboutthecompany" class="btn btn-default aboutusinnerbutton active " role="button">About the Company</Link>
        <Link to="/organic" class="btn btn-default aboutusinnerbutton" role="button">Organic And Quality Certifications</Link>
        
        <Link to="contect" class="btn btn-default aboutusinnerbutton" role="button">Contact Us</Link>
        {/* <Link to="#" class="btn btn-default aboutusinnerbutton" role="button">Press/News</Link> */}
     </div>
     <div class="row mt-4">
<div class="col-md-12">
<h1 className='f-s-18'><b>About the Company</b></h1>
</div>
</div>
     <div class="row mt-1">
<div class="col-md-9">
<p className='f-s-14'>At the heart of <b>ORGANIC INDIA</b> is our commitment to be a living embodiment of love and consciousness in action. We work with thousands of small family farmers in India to cultivate tens of thousands of acres of sustainable organic farmland.</p>

<p className='f-s-14'>All <b>ORGANIC INDIA</b> products support health and True Wellness and are made with loving care. Each product is one link in a chain of connectedness between Mother Nature, our farmers and you. By choosing ORGANIC INDIA you are completing this chain, actively participating in our mission to create a sustainable environment of True Wellness, providing training and a life of dignity to our farmers, and bringing health, happiness and True Wellness to you.</p>

<p className='f-s-14'>All of our farmers and tribal wildcrafters are educated in organic and biodynamic agricultural practices. We pay all the fees associated with acquiring the necessary organic certifications for them, and then we purchase the harvested crops and herbs at a premium market price. The farmers also rotate between growing crops on their land for <b>ORGANIC INDIA</b> with food crops for themselves. This means farming families are supported by a sustainable income, while at the same time improving and preserving their own health and natural environment.</p>
</div>


<div class="col-md-3 m-t-nagative"><img class="img-responsive v" src="https://www.organicindia.com/media/cms/Farmer-Right.jpg" /></div>
</div>
<div class="row  mt-2">
<div class="col-md-12">
<p className='f-s-14'><b>ORGANIC INDIA </b>is committed to being a trustworthy and innovative global leader by providing genuine True Wellness products. Our advanced processing methods and dehydration technologies ensure that our herbs retain their maximum level of potency for the highest quality, most effective, pure and natural True Wellness products available in the market today. Our success serves as living proof that shared abundance can be created with an uncompromising commitment to environmental and social responsibility. In living this vision, we are inspired to introduce a new standard for new paradigm companies:</p>
</div>
</div>
<div class="row mt-2">
<div class="col-md-9">
<p className='f-s-14'><b>ORGANIC INDIA</b> is proud to announce its partnership with FabIndia, India's largest private retail platform for craft-based products. FabIndia sources from rural artisans across the country to bring a range of lifestyle products to customers around the world. Besides a distinctive range of clothing and products for your home, FabIndia offers you choices for a complete organic lifestyle with its range of organic and natural foods.</p>
</div>

<div class="col-md-3"><img class="img-responsive" src="https://www.organicindia.com/media/cms/fabindialogo.png"/></div>
</div>
       
    <br/>      
</div>









                  
          
               
            </div>
        </div>
       );
};

        export default AbouttheCompany;




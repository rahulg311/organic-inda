
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const Consciousness = () => {

    return (

        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>



                <div className='row green-h'>
                    <div className='col-12'>


                        <div className='container '>
                            <nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
                                <a class="navbar-brand" href="#"></a>
                                <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon float-end fs-15"></span>
                                </button>
                                <div class="container-fluid green-h col-12">

                                    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
                                        <div class=" green-h w-100 ">
                                            <ul class="nav d-flex justify-content-around green-h">
                                                <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                                                <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/regenerative">Regenerative Agriculture</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </nav>


                        </div></div>
                </div>


                <div class=" ourstory ">

                    <div className='row h-420   height-220  ' style={{ background: "url(https://www.organicindia.com/media//cms/banner/consciousness-inaction.jpg)", backgroundSize: "cover" }}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25'>CONSCIOUSNES IN ACTION</strong> </h1>
                        </div>
                    </div>
                    {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
                </div>
                <div class="px-10 pxx-5 os-pagecontent mt-3">

                    <div class="col-md-12">
                        <h1><b className='f-s-18'>Consciousness In Action</b></h1>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div className='row'>
                                <div class="col-md-7 col-12">
                                    <p className='f-s-14'>At the heart of ORGANIC INDIA is our commitment to be a living embodiment of love and consciousness in action. We work with several small family farmers across India to cultivate thousands of acres of sustainable organic farmland. Each product of <b>ORGANIC INDIA</b> is one link in a chain of inter-connectedness - a chain between Mother Nature, our farmers and you.</p>

                                    <p className='f-s-14'>We operate from a place of inter-connectedness and oneness, working to be of service to our community and to keep our planet vibrant. The essence of our brand is consciousness in action. The work we do as human beings matter, and our products and practices are created by conscious decisions based on true wellness and oneness for the planet,our farmers, our employees and, you, the consumers.</p>
                                </div>

                                <div class="col-md-5 col-12"><img class="img-responsive w-100 h-100" src="https://www.organicindia.com/media/cms/Consciousness-rightimage1.jpg" /></div>
                            </div>
                        </div></div>

                    <div class="row">
                        <div class="col-md-12 pt-4 pr-5" >
                            <p className='f-s-14'>With every purchase, ORGANIC INDIA customers can enjoy the healing benefits of our products while supporting the True Wellness of the communities that grow them, the employees who produce them, and the land that nourishes them. In this way, our holistic business model creates no separation between profit and purpose.</p>
                        </div>
                    </div>

                    <p>&nbsp;</p>

                </div>


            </div>
        </div>
    );
};

export default Consciousness;




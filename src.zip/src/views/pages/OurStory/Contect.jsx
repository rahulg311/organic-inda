import React from "react";
import GoogleMapReact from 'google-map-react';
import { Link } from 'react-router-dom';

const AnyReactComponent = ({ text }) => <div>{text}</div>;

export default function Contect(){
  const defaultProps = {
    center: {
      lat: 10.99835602,
      lng: 77.01502627
    },
    zoom: 11
  };

  return (
    // Important! Always set the container height explicitly

    <div className='mt-2 row '>
    <div className='col-md-12 col-12'>
       

        {/* <div class=" ourstory-title blue-gray">
<div class="container">
<div class="row pt-2 pb-2 ">
    <div class="col-md-9">
        <span className='fs-30  Whitney-Medium'>
           Our Story
        </span>
    </div>
    <div class="col-md-3" align="right">
      
    </div>
</div>
</div>
</div> */}
<div className='row green-h'>
<div className='col-12'>


    
<div className='container '>
<nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
<a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon float-end fs-15"></span>
    </button>
  <div class="container-fluid green-h col-12">
   
    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
      <div class=" green-h w-100 ">
      <ul class="nav d-flex justify-content-around green-h">
                    <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                    <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class="nav-res green-h "><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
      </div>
    </div>
  </div>
 
</nav>
{/* <div className=' row  p-3'>
<div class="col-12" >
<ul class="nav d-flex justify-content-around">
                    <li class="active "><Link className='text-white' to="/aboutthecompany">About Us</Link></li>
                    <li class=""><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class=""><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class=""><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class=""><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
            </div>
</div> */}


</div>
</div>
</div>


<div class=" ourstory ">

<div className='row h-420 height-220   '  style={{background:"url('https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg')", backgroundSize:"cover"}}>
                <div
                    className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                >

                    <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className="fs-w-25">OUR STORY</strong> </h1>
                </div>
            </div>
{/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
</div>
<div class="container os-pagecontent" id="showcurrentversion">
<div class="col-md-12 ourstorypagenav">
<Link to="/ourstory" class="btn btn-default aboutusinnerbutton " role="button">Vision &amp; Mission</Link>
<Link to="/aboutthecompany" class="btn btn-default aboutusinnerbutton" role="button">About the Company</Link>
<Link to="/organic" class="btn btn-default aboutusinnerbutton" role="button">Organic And Quality Certifications</Link>

<Link to="contect" class="btn btn-default aboutusinnerbutton active" role="button">Contact Us</Link>
{/* <Link to="#" class="btn btn-default aboutusinnerbutton" role="button">Press/News</Link> */}
</div>
</div>
<div style={{ height: '100vh', width: '100%' }}>
      <GoogleMapReact
        bootstrapURLKeys={{ key: "" }}
        defaultCenter={defaultProps.center}
        defaultZoom={defaultProps.zoom}
      >
        <AnyReactComponent
          lat={59.955413}
          lng={30.337844}
          text="My Marker"
        />
      </GoogleMapReact>
    </div>
<div className='row'> 
<div class="col-md-12 h-r" >
<h4 className='fs-14 pt-2'>Grievances (For Online Purchase Only)</h4>

</div>
</div>
<div className='container'>

<div class="row">
<div class="col-md-12" >
<p className="f-s-14"><u><strong className='fs-13 f-s-18 pb-1'><br/>
GET IN TOUCH WITH US</strong></u><br/>
<strong className='fs-13 f-s-14'>Queries / Feedback / Complaints</strong><br/>
<span className='fs-13 f-s-14'>We are extremely sorry that you are having an issue or complaint with our product or services and regret the inconvenience. We will make every effort to provide a resolution. To get in touch you can:</span><br/>
Call us 18003095153 (From 10 AM to 8 PM, all 7 days a week)<br/>
Email us  <a href="mailto:care@organicindia.com">care@organicindia.com</a><br/>
For International Business - <a href="mailto:export@organicindia.com">export@organicindia.com</a></p>
</div>
</div>
<hr />
<div class="row">
<div class="col-md-6 w-50 col-12 addresslist">
<address><strong>Barabanki</strong><br/>
ORGANIC INDIA Pvt. Ltd.<br/>
C-5/10,Agro Park,<br/>
UPSIDC Kursi Road<br/>
Barabanki-225302</address>
</div>

<div class="col-md-6 w-50 col-12  addresslist">
<address><strong>Delhi</strong><br/>
ORGANIC INDIA Pvt. Ltd.<br/>
Office no -02, Ground floor,<br/>
Uppals Plaza M6, Jasola District Center<br/>
New Delhi - 110025</address>

<address>&nbsp;</address>
</div>

</div>







</div>
<div className='row'> 
<div class="col-md-12 h-r" >
<h4 className='fs-14 pt-2'>Grievances (For Online Purchase Only)</h4>

</div>
</div>
<div className='container'>
<div class="row mb-4">
<div class="col-md-12" >
<p><br/>
Important : Grievance cell must be approached post contacting the "Customer Support" of ORGANIC INDIA where desired resolution were not served.<br/>
In case you are not satisfied with the responses provided by customer care team or with responses to your queries, please contact at:<br/>
<br/>
Email: <a href="mailto:complaint@organicindia.com">complaint@organicindia.com</a></p>

<p>Call us: 9519000106<br/>
<br/>
<u><strong className='fs-14'>Write to us :</strong></u><br/>
Ms. Rashita Pandey<br/>
Grievance Redressal Officer<br/>
ORGANIC INDIA Pvt Ltd<br/>
C-5/10 Agro Park Phase-II UPSIDC Industrial Area,<br/>
Kursi Road Barabanki- 225302, Uttar Pradesh</p>
</div>
</div>
</div>






</div>
</div>
    
  );
}
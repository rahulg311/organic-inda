
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';
import usePost from '../../../hooks/usePost';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';

const Map = () => {
   
    return (
        

        <div className='mt-2 row '>

<div className='col-md-12 col-12'>
   

    {/* <div class=" ourstory-title blue-gray">
<div class="container">
<div class="row pt-2 pb-2 ">
<div class="col-md-9">
    <span className='fs-30  Whitney-Medium'>
       Our Story
    </span>
</div>
<div class="col-md-3" align="right">
  
</div>
</div>
</div>
</div> */}
















<div class=" ourstory ">

<div className='row h-420    '  style={{background:"url('https://organicindiausa.com/wp-content/uploads/Tea-_-Writing-1440x500.jpg')", backgroundSize:"cover"}}>
            <div
                className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

            >

                <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong>Frequently Asked Questions</strong> </h1>
            </div>
        </div>
{/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
</div>
<div class="divider1"></div>



<Tabs>
    
            <TabList>
            
                
<div className='row'>
<div className='col-md-12   d-flex justify-content-center'>

<div className='container mt-7'>
<div class="faqs__filter-label mb-4">Filter by Category:</div>
<div class="faqs__categories-holder">
            <ul class="faqs__categories tablet">
            <Tab>    <li>
                        <a href="#" class="js--category-tab">Ayurveda  Adaptogens</a>
                    </li> </Tab>  
                                            <li class="divider"></li>
                                            <Tab>                            <li>
                        <a href="#" class="js--category-tab">Supplements</a>
                    </li></Tab>  
                                            <li class="divider"></li>
                                            <Tab>         <li>
                        <a href="#" class="js--category-tab">Nutritional Information</a>
                    </li></Tab>  
                                            <li class="divider"></li>
                                            <Tab>          <li>
                        <a href="#" class="js--category-tab">Processing &amp; Manufacturing</a>
                    </li></Tab>  
                                            <li class="divider"></li>
                                            <Tab>         <li>
                        <a href="#" class="js--category-tab active">Safety</a>
                    </li></Tab>  
                                            <li class="divider"></li>
                                            <Tab>          <li>
                        <a href="#" class="js--category-tab">Certification</a>
                    </li></Tab>  
                                                </ul>
          
        </div>
    
{/* <Tab>  <a href="#home">   <p className=" col-2 h-100 fs-15 ">AYURVEDA AND <br /> ADAPTOGENS</p></a>

</Tab>
<Tab>   <a href="#news"><p className="  col-2 fs-15 ">SUPPLEMENTS</p></a></Tab>
<Tab>  <a href="#contact"> <p className="  col-2 fs-15  ">NUTRITIONAL <br />
INFORMATION</p></a></Tab>
<Tab>  <a href="#home">   <p className="  col-2 fs-15 active ">PROCESSING & <br /> MANUFACTURING</p></a>

</Tab>
<Tab>   <a href="#news"><p className="  col-2 fs-15 ">SAFETY
</p></a></Tab>
<Tab>  <a href="#contact"> <p className="  col-2 fs-15  "> CERTIFICATION

</p></a></Tab> */}

</div>

</div>
</div>
</TabList>


<TabPanel>
<div class="row">
<div class="col-md-12">
    <div class="container ">
                            <div class=" active mt-2" >
            <h2 className='text-center fs-36  mb-7'>Ayurveda and Adaptogens</h2>
            <div className='container'></div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq m-0 p-0'>
                <p className='float-start fs-20  fs-20 pt-4 pb-1'>WHAT IS AYURVEDA?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"  data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Originating in India, the 5,000 year-old Ayurvedic medical system is one of the world’s oldest health modalities. “Ayurveda” comes from two Sanskrit words — “ayuh” meaning “life” and “veda” meaning “science” or “wisdom.”

Ayurveda is the sister science to Yoga and is based upon the same ancient Vedic texts. The system teaches us to live in balance with nature by following natural rhythms.</div>
    </div>
              </div>
           
            </div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq  m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1 '>WHAT ARE ADAPTOGENS?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingTwo" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-headingTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Adaptogens are a unique class of herbs: They help balance, restore and protect the body from physical, environmental, and psychological stress. An adaptogen doesn’t have a specific action; they are multidirectional herbs that supports stress responses to normalize physiological functions, leading to stress resilience.</div>
    </div>
              </div>
              <div className='faq w-75 mb-10'></div>
            </div>
  
        </div>
     
                        </div>
</div>
</div>
</TabPanel>
<TabPanel>
<div class="row">
<div class="col-md-12">
    <div class="container ">
                            <div class=" active mt-2" >
            <h2 className='text-center fs-36  mb-7'>Supplements</h2>
            <div className='container'></div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1'>HOW MANY TULSI CAPSULES ARE EQUIVALENT TO ONE CUP OF TEA?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"  data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">There aren’t equivalent doses between Tulsi tea and Tulsi capsules. Tulsi tea is an infusion — hot water allows for fast delivery to the bloodstream, while Tulsi capsules are processed by the digestive system until the phytochemical compounds are absorbed. We suggest Tulsi tea for quick absorption, and Tulsi capsules for those who don’t enjoy tea or who prefer the convenience of capsules.</div>
    </div>
              </div>
           
            </div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq  m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1 '>CAN I EXCEED YOUR SUGGESTED DOSAGE?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingTwo" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-headingTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">We recommend working with a practitioner before electing to increase dosages. Suggested dosages are meant to optimally support the average person. ORGANIC INDIA recommends working with a health professional or Ayurvedic practitioner to determine individualized dosages and to create a health plan that is suited to individual needs.</div>
    </div>
              </div>
       
            </div>
            <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>WHAT ARE ORGANIC INDIA CAPSULES MADE OF?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingThree" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingThree" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">Pullulan is a natural biopolymer obtained from the mushroom species A. pullulans. Pullulan is created by extracting water from the mushroom that is grown organically on a tapioca starch substrate. ORGANIC INDIA’s pullulan is vegan, free of major allergens (soy, wheat, corn, dairy, and nuts), non-gmo, and certified USDA organic.

Pullulan creates an oxygen barrier to ensure the shelf life of ORGANIC INDIA supplements. Pullulan capsules also protect encapsulated herbs from oxidation.</div>
      </div>
                </div>
                
              </div>
              <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>WHAT IS THE DOSAGE FOR SUPPLEMENTS?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingFour" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingFour" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">Dosage varies by product. Please check the bottle/website for suggested dosages. ORGANIC INDIA does not provide individual diagnosis or dosages.

To find an Ayurvedic practitioner, please visit: NAMA – National Ayurvedic Medical Association.</div>
      </div>
                </div>
                <div className='faq w-75 mb-10'></div>
              </div>
  
        </div>
     
                        </div>
</div>
</div>
</TabPanel>
<TabPanel>
<div class="row">
<div class="col-md-12">
    <div class="container ">
                            <div class=" active mt-2" >
            <h2 className='text-center fs-36  mb-7'>Nutritional Information</h2>
            <div className='container'></div>
           
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq  m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1 '>WHAT ARE “FUNCTIONAL” FOODS?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingTwo" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-headingTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">According to the Mayo Clinic website, functional foods are foods that have a potentially positive effect on health beyond basic nutrition.</div>
    </div>
              </div>
       
            </div>
            <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>WHAT DOES “WHOLE HERB” MEAN?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingThree" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingThree" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">Whole herbs, as opposed to tinctures and extracts, provide the fullest spectrum of each plant’s unique phytochemical signature.

We believe whole herbs and whole herbs enhanced with an herbal extract more effective than extracts alone. It is believed that the various constituents and parts of the plant work synergistically.</div>
      </div>
                </div>
                
              </div>
              <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>DO ORGANIC INDIA PRODUCTS CONTAIN CAFFEINE?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingFour" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingFour" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">The following formulations contain caffeine:
<ul>
    <li>Tulsi Breakfast – 25 mg/tea bag</li>
    <li>Tulsi Green – 12 mg/tea bag</li>
    <li>Tulsi Masala Chai – 12 mg/tea bag</li>
  
    </ul>
</div>
      </div>
                </div>
                <div className='faq w-75 mb-10'></div>
              </div>
  
        </div>
     
                        </div>
</div>
</div>
</TabPanel>
<TabPanel>
<div class="row">
<div class="col-md-12">
    <div class="container ">
                            <div class=" active mt-2" >
            <h2 className='text-center fs-36  mb-7'>Processing & Manufacturing</h2>
            <div className='container'></div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1'>ARE ORGANIC INDIA HERBS RAW? STERILIZED?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"  data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Although ORGANIC INDIA is a whole herb company and keeps herbs as close to their natural forms as possible, our herbs are heated above the threshold to be considered raw during the sterilization process. We use a chemical-free, sterilization process to clean our herbs and rid them of harmful pathogens.

The heat treatment is kept at a minimum to maintain the herbs’ essential nutrients and enzymes.</div>
    </div>
              </div>
           
            </div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq  m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1 '>HOW ARE ORGANIC INDIA HERBS PROCESSED?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingTwo" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-headingTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">All ORGANIC INDIA herbs, after being organically grown, are air-dried either in the sun or shade according to each herb’s requirements. ORGANIC INDIA processes all herbs in our own certified organic facilities; we grind our herbs into a 30 mesh particle size to maintain each herb’s botanical integrity, and employ a dry steam sterilization technology to ensure our stringent product safety specifications. Each batch of herbs is then tested to make sure that it is in compliance with AHPA safety standards and regulations for contaminants such as fungus, mold, yeast, bacteria, pesticides, and heavy metals. ORGANIC INDIA does not add any fillers, artificial flavors, colors, or preservatives to products.</div>
    </div>
              </div>
       
            </div>
            <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>WHAT ARE ORGANIC INDIA’S TEA BAGS MADE OF? ARE THEY BLEACHED?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingThree" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingThree" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">The tea bag paper is made of unbleached, organic manila hemp (also known as abaca). The string is made from unbleached cotton fiber. We chose this style because the stringless tea bags that are currently on the market employ filter paper that is coated with a polyamide plastic.</div>
      </div>
                </div>
                
              </div>
              <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>DO YOUR TEA BAGS CONTAIN PLASTIC OR ADHESIVE?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingFour" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingFour" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">ORGANIC INDIA does not utilize plastic of any kind in our tea bags. Tea bags are made from organic manila hemp (also known as abaca) and the string is made from unbleached cotton fiber. ORGANIC INDIA chose this style because most stringless bags on the market employ filter paper that is coated with a polyamide plastic. This type of plastic coating melts under high temperatures, and as a result, some amount of plastic is leached into the tea as it brews.</div>
      </div>
                </div>
             
              </div>
              <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>CAN I USE ORGANIC INDIA PRODUCTS AFTER THE EXPIRATION DATE?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingFive" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingFive" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">While it is unlikely that there would be any safety issue, we do not recommend using our products past the expiration date on the packaging, as we can no longer guarantee the efficacy of the herbs.</div>
      </div>
                </div>
         
              </div>
              <div className='row d-flex justify-content-center '>
                  
            
                  <div className='col-12 w-75 faq  m-0 p-0'>
                    <p className='float-start fs-20  pt-4 pb-1 '>WHAT ARE THE EXACT AMOUNTS OF CONSTITUENTS IN ANY SPECIFIC PRODUCT?</p> 
                    <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingSix" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                  
                  </div>
    
    
                  <div className='col-12 w-75 m-0 p-0'>
                  <div id="flush-headingSix" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
          <div class="accordion-body">ORGANIC INDIA is a whole herb company, and we use the unaltered and natural whole roots and herbs that we grow. Because of this, we don’t measure or print the amount of constituents, such as withanolides, in our herbs because that can vary among different harvests.</div>
        </div>
                  </div>
                  
                </div>
                <div className='row d-flex justify-content-center '>
                  
            
                  <div className='col-12 w-75 faq  m-0 p-0'>
                    <p className='float-start fs-20  pt-4 pb-1 '>WHERE CAN I FIND ORGANIC INDIA PRODUCTS?</p> 
                    <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingSeven" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                  
                  </div>
    
    
                  <div className='col-12 w-75 m-0 p-0'>
                  <div id="flush-headingSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
          <div class="accordion-body">To find stores in your area that carry ORGANIC INDIA products, please visit the Store Locator. Enter your zip code to view which products are carried by a specific retailer. Our products are also available through our website.</div>
        </div>
                  </div>
                  <div className='faq w-75 mb-10'></div>
                </div>
  
        </div>
     
                        </div>
</div>
</div>
</TabPanel>
<TabPanel>
<div class="row">
<div class="col-md-12">
    <div class="container ">
                            <div class=" active mt-2" >
            <h2 className='text-center fs-36  mb-7'>Safety</h2>
            <div className='container'></div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1'>HOW DO YOU ENSURE PRODUCT SAFETY?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"  data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">ORGANIC INDIA is passionate about raising the standards within the organic industry by example, and is among the few herbal companies in India to receive ISO 9001-2008 and Kosher Certifications. We have Organic Certifications from Control Union and Aditi as per USDA, EU and NPOP Organic Standards. ORGANIC INDIA products are verified non-GMO by The Non-GMO Project.</div>
    </div>
              </div>
           
            </div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq  m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1 '>ARE ORGANIC INDIA PRODUCTS THIRD-PARTY TESTED?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingTwo" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-headingTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Yes. ORGANIC INDIA tests each batch of herbs by a third-party certified lab for contaminants such as fungus, mold, yeast, bacteria, pesticides, and heavy metals. We test against standards issued by American Herbal Products Association (click here for more information). Additionally, we ensure Botanical Ingredient Identity Testing of our whole herbs.</div>
    </div>
              </div>
       
            </div>
            <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>ARE ORGANIC INDIA PRODUCTS SAFE FOR PREGNANT WOMEN?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingThree" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingThree" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">We recommend that pregnant women consult with their medical doctor before using any kind of supplement, including ORGANIC INDIA products.</div>
      </div>
                </div>
                
              </div>
              <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>ARE ORGANIC INDIA PRODUCTS SAFE FOR CHILDREN?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingFour" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingFour" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">We do not recommend our products for anyone under the age of 18. Please consult your health care provider before adding any supplement to your children’s wellness regimen.</div>
      </div>
                </div>
             
              </div>
              <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>DO ORGANIC INDIA PRODUCTS HAVE ANY DRUG INTERACTIONS OR <br /> CONTRA-INDICATIONS?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingFive" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingFive" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">We do not advise on the safety of taking our supplements with prescription medications. Please consult your health care practitioner if you are currently under other prescription medication protocols.</div>
      </div>
                </div>
         
              </div>
              <div className='row d-flex justify-content-center '>
                  
            
                  <div className='col-12 w-75 faq  m-0 p-0'>
                    <p className='float-start fs-20  pt-4 pb-1 '>WHAT KIND OF TESTING DOES ORGANIC INDIA DO TO DETERMINE WHETHER <br /> PRODUCTS ARE FREE OF CONTAMINANTS, PESTICIDES, OR HEAVY METALS?</p> 
                    <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingSix" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                  
                  </div>
    
    
                  <div className='col-12 w-75 m-0 p-0'>
                  <div id="flush-headingSix" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
          <div class="accordion-body">ORGANIC INDIA products are certified organic by Control Union and Aditi as per USDA, EU and NPOP Organic Standards. All products are verified non-GMO by The Non-GMO Project. Every batch of ORGANIC INDIA herbs are third-party laboratory tested for pathogens, pesticides, and heavy metals. We test against standards issued by American Herbal Products Association (click here for more information). Only product batches that meet or exceed these standards are made available to consumers.</div>
        </div>
                  </div>
                  
                </div>
                <div className='row d-flex justify-content-center '>
                  
            
                  <div className='col-12 w-75 faq  m-0 p-0'>
                    <p className='float-start fs-20  pt-4 pb-1 '>WHAT IF I HAVE AN ADVERSE REACTION TO ANY ORGANIC INDIA PRODUCTS?</p> 
                    <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingSeven" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                  
                  </div>
    
    
                  <div className='col-12 w-75 m-0 p-0'>
                  <div id="flush-headingSeven" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
          <div class="accordion-body">WHAT IF I HAVE AN ADVERSE REACTION TO ANY ORGANIC INDIA PRODUCTS?</div>
        </div>
                  </div>
                
                </div>
                <div className='row d-flex justify-content-center '>
                  
            
                  <div className='col-12 w-75 faq  m-0 p-0'>
                    <p className='float-start fs-20  pt-4 pb-1 '>WHY IS THERE A WARNING ON THE SUPPLEMENT LABELS AND WHAT IS PROP 65?</p> 
                    <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingEight" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                  
                  </div>
    
    
                  <div className='col-12 w-75 m-0 p-0'>
                  <div id="flush-headingEight" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
          <div class="accordion-body">These labels are a result of California legislation commonly known as Prop 65 — warnings that, according to the American Herbal Products Association, “are well-intentioned, but can be alarming and even misleading, since the warnings often occur on products that present no actual risk.” Learn more about Prop 65 here, or visit the AHPA website.</div>
        </div>
                  </div>
                  <div className='faq w-75 mb-10'></div>
                </div>
  
        </div>
     
                        </div>
</div>
</div>
</TabPanel>
<TabPanel>
<div class="row">
<div class="col-md-12">
    <div class="container ">
                            <div class=" active mt-2" >
            <h2 className='text-center fs-36  mb-7'>Certification</h2>
            <div className='container'></div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1'>WHAT DOES “FAIR TRADE” MEAN?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"  data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">Fair Trade certifications are third-party certifications that set standards for ethical supply chains that compensate suppliers, or growers in the case of ORGANIC INDIA. This certification means that producers are given market value for their goods. Fair Trade goes beyond just fair pricing though, and supports social and economic improvement for producers in countries all over the world. ORGANIC INDIA offers the world’s first Fair Trade certified organic herbals supplements, certified by Fairtrade America.</div>
    </div>
              </div>
           
            </div>
            <div className='row d-flex justify-content-center '>
                
          
              <div className='col-12 w-75 faq  m-0 p-0'>
                <p className='float-start fs-20  pt-4 pb-1 '>WHAT IS A “B” CORPORATION?</p> 
                <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingTwo" aria-expanded="false" aria-controls="flush-collapseOne"></i>
              
              </div>


              <div className='col-12 w-75 m-0 p-0'>
              <div id="flush-headingTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">“B Corp” is a certification awarded by B Labs, a non-profit organization that rigorously examines corporate policies, operations, and methods in areas such as supply chain ethics, labor policies, manufacturing practices, environmental impact, transparency, and accountability. “B” stands for “Beneficial.” There are just under 6,000 certified B Corps worldwide, but that number is growing as businesses align with higher standards of production and trade. In 2018 and 2019, ORGANIC INDIA was awarded the coveted B Corp “Best for the World” designation — this places ORGANIC INDIA in the top 10 percent of all B Corps in terms of alignment with B Corp standards in the above categories.</div>
    </div>
              </div>
       
            </div>
            <div className='row d-flex justify-content-center '>
                
          
                <div className='col-12 w-75 faq  m-0 p-0'>
                  <p className='float-start fs-20  pt-4 pb-1 '>ARE ORGANIC INDIA PRODUCTS CERTIFIED GLUTEN FREE/KOSHER/ORGANIC/  <br /> NON-GMO/DAIRY-FREE/VEGAN?</p> 
                  <i class="fas fa-chevron-right float-end  fs-18 text-center pt-2  arrow-span"   data-bs-toggle="collapse" data-bs-target="#flush-headingThree" aria-expanded="false" aria-controls="flush-collapseOne"></i>
                
                </div>
  
  
                <div className='col-12 w-75 m-0 p-0'>
                <div id="flush-headingThree" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">All ORGANIC INDIA products are vegan and free from gluten, dairy, soy, and corn. Our products are certified USDA Organic, Kosher, Halal and Non-GMO Project Verified. ORGANIC INDIA products contain no artificial ingredients, additives, preservatives, or binders.</div>
      </div>
                </div>
                <div className='faq w-75 mb-10'></div>
              </div>
              
  
        </div>
     
                        </div>
</div>
</div>
</TabPanel>

</Tabs>


</div></div>






 
















































       
   









                  
          
               
          
       );
};

        export default Map;




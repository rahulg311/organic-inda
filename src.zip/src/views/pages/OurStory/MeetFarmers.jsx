
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const MeetFarmers = () => {

    return (

        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>



                <div className='row green-h'>
                    <div className='col-12'>


                        <div className='container '>
                            <nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
                                <a class="navbar-brand" href="#"></a>
                                <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon float-end fs-15"></span>
                                </button>
                                <div class="container-fluid green-h col-12">

                                    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
                                        <div class=" green-h w-100 ">
                                            <ul class="nav d-flex justify-content-around green-h">
                                                <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                                                <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/regenerative">Regenerative Agriculture</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </nav>



                        </div>
                    </div>
                </div>


                <div class=" ourstory ">

                    <div className='row h-420  height-220   ' style={{ background: "url(https://www.organicindia.com/media//cms/banner/meetthefarmers.jpg)", backgroundSize: "cover" }}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25 fs_12'>MEET THE FARMERS</strong> </h1>
                        </div>
                    </div>
                    {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
                </div>
                <div class="containe pxx-5 px-10 os-pagecontent" id="showcurrentversion">
                    <div class="col-md-12 ourstorypagenav">
                        <Link to="/ourstory" class="btn btn-default aboutusinnerbutton active" role="button">Vision &amp; Mission</Link>
                        <Link to="/aboutthecompany" class="btn btn-default aboutusinnerbutton" role="button">About the Company</Link>
                        <Link to="/organic" class="btn btn-default aboutusinnerbutton" role="button">Organic And Quality Certifications</Link>

                        <Link to="contect" class="btn btn-default aboutusinnerbutton" role="button">Contact Us</Link>
                        <Link to="#" class="btn btn-default aboutusinnerbutton" role="button">Press/News</Link>
                    </div>

                    <div class=" os-pagecontent  ">

                        <div class="col-md-12">
                            <h1 className='f-s-18'>Meet The Farmers</h1>
                        </div>

                        <div class="col-md-12 ">
                            <p className='f-s-14' >Farmers are the pillars of <b>ORGANIC INDIA</b>. We take pride in training them - many of them from marginalized groups, including women, widows, the elderly and the illiterate-and providing educational opportunities enabling self-sufficiency and developing skills to pass on to future generations.</p>

                            <p className='f-s-14' >Our relationships are built on mutual respect, dignity and inter-connectedness. Our commitment goes beyond the farm to help enhance the lives of our farmers through fair-market wages, access to healthcare, empowerment and gender equality programmes, as well as improvements in infrastructure. When farmers succeed, their villages also prosper, leading to a collective enhancement of the quality of life.</p>
                        </div>

                    </div>
                    <div className='row  '>

                        <div class="col-md-4 col-12"><iframe allowfullscreen="" frameborder="0" height="169" src="https://www.youtube.com/embed/0iVs7V0AkEI?autoplay=0&amp;controls=1&amp;showinfo=0&amp;rel=0&amp;autohide=0?rel=0&amp;vq=hd720" width="300"></iframe></div>

                        <div class="col-md-4 col-12"><iframe allowfullscreen="" frameborder="0" height="169" src="https://www.youtube.com/embed/8Ar4EspuvYM?autoplay=0&amp;controls=1&amp;showinfo=0&amp;rel=0&amp;autohide=0?rel=0&amp;vq=hd720" width="300"></iframe></div>

                        <div class="col-md-4 col-12"><iframe allowfullscreen="" frameborder="0" height="169" src="https://www.youtube.com/embed/65WDOQeA6eU?autoplay=0&amp;controls=1&amp;showinfo=0&amp;rel=0&amp;autohide=0?rel=0&amp;vq=hd720" width="300"></iframe></div>

                    </div>


















                    <br />
                </div>












            </div>
        </div>
    );
};

export default MeetFarmers;





import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const Organic = () => {
   
    return (
        
        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>
               
      
                {/* <div class=" ourstory-title blue-gray">
    <div class="container">
        <div class="row pt-2 pb-2 ">
            <div class="col-md-9">
                <span className='fs-30  Whitney-Medium'>
                   Our Story
                </span>
            </div>
            <div class="col-md-3" align="right">
              
            </div>
        </div>
    </div>
</div> */}
<div className='row green-h'>
    <div className='col-12'>

    
    <div className='container '>
<nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
<a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon float-end fs-15"></span>
    </button>
  <div class="container-fluid green-h col-12">
   
    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
      <div class=" green-h w-100 ">
      <ul class="nav d-flex justify-content-around green-h">
                    <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                    <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class="nav-res green-h "><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
      </div>
    </div>
  </div>
 
</nav>
{/* <div className=' row  p-3'>
<div class="col-12" >
<ul class="nav d-flex justify-content-around">
                    <li class="active "><Link className='text-white' to="/aboutthecompany">About Us</Link></li>
                    <li class=""><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class=""><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class=""><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class=""><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
            </div>
</div> */}


</div>
</div>
</div>


<div class=" ourstory ">
    {/* <nav class="">
        <div class="">
          
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav ourstorynav d-flex">
                    <li class="active"><a href="https://www.organicindia.com/about-the-company">About Us</a></li>
                    <li class=""><a href="https://www.organicindia.com/meet-the-farmers">Meet the Farmers</a></li>
                    <li class=""><a href="https://www.organicindia.com/consciousness-in-action">Consciousness in Action</a></li> 
                    <li class=""><a href="https://www.organicindia.com/regenerative-agriculture">Regenerative Agriculture</a></li> 
                    <li class=""><a href="https://www.organicindia.com/whole-herb">Whole Herb</a></li> 
                </ul>   
            </div>
        </div>
    </nav> */}
    <div className='row h-420 height-220    '  style={{background:"url('https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg')", backgroundSize:"cover"}}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25'>OUR STORY</strong> </h1>
                        </div>
                    </div>
        {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
    </div>
    <div class="px-10 pxx-5 os-pagecontent" id="showcurrentversion">
    <div class="col-md-12 ourstorypagenav">
        <Link to="/ourstory" class="btn btn-default aboutusinnerbutton " role="button">Vision &amp; Mission</Link>
        <Link to="/aboutthecompany" class="btn btn-default aboutusinnerbutton" role="button">About the Company</Link>
        <Link to="/organic" class="btn btn-default aboutusinnerbutton active " role="button">Organic And Quality Certifications</Link>
        
        <Link to="/contect" class="btn btn-default aboutusinnerbutton" role="button">Contact Us</Link>
        {/* <Link to="#" class="btn btn-default aboutusinnerbutton" role="button">Press/News</Link> */}
     </div>

     <div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>Organic And Quality Certification</h1>

<p className='f-s-14'>We are passionate about raising the standards within the organic industry. Currently, we are amongst the few herbal companies in India to receive HACCP, GMP, ISO 9001-2015&nbsp;and Kosher Certifications. We have Organic Certifications from Control Union and SGS as per USDA, EU and NPOP Organic Standards.</p>

<p className='f-s-14'>From preservation of seed to sowing, from cultivation to harvesting, from processing to production through sales and marketing, each step of the way is a testimony of our commitment to integrity, accountability and responsibility for Holistic Quality Assurance.</p>
</div>
</div>

<div class="row">
<div class="col-md-12">
<h1  className='f-s-18' >EARTHSEER</h1>

<p className='f-s-14'>This new standard reflects a sustainable business commitment which inspires, promotes and supports well-being and respect for all beings and for Mother Nature. Earth Seer stands for:</p>
</div>

<div class="col-md-10">
<ul className='ps-4 fs-17' >
	<li>Ethical</li>
	<li>Accountable</li>
	<li>Reliable</li>
	<li>Trustworthy</li>
	<li>Holistic</li>
	<li>Socially, Environmentally and Economically Responsible</li>
</ul>
</div>

<div class="col-md-2">
<p><br/>
<img class="img-responsive" src="https://www.organicindia.com/media/cms/earthseerlogo.jpg"/></p>
</div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>GMP - Good Manufacturing Practices</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>SGS GMP certification verifies that all required practices necessary for an effective food safety program are being followed. It addresses hygiene in all aspects of the SGS manufacturing process, including premises and equipment, primary production, packaging, warehousing, distribution, pest control and waste management, as well as routine personal hygiene of personnel.</p>

<p><b>ORGANIC INDIA Pvt. Ltd.</b> meets the requirements of Codex Allmentarius Commission Guidelines, Recommended International Code of Practices, General Principles of Food Hygiene, CAC/RCP 1-1969 Rev. 3 (1997).</p>
</div>

<div class="col-md-2"><img class="img-responsive pt-3" src="https://www.organicindia.com/media/cms/sgs.png" /></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>HACCP - Hazard Analysis &amp; Critical Control Points</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>HACCP based Food Safety Management System registration and certification verifies that World Health Organization standards are met in the management of food safety and hygiene. The HACCP-based Food Safety Management System Registration is based on the "criteria for assessment of an operational HACCP system". It is an accredited registration scheme for assessing the operational status and performance of a HACCP-based Food Safety Management System to ensure the safety of foodstuffs. Organizations that successfully complete the assessment earn both a highly regarded HACCP certificate and registration. This acts as an assurance to consumers, retailers, governmental authorities and other interested parties that they may trust the way that the organization controls food safety and food hygiene.</p>
</div>

<div class="col-md-2"><img class="img-responsive img-organic" src="https://www.organicindia.com/media/certi.jpg" /></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>ISO 9001 : 2015</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>Internationally, there is no better guarantee than ISO Certification in earning the buyer's confidence and recognition for a product. The certification ensures vital features such as quality, ecology, safety, economy, reliability, compatibility, inter-operability, efficiency and effectiveness. It also facilitates trade, spreads knowledge, and leads to the sharing of technological advances and good management practices. These standards help achieve benefits for all three dimensions of sustainable development - economic, environmental and social.</p>
</div>

<div class="col-md-2"><img class="img-responsive img-organic" src="https://www.organicindia.com/media/icon_ISO9001.png" /></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>NPOP India Organic</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>The Indian National Programme for Organic Production and the India Organic Logo is governed by APEDA, which provides national standards for organic products through a National Accreditation Policy and Programme.</p>

<p className='f-s-14'>The key tasks of National Programme for Organic Production include:</p>

<ul className='ps-4 fs-17'>
	<li>Providing the means to evaluate certification programmes for organic agriculture &amp; products as per internationally approved criteria.</li>
	<li>Accrediting certification programmes.</li>
	<li>Facilitating certification of organic products in conformity with the National Standards for Organic Products.</li>
	<li>Encouraging the development of organic farming and organic processing.</li>
</ul>
</div>

<div class="col-md-2"><img class="img-responsive" src="https://www.organicindia.com/media/cms/npop.png"/></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>USDA - United States Department of Agriculture</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>The USDA organic certification verifies that all United States Department of Agriculture regulations, requirements and specifications are adhered to. It covers a wide range of detailed monitoring and control measures. It is one of the most comprehensive and demanding certification systems to ensure absolute commitment to Organic Certification qualifications as established by the United States Department of Agriculture.</p>
</div>

<div class="col-md-2"><img class="img-responsive" src="https://www.organicindia.com/media/cms/usda.png"/></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>Control Union</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>Control Union Certifications World Group is an internationally recognized certification organization and carries out inspections and issues certifications for sustainable agricultural, processing and production methods. It certifies that raw materials originate from organic cultivation and are processed using organic methods. Control Union verifies that products have been cultivated according to sustainable production methods by means of supervising, testing, inspecting, assessing and finally certifying them as per the regulations EEC 834/2007, NOP of USDA (National Organic Programme of United States Department of Agriculture) and JAS (Japanese Agricultural Standard).</p>
</div>

<div class="col-md-2"><img class="img-responsive" src="https://www.organicindia.com/media/cms/cuc.png"/></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>EU Organic Certification</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>The EU organic logo guarantees that the product in question complies with the common European organic food standards. Consumers buying products bearing this logo can be confident that at least 95% of the product's ingredients have been organically produced, that the product complies with the rules of the official inspection scheme, it has come directly from the producer or the preparer in a sealed package and that it bears the name of the producer, the preparer or vendor and the name or code of the inspection body.</p>
</div>

<div class="col-md-2"><img class="img-responsive" src="https://www.organicindia.com/media/cms/eu.png"/></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>OU Kosher</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>The OU logo indicates that a product may be consumed by all those who observe Kosher dietary laws, as well as by many others who have special dietary requirements. Today, manufacturers and consumers view the logo as an independent verification of quality, integrity and purity. By far the largest of the Kosher certification agencies - and the most extensive in its global reach - the Orthodox Union is renowned for its ability to serve its clients needs promptly and efficiently. The conferral of OU Kosher certification on ORGANIC INDIA raises its profile and helps expand its market base.</p>
</div>

<div class="col-md-2"><img class="img-responsive pt-3" src="https://www.organicindia.com/media/cms/ou.png" /></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>Soil Association</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>Established in 1973, the Soil Association certifies over 4,500 farms and businesses all over the world and is the most recognized organic mark in the UK today. The Soil Association standards of <b>ORGANIC INDIA</b> exceed the UK government's minimum requirements - especially in areas concerning the environment and animal welfare.</p>
</div>

<div class="col-md-2"><img class="img-responsive" src="https://www.organicindia.com/media/cms/soil.png"/></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>GMO FREE</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>Supporting sustainable agriculture is at the very core of ORGANIC INDIA's mission. Awareness of the devastating impact GMO crops have on farmers in India and worldwide is what spurs our uncompromising support of "Right to Know" GMO labeling efforts.</p>
</div>

<div class="col-md-2"><img class="img-responsive" src="https://www.organicindia.com/media/cms/gmo.png"/></div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>Non GMO Project Verification</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>The majority of ORGANIC INDIA's Tulsi teas and herbal supplements have been verified as Non-GMO. This verification authenticates the integrity of ORGANIC INDIA seeds, herbs and products as natural heritage strains. A Non-GMO Project is a non-profit organization raising awareness about the dangers and unknown aspects of genetically modified foods. Here is the current list of our products carrying this logo, <a href="http://www.nongmoproject.org/find-non-gmo/search-participating-products/search/?brandId=2047s" target="_blank">Click Here</a>. Additional products are in the process of becoming Non-GMO Project Verified.</p>
</div>

<div class="col-md-2"><img class="img-responsive img-size" src="https://www.organicindia.com/media/cms/Non-GMO-project-logo-300x186.jpg" /></div>
{/* style="margin-left: auto; vertical-align:middle;margin-right: auto;display: block;height: 100%;width:130px;" */}
<div class="col-md-2">&nbsp;</div>

<div class="col-md-2">&nbsp;</div>
</div>
<div class="row">
<div class="col-md-12">
<h1 className='f-s-18'>COSMOS certification by ECOCERT</h1>
</div>

<div class="col-md-10">
<p className='f-s-14'>ORGANIC INDIA KURE products have certification from a renowned global body, ECOCERT. Founded in 1991,this body specialises in certification of organic agricultural and cosmetic products. It has become a benchmark in organic certification worldwide. Our products have been awarded the prestigious COSMOS certification by ECOCERT. Within this standard are core principles of respect for biodiversity, use of clean manufacturing processes, green chemistry and transparency to consumers.</p>
</div>

<div class="col-md-2"><img class="img-responsive img-size" src="https://www.biggreensmile.com/images/cms/ECOCERTcrop.jpg"/></div>

<div class="col-md-2">&nbsp;</div>

<div class="col-md-2">&nbsp;</div>
</div>








       
    <br/>      
</div>









                  
          
               
            </div>
        </div>
       );
};

        export default Organic;




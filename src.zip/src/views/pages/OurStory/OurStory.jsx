
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const OurStory = () => {
   
    return (
        
        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>
               
      
                {/* <div class=" ourstory-title blue-gray">
    <div class="container">
        <div class="row pt-2 pb-2 ">
            <div class="col-md-9">
                <span className='fs-30  Whitney-Medium'>
                   Our Story
                </span>
            </div>
            <div class="col-md-3" align="right">
              
            </div>
        </div>
    </div>
</div> */}
<div className='row green-h'>
    <div className='col-12'>

    
    <div className='container '>
<nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
<a class="navbar-brand" href="#"></a>
    <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon float-end fs-15"></span>
    </button>
  <div class="container-fluid green-h col-12">
   
    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
      <div class=" green-h w-100 ">
      <ul class="nav d-flex justify-content-around green-h">
                    <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                    <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class="nav-res green-h "><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
      </div>
    </div>
  </div>
 
</nav>
{/* <div className=' row  p-3'>
<div class="col-12" >
<ul class="nav d-flex justify-content-around">
                    <li class="active "><Link className='text-white' to="/aboutthecompany">About Us</Link></li>
                    <li class=""><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                    <li class=""><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li> 
                    <li class=""><Link  className='text-white' to="/regenerative">Regenerative Agriculture</Link></li> 
                    <li class=""><Link className='text-white' to="/wholeherb">Whole Herb</Link></li> 
                </ul> 
            </div>
</div> */}


</div>
</div>
</div>


<div class=" ourstory ">
    {/* <nav class="">
        <div class="">
          
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav ourstorynav d-flex">
                    <li class="active"><a href="https://www.organicindia.com/about-the-company">About Us</a></li>
                    <li class=""><a href="https://www.organicindia.com/meet-the-farmers">Meet the Farmers</a></li>
                    <li class=""><a href="https://www.organicindia.com/consciousness-in-action">Consciousness in Action</a></li> 
                    <li class=""><a href="https://www.organicindia.com/regenerative-agriculture">Regenerative Agriculture</a></li> 
                    <li class=""><a href="https://www.organicindia.com/whole-herb">Whole Herb</a></li> 
                </ul>   
            </div>
        </div>
    </nav> */}
    <div className='row height-220 h-420    '  style={{background:"url('https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg')", backgroundSize:"cover"}}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1  display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25'>OUR STORY</strong> </h1>
                        </div>
                    </div>
        {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
    </div>
    <div class="container os-pagecontent" id="showcurrentversion">
    <div class="col-md-12 ourstorypagenav">
        <Link to="/ourstory" class="btn btn-default aboutusinnerbutton active" role="button">Vision &amp; Mission</Link>
        <Link to="/aboutthecompany" class="btn btn-default aboutusinnerbutton" role="button">About the Company</Link>
        <Link to="/organic" class="btn btn-default aboutusinnerbutton" role="button">Organic And Quality Certifications</Link>
        
        <Link to="/contect" class="btn btn-default aboutusinnerbutton" role="button">Contact Us</Link>
        {/* <Link to="#" class="btn btn-default aboutusinnerbutton" role="button">Press/News</Link> */}
     </div>

        <div class="row mt-4">
<div class="col-md-8">
<h1 className=''><img src="https://www.organicindia.com/design/images/ourstorylogo.png" />Our Vision</h1>

<p className='f-s-14' >To be a Vehicle of Consciousness in the global market by creating an holistic, sustainable business modality, which inspires, promotes and supports True Wellness and respect for all Beings and for Mother Nature..</p>

<h1><img src="https://www.organicindia.com/design/images/ourstorylogo.png" />Our Mission</h1>

<p className='f-s-14'>To be a trustworthy and innovative global leader in providing genuine organic True Wellness products and solutions for conscious, healthy living.</p>

<h1 ><img src="https://www.organicindia.com/design/images/ourstorylogo.png" />Our Values</h1>

<ul>
	<li>Service to all</li>
	<li>Total integrity</li>
	<li>Absolute commitment to quality</li>
	<li>Respect and devotion to Mother Nature</li>
	<li>No compromise on being who we are</li>
</ul>

<h1><img src="https://www.organicindia.com/design/images/ourstorylogo.png" />Our Commitment</h1>

<ul >
	<li>To deliver genuine organic foods and products to our consumers.</li>
	<li>To introduce a unique and successful business model that is committed to service and integrity, and benefits all.</li>
	<li>To support natural, sustainable, organic, agriculture practices that serve and protect Mother Nature.</li>
	<li>To support the livelihood and well-being of farmers and tribal wildcrafters across rural India.</li>
</ul>
</div>

<div class="col-md-4"><img class="img-responsive w-100"  src="https://www.organicindia.com/media/cms/visionmission.jpg"/></div>
</div>
       
    <br/>      
</div>









                  
          
               
            </div>
        </div>
       );
};

        export default OurStory;




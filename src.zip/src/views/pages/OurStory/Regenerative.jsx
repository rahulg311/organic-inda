
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const Regenerative = () => {

    return (

        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>


                <div className='row green-h'>
                    <div className='col-12'>


                        <div className='container '>
                            <nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
                                <a class="navbar-brand" href="#"></a>
                                <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon float-end fs-15"></span>
                                </button>
                                <div class="container-fluid green-h col-12">

                                    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
                                        <div class=" green-h w-100 ">
                                            <ul class="nav d-flex justify-content-around green-h">
                                                <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                                                <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/regenerative">Regenerative Agriculture</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </nav>



                        </div>
                    </div>
                </div>


                <div class=" ourstory ">

                    <div className='row h-420  height-220  ' style={{ background: "url(https://www.organicindia.com/media//cms/banner/regeneratingagriculture.jpg)", backgroundSize: "cover" }}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25'> REGENERATIVE AGRICULTURE</strong> </h1>
                        </div>
                    </div>
                    {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
                </div>
                <div class="px-10 pxx-5 os-pagecontent mt-3">

                    <div class="row ">
                        <div class="col-md-12">
                            <h1 className='f-s-18'>Regenerative Agriculture</h1>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12 fs-17">
                            <p className='fs-17'><strong className='fs-17'  >ORGANIC INDIA</strong> believes in the power of regeneration. Every year, our network of farmers and wildcrafters works thousands of acres of organic farmland in India to provide quality, organic crops and herbs, while simultaneously reversing environmental degradation in Indian farming communities.</p>

                            <p className='f-s-14'>All of our farmers and tribal wildcrafters are educated in organic and regenerative agricultural practices. Our intention is to leave the planet in better condition than we found it by committing to practices that heal the Earth, enrich biodiversity and regenerate the soil.</p>

                            <p className='f-s-14'>Organic standards form the foundation of <strong className='fs-17'>ORGANIC INDIA</strong>'s farming practices. <strong className='fs-17'>ORGANIC INDIA</strong> has never used synthetic chemicals, GMOs or irradiation. Our regenerative farming practices incorporate organic and biodynamic standards and treat each farm as a unique organism.</p>

                            <p className='f-s-14'>Regenerative agriculture includes the use of comprehensive soil fertility management, seed collection, biodiversity, composting, water management, and crop protection and rotation. These practices help to revive the local ecosystem through carbon sequestration and improved water and soil conditions, ultimately impacting the health of our global ecosystem.</p>

                            <p className='f-s-14'>We also aim to return to the ancient practice of following the rhythms of nature, such as planting and harvesting according to lunar and other natural cycles. Many Indian farming traditions (Vrishka Ayurveda) were lost after the introduction of industrialized agriculture. We offer traditional and regenerative farming practices to our farmers that strengthen their communities and their faith in tradition.</p>

                            <div class="video-container"><iframe allowfullscreen="" frameborder="0" height="100%" src="https://www.youtube.com/embed/TRB4oeHABsw" width="100%"></iframe></div>
                        </div>
                    </div>

                    <p>&nbsp;</p>

                </div>












            </div>
        </div>
    );
};

export default Regenerative;





import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const StoreLocator = () => {
   
    return (
        
        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>
               
      
                <div class=" ourstory-title blue-gray">
    <div class="container">
        <div class="row pt-2 pb-2 ">
            <div class="col-md-9">
                <span className='fs-30  Whitney-Medium'>
                Store Locator
                </span>
            </div>
            <div class="col-md-3" align="right">
              
            </div>
        </div>
    </div>
</div>
<div class="container os-pagecontent storelocatormaindiv">
    
    <div class="row">
        <div class="col-md-12 storelocatorsearch">
            <img className='w-100 p-1'  src="https://www.organicindia.com/store-loc.jpg"/>
            <br/>

<div className='row mt-2'>
            <div class="col-md-4">
                <p class="selctlablestore">Please select your preferred location:</p>  
            </div>
           <div class="col-md-3">
            <select name="statelist" id="statelist" class="form-control selectlocatorbox" onchange="getstorecitylist(this.value)">
                <option value="">Select State</option>
                                <option value="1">Andaman and Nicobar Islands</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Arunachal Pradesh</option>
                                <option value="4">Assam</option>
                                <option value="5">Bihar</option>
                                <option value="6">Chandigarh</option>
                                <option value="7">Chhattisgarh</option>
                                <option value="8">Dadra and Nagar Haveli</option>
                                <option value="9">Daman and Diu</option>
                                <option value="10">Delhi &amp; NCR</option>
                                <option value="11">Goa</option>
                                <option value="12">Gujarat</option>
                                <option value="13">Haryana</option>
                                <option value="14">Himachal Pradesh</option>
                                <option value="15">Jammu and Kashmir</option>
                                <option value="16">Jharkhand</option>
                                <option value="17">Karnataka</option>
                                <option value="18">Kerala</option>
                                <option value="19">Lakshadweep</option>
                                <option value="20">Madhya Pradesh</option>
                                <option value="21">Maharashtra</option>
                                <option value="22">Manipur</option>
                                <option value="23">Meghalaya</option>
                                <option value="24">Mizoram</option>
                                <option value="25">Nagaland</option>
                                <option value="26">Orissa</option>
                                <option value="27">Pondicherry</option>
                                <option value="28">Punjab</option>
                                <option value="29">Rajasthan</option>
                                <option value="30">Sikkim</option>
                                <option value="31">Tamil Nadu</option>
                                <option value="32">Tripura</option>
                                <option value="33">Uttar Pradesh</option>
                                <option value="34">Uttarakhand</option>
                                <option value="35">West Bengal</option>
                                <option value="36">Telangana</option>
                            </select>
        </div> 
		
        <div class="col-md-3">
            <select name="citylist" id="citylist" class="form-control selectlocatorbox">
                <option value="">Select City</option>
            </select>
            <span id="cityloading" className='d-none float-start' >City Loading...</span>
        </div>
        <div class="col-md-2">
            <input type="button" value="Search Now" id="searchstore" class="btn btn-default green-h text-white storelocatorsearchbtn float-start" onclick="getstorelist()" />
        </div>
    </div>
    
    
    
    
    
    </div>
    
    
  


</div>

</div>
<hr />
<div  class="row col-md-12 p-2">
                <b>Come, Experience True Wellness with Us </b>
            <p className='fs-13'>Everyone wants to experience greater health and happiness: and yet, not everyone knows how to eat well, live well and to enjoy lasting health. Little do they realize how profoundly their innate wellness is affected by modern day living.
Wellness stores are dedicated to inspiring conscious choices that serve personal and planetary wellbeing by providing genuine support and evidence-based programs designed by the world’s most renowned wellness experts. These products are designed around organic whole food nutrition, stress management, detoxification and total health support. 
</p>
<b>Experiential One Stop Destination</b>
<p className='fs-13'>
    These stores provide the space for customers to interact with inspired and well-trained consultants who can explain the connection between the way they live and how they feel. They are warm and friendly and go the extra mile to ensure that all your queries are answered and make your shopping experience memorable. 
These stores will be a one stop destination for all information and education on living a healthy conscious life, thus becoming a magnet for people seeking connection and solutions to their everyday health challenges. 


</p>
<b>Total Health Support at Stores</b>
<p className='fs-13'>
    People from all walks of life can benefit, whether they want to reduce stress, build immunity, improve cognitive function and memory or simply to feel better, more active and energized.
The approach of the ORGANIC INDIA Wellness stores is that lifestyle-related health conditions can be prevented the same way they are caused: through our lifestyle choices. What we choose to put inside our body, apply to our bodies and around our homes, is the single largest factor affecting our health.
And for consumers seeking a deeper understanding of preventive and curative solutions to specific conditions, we also offer exclusive video consultation with Dr. Shikha Sharma’s Nutrihealth team of nutritionist and doctors, one of India’s best known and respected professionals. 


</p>
<b>What do we have to offer in Wellness Solutions?</b>
<p className='fs-13'>
    
Each product of the company’s rich wellness range is certified organic and adds value to the life of the consumers by helping them flourish, and live healthy and happy lives. By choosing ORGANIC INDIA you become part of the chain connecting you to Nature and the farmers and participate in ORGANIC INDIA’s mission to create a happier healthier world for everyone

ORGANIC INDIA brings you over 23 delicious flavours of teas and infusions imbibed with the immunity-boosting properties of Ayurvedic herbs such as Mulethi (Licorice), Ashwagandha, Ginger, Giloy (Guduchi), and Turmeric. In addition to this, 6 flavours of a unique proprietary blend of Green Tea and Tulsi form part of the bouquet.

There are more than 30 health-giving, herbal supplements in the ORGANIC INDIA range of products made of certified organic herbs. These supplements help prevent and heal various conditions such as joint pain, heart and sugar imbalances, kidney and liver conditions. 
Ashwagandha, Moringa, Brahmi, Turmeric, Wheat Grass and many more are among the many efficacious Ayurvedic herbs and herb combinations used in the supplements.

The packaged food range comprises certified organic ghee, cereals, jaggery, rice, pasta, pickles, honey, pulses, stevia, cold-pressed oils, including coconut oil, quinoa, apple cider vinegar, pink salt, and more. The ORGANIC INDIA Chyawanprash has an edge over like products as it is made from wild forest antioxidant-rich fruits including Amalaki, and 38 healing herbs.

ORGANIC INDIA CLEAN is a cleansing ritual aimed at enhancing one’s physical, mental and spiritual health. Designed in 2 variations – 7 Day and 21 Day programs – ORGANIC INDIA CLEAN Detox Program has been created by practitioners of Western Medicine and Ayurveda experts.

Our KURE range of Ayurvedic body care products, another of our latest launches, bring you an exclusive range of therapeutic herbal oils that are guaranteed to help you be your best and uplift your sense of well-being with their aromatic goodness. They are made using certified organic, non-toxic, and naturally processed ingredients. 


</p>
<b>ORGANIC INDIA: The Promise of True Wellness</b>
<p className='fs-13'>
    “Wellness” is our inherent natural state of being, with a calm mind and a healthy functioning body. Feeling well, thinking well, looking well, we are free to discover our potential to truly practice Healthy Conscious Living! We experience wellness by caring for ourselves and realizing that our wellness is connected to caring for all of life. With humble beginnings 20 years ago, ORGANIC INDIA marches towards building the organic movement in India and across the globe with solutions for Healthy Conscious Living

</p>
















<hr/>








</div>


























                  
          
               
            </div>
        </div>
       );
};

        export default StoreLocator;




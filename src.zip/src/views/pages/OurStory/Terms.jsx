
import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const Terms = () => {
   
    return (
        
        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>
               
      
                <div class=" ourstory-title blue-gray">
    <div class="container">
        <div class="row pt-2 pb-2 ">
            <div class="col-md-9">
                <span className='fs-30  Whitney-Medium'>
                Terms & Conditions
                </span>
            </div>
            <div class="col-md-3" align="right">
              
            </div>
        </div>
    </div>
</div>
<div class="container os-pagecontent privacypolicy mt-2 mb-2">
   
    <p className='fs-15'>1) Once Order is Placed, your order is proccessed.</p>

<p className='fs-15' >2) It takes 48 Hours to confirm payment with the bank.</p>

<p className='fs-15'>3) Once payment is confirmed with bank, your order is packed and shipped.</p>

<p className='fs-15'>4) Once order is shipped, you will recive an auto email with tracking details on your registered email with website.</p>

<p className='fs-15'>5) Complaints for Replacement of&nbsp;Breakage&nbsp;or&nbsp;Damage Products&nbsp;will be Acceptable Only within 48&nbsp;hours after delivery.</p>

<p className='fs-15'>6) For any queries/details, mail us at care@organicindia.com</p>

<p className='fs-15'>7)&nbsp;ORGANIC INDIA may send you E-mails / SMS communication relating to the Products Information/Promotional activities/Offers Program from time to time on your registered contact details. In case of any objection with such&nbsp;E-mails/SMS, do mail us request on care@organicindia.com to stop email/SMS in future.&nbsp;</p>

<p>&nbsp;</p>

<p className='fs-15'><u><strong className='fs-16'>Refund and Returning Policy</strong></u></p>

<p className='fs-15'><strong className='fs-16'>Regarding Refunding of Amount:-</strong></p>

<p className='fs-15'>We offer a 100% money back guaranty. If you are not satisfied with any of our products that you have purchased from us, we will give you a 100% refund (excluding delivery charge and gift-wrapping where appropriate). Returns for refund must be received back into the warehouse within 15 days from the date of Delivery. When returning goods, please quote the - order number, your name, name of the product and the reason why you are returning the goods. We do not refund users for postage expense of the returning the goods.</p>

<p className='fs-15'><strong className='fs-16'>Regarding Replacement of Product:-</strong></p>

<p className='fs-15'>In a few cases, we ensure that pickup is arranged at the earliest and we ship the replacement as soon as we receive the item from our courier partner.</p>

<p className='fs-15'>Replacement is subject to availability of stock with us. In case a replacement is not available, we will refund the amount for the same.</p>

<p className='fs-15'><strong className='fs-16'><br/>
Payment Policy:-</strong></p>

<ul className='fs-15'>
	<li>ORGANIC INDIA accepts the following forms of payment -</li>
	<li>All electronic means like Debit Card / Net Banking/Mobile Payment</li>
	<li>Payments are processed through CCavanue PG/BillDesk secure website.</li>
	<li>MasterCard or Visa Credit Cards / Debit or ATM Card</li>
	<li>Wire / Bank / Fund Transfer</li>
	<li>Demand Draft</li>
	<li>PayTm</li>
	<li>Mobikwik</li>
	<li>Cash on Delivery</li>
</ul>

<p>&nbsp;</p>

<p className='fs-15'><strong className='fs-16'><br/>
Shipping Information (with in India)</strong></p>

<ul className='fs-15'>
	<li>Shipping is free for Prepaid and Cash on Delivery Orders.</li>
	<li>ORGANIC INDIA using major courier partners like BlueDart, DTDC, Delhivery, GATI, FedEx, EcomExpress &amp; Indian Post to ship parcel within India.</li>
	<li>For Shipping information, Customer has to check within dashboard, Email and SMS for courier name, tracking number and live tracking of parcel.</li>
	<li>Delivery time 3 to 5 working days from placing of order.</li>
</ul>
       
</div>












































                  
          
               
            </div>
        </div>
       );
};

        export default Terms;





import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';

const Wholeherb = () => {

    return (

        <div className='mt-2 row '>
            <div className='col-md-12 col-12'>

                <div className='row green-h'>
                    <div className='col-12'>


                        <div className='container '>
                            <nav class="navbar navbar-expand-lg w-100 navbar-light green-h">
                                <a class="navbar-brand" href="#"></a>
                                <button class="navbar-toggler back-white ms-8 text-white float-end " type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon float-end fs-15"></span>
                                </button>
                                <div class="container-fluid green-h col-12">

                                    <div class="collapse navbar-collapse green-h" id="navbarNavDropdown">
                                        <div class=" green-h w-100 ">
                                            <ul class="nav d-flex justify-content-around green-h">
                                                <li class="active nav-res green-h  "><Link className='text-white w-100' to="/aboutthecompany">About Us</Link></li>
                                                <li class=" nav-res green-h "><Link className='text-white' to="/meetfarmers">Meet the Farmers</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/consciousness">Consciousness in Action</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/regenerative">Regenerative Agriculture</Link></li>
                                                <li class="nav-res green-h "><Link className='text-white' to="/wholeherb">Whole Herb</Link></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </nav>



                        </div>
                    </div>
                </div>


                <div class=" ourstory ">
    
                    <div className='row h-420 height-220   ' style={{ background: "url(https://www.organicindia.com/media//cms/banner/wholeherbscover.jpg)", backgroundSize: "cover" }}>
                        <div
                            className=' col-md-12   d-flex justify-content-center   align-items-center d-block optocity-b bg-dark  '

                        >

                            <h1 className='text-white fw-border fs-1 display- text-center f-HelveticaNeue-Light l-spacing-4'> <strong className='fs-w-25'>WHOLE HERB</strong> </h1>
                        </div>
                    </div>
                    {/* <img src="https://www.organicindia.com/media//cms/banner/ourstorybanner.jpg" class="img-responsive"/> */}
                </div>
                <div class="pxx-5 px-10 os-pagecontent mt-5">

                    <div class="row">
                        <div class="col-md-12">
                            <h5 className='fs-30' className='f-s-18'>Whole Herb</h5>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-7">
                            <p className='f-s-14'>Our herbs are potent and full of life, served to you in a form that is just as Mother Nature intended. Herbs are a complex mixture of many hundreds of compounds, which offer intricate information and buffer against harmful effects. We believe that the sum of the actions of the whole plant are more balanced than any one main constituent. Part of the restorative properties come from the synergistic quality of plants-they weren't meant to be scientifically separated into extracts, they were meant to be offered whole. And modern science confirms what Vedic scriptures have long known-that isolations of compounds alter the essence, or life force, of the whole plant. Every part of an herb is a valuable energetic gift that is magnified when taken as a whole. At <strong className='fs-17'>ORGANIC INDIA</strong>, we believe in the power of the life force of the whole plant, and every product we sell uses only whole plants and herbs in their purest form.</p>
                        </div>

                        <div class="col-md-5"><img class="img-responsive w-100" src="http://organicindia.com/media/cms/ashwagandha.jpg" />
                            <p className='fs-13'>Ashwagandha</p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <p className='f-s-14'>Getting from field to cup or capsule includes advanced processing methods and dehydration technologies to ensure that our herbs retain their maximum level of potency. Our herbs are 100% organic, harvested by hand and locally processed. At the factory, they are dehydrated in a dry, sterile environment to prevent phytochemical breakdown. Then they are coarsely ground at low temperatures to preserve the matrix of the bioactive molecules. Finally, they are filled into 100% vegetarian capsules—free of toxic chemicals, solvents or alcohol. The result is the highest quality, most effective, pure and natural products available today.</p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="video-container"><iframe allowfullscreen="" frameborder="0" height="100%" src="https://www.youtube.com/embed/-T6YpzrhhqQ" width="100%"></iframe></div>
                        </div>
                    </div>

                </div>












            </div>
        </div>
    );
};

export default Wholeherb;




import React, { useEffect, useRef } from 'react';
import useFetch from '../../hooks/useFetch';
import Loading from '../../components/Loading';
import ProductCard from '../../components/Products/ProductCard';
import ProductssSelling from '../../components/Products/ProductssSelling';
import usePost from '../../hooks/usePost';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';
import { notification } from '../../utils/notification';
import api from '../../api';
import Thankyou from './Thankyou';
import { useHistory } from 'react-router-dom';
import { data } from 'jquery';


const Payment = () => {
	const history = useHistory();
	const [show1, setShaw1] = useState(false);
	const [show2, setShaw2] = useState(false);
	const [show3, setShaw3] = useState(false);
	const [addressarr, setAddress] = useState([]);
	const [sub_total, setsub_total] = useState(0);
	const [addressID, setAddressId] = useState(0)
	const [cartData, setcartData] = useState([])
	const [cupanName, setCupanName] = useState("")
	const [orderData, setOrderData] = useState([])
	const getId = JSON.parse(localStorage.getItem('user'));
	const [grandTotal, setGrandTotal] = useState(0)
	const [logintab, setLogin] = useState(true);
	const { isLoading, error, response, doPost } = usePost();
	const { user, userToken, userId, isLoading: isLoading2, doLogin, doLogout } = useAuth();
	const [cupan, setCupan] = useState("")
	const [cupanId, setCupanId] = useState("")
	const [discountAmt, setdiscountAmt] = useState("")
	const [paymentMode, setPaymentMode] = useState()
	const handleSubmit = (e) => {
		e.preventDefault();
		const { mobile, password } = e.target;
		doPost('user_login', {
			mobile: mobile.value,
			password: password.value,
		});
	};
	const redirect = () => {
		history.push('/carts');
	}
	const CardUpdateApi = () => {
		const getCardData = JSON.parse(localStorage.getItem('cart'));
		let request = {
			url: 'cart_update',
			data: { "cart_info": getCardData, "user_id": getId.id },

		}
		api.postother(request).then(data => {
			if (data.data.status == "error") {
				const notify = notification({
					type: "error",
					message: data.data.msg,
				});
				notify();

			}
			else {
				data.data.data.address_info && setAddress(data.data.data.address_info)
				data.data.data.cart_info && setcartData(data.data.data.cart_info)
				data.data.data.sub_total && setsub_total(data.data.data.sub_total)
			}


		})
	}
	function postData(path, access_code, encRequest) {
		console.log(path, "path")
		console.log(access_code, "paaccess_codeth")
		console.log(encRequest, "encRequest")
		document.getElementById("formField1").value = access_code;
		document.getElementById("formField2").value = encRequest;

		document.getElementById("form").action = path;
		document.getElementById("form").submit();
	}

	const MarchPaymentApi = (id) => {
		console.log("check id", id)
          
		// window.open(`https://divashudh.com/api/ccanvenuepayment?order_id=${id}`)
		if(paymentMode==2){
			window.location.replace(`https://divashudh.com/api/ccanvenuepayment?order_id=${id}`)
		}
		else if(paymentMode==3){
			// console.log()
			window.location.replace(`http://divashudh.com/public/api/vouchagrampayment?order_id=${id}`)
		}
		
		// let request = {
		// 	url: `https://divashudh.com/api/ccanvenuepayment?order_id=${id}`,
		// }
		// const formData = new FormData();
		// formData.append("access_code", access_code)
		// formData.append("encRequest", encRequest)

		// api.postMarchPayment(request).then(data => {
		// 	if (data.status == 200) {
		// 		if (data.data.status == "success") {
		// 			setGrandTotal(data.data.data.amount)
		// 			setCupanName(data.data.data.coupon_code)
		// 		}
		// 	}
		// })
	}

	const CupanApi = () => {
		const getCardData = JSON.parse(localStorage.getItem('cart'));
		const temp = getCardData.map((item, index) => {
			return ({ product_id: item.id, quantity: item.quantity })
		})
		let request = {
			url: 'coupon_code',
			data: { "cart_info": temp, "coupon_code": cupan },

		}
		api.postother(request).then(data => {
			if (data.status == 200) {
				if (data.data.status == "success") {
					setGrandTotal(data.data.data.amount)
					setCupanName(data.data.data.coupon_code)
					setCupanId(data.data.data.coupon_id)
				}
				else {
					setGrandTotal(0)
				}
				const notify = notification({
					type: data.data.status == "error" ? 'error' : "success",
					message: data.data.message,
				});
				notify();
			}

		})

	}

	const checkOutApi = () => {

		let request = {
			url: 'checkout',
			data: {
				user_id: getId.id,
				token: getId.remember_token
			}
		}
		api.postother(request).then(data => {
			setAddress(data.data.data.address_info)
			setcartData(data.data.data.cart_info)
			setsub_total(data.data.data.sub_total)



		}).catch((err) => {

		})
	}

	const OrderApi = () => {
		const getCartData = JSON.parse(localStorage.getItem('cart'));
		let request = {
			url: 'order_create',
			headers: {
				"TOKEN-KEY": getId.remember_token,
				"id": getId.id
			},
			data: { "cart_info": getCartData, "user_id": getId.id, "address_id": addressID, "total_amount": sub_total, "discount": sub_total - grandTotal, "coupon_id": cupanId, "payment_mode": paymentMode }

		}
		api.postOtherApi(request).then(response => {
			if (response.status == 200 && response.data.status == "success") {
				setOrderData(response.data)
				response.data.payment &&
					// postData("https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction", response.data.payment.access_key, response.data.payment.encrypted_data);
				MarchPaymentApi(response.data.data)
				const notify = notification({
					type: 'success',
					message: response.data.message,
				});
				notify();

			} else {
				if (response.data.message == "Address is required !") {
					setShaw2(true)
				}
				if (response.data.message == "Payment Mode is required !") {
					setShaw3(true)
				}

				const notify = notification({
					type: 'error',
					message: response.data.message,
				});
				notify();
			}

		}).catch((err) => {
			const notify = notification({
				type: 'error',
				message: "Network Error",
			});
			notify();

		})
	}


	useEffect(() => {
		getId && setLogin(false)
		const getCardData = JSON.parse(localStorage.getItem('cart'));

		getId &&
			checkOutApi()
		getId ? CardUpdateApi() :
			setcartData(getCardData)
	}, [])

	useEffect(() => {
		if (response && response.status === 'error') {
			response?.error && response?.error.forEach((error) => {
				const notify = notification({
					type: 'error',
					message: error,
				});
				notify();
			});
			const notify = notification({
				type: 'error',
				message: response.message,
			});
			notify();

		}
		if (response && response.status === 'success') {
			const notify = notification({
				type: 'success',
				message: 'Login Successful',
			});
			notify();
			doLogin(response.data[0], response.data[0].remember_token, response.data[0].id);
			window.location.reload()
		}
	}, [response]);



	return (
		<div>
			<form id="form" action="https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction'" method="POST">
				<input id="formField1" type="hidden" name="access_code" value="" />
				<input id="formField2" type="hidden" name="encRequest" value="" />
			</form>
			{isLoading && <Loading />}
			{
				orderData.data ?

					(orderData.data !== 0 && orderData.payment.length == 0) &&
					<Thankyou orderId={orderData.data} />

					:
					<div >

						{/* slider 1 */}
						<div className="">
							<div className="row m-4  whitec ">
								<div className="col-md-7 m-2">
									<div className="row ">
										<div className="col-md-12">
											<div className="row pt-2 pb-2  text-dark border">
												<div className="col-md-12 col-12 d-flex " onClick={(e) => logintab && setShaw1(!show1)}>
													<span class=" text-white    "><p className='fs-5 green-h  ps-2 pe-2 mt-2 f-1'> 1</p></span>
													<h5 className='ms-3 mt-3 text-muted f-HelveticaNeue-Light f-1' > LOGIN <span style={{ color: "black" }}>{getId && getId.user_full_name} : {getId && getId.user_mobile}</span>  </h5>

												</div>

											</div>

										</div>

									</div>
									{
										show1 == true && <>
											<div className="row border mt-4 mb-2 m-top-nagative ">
												<div className="col-md-12">
													<div className="row pt-2 pb-2 bg-green text-white green-h ">
														<div className="col-md-11 col-10 d-flex">
															<span class=" green-h-text   "><p className=' bg-white ps-2 pe-2 mt-2 f-1'> 1</p></span>
															<h5 className='ms-3 mt-3 f-HelveticaNeue-Light f-1'> LOGIN OR SIGNUP</h5>
														</div>
														<div className="col-md-1 col-2">
															<h2 className='ms-3 mt-2'> <i class="fas fa-chevron-up" onClick={(e) => setShaw1(!show1)}></i></h2>
														</div>
													</div>
													<div className="row mt-4 mb-2 mb-5">
														<div className="col-md-12">
															{

																logintab == true ?
																	<div className="container">
																		<div className="row gap-7">
																			<div className="col-md-6   ">
																				<form action='' onSubmit={handleSubmit}>
																					<div class='mb-3'>
																						<label for='exampleFormControlInput1' class='form-label'>
																							Email Address / Mobile No.*
																						</label>
																						<input
																							type='text'
																							class='form-control'
																							id='exampleFormControlInput1'
																							placeholder=''
																							name='mobile'
																						/>
																					</div>
																					<div class='mb-3'>
																						<label for='exampleFormControlInput1' class='form-label'>
																							Password
																						</label>
																						<input
																							type='password'
																							class='form-control'
																							id='exampleFormControlInput1'
																							placeholder=''
																							name='password'
																						/>
																					</div>
																					<div class='mt-4'>
																						<button type='submit' class="btn green-h w-90 text-white pt-2 pb-2 f-1 rounded-6" disabled={isLoading}>
																							Login
																						</button>
																					</div>
																				</form>
																				<div id="passwordHelpBlock" class="form-text">
																					<p className="ml-2 mt-3 mb-3">  By Countinuing, you agree to Organic India <span className='green-h-text'>Terms of use</span> and <span className='green-h-text fw-1'> Privacy Policy</span> </p>
																				</div>
																				<div className="row mt-2">
																				</div>
																			</div>
																			<div className="col-md-5 ms-2  mb-2 ">
																				<p className="mt-2 text-muted f-1 ms-2 f-HelveticaNeue-Light">Advantages of your secure login</p>
																				<p className="p-1 m-0 text-muted mt-1 f-0-8 f-HelveticaNeue-Light"> <i class="fas fa-shuttle-van green-h-text me-2"></i>Easily Track Oders, Hassle free returns</p>
																				<p className="p-1 m-0 text-muted  mt-1 f-0-8 f-HelveticaNeue-Light"><i class="fas fa-bell green-h-text me-2"></i>Get Relavent Alerts and  Recomendation</p>
																				<p className="p-1 m-0  f-0-8  mt-1 f-HelveticaNeue-Light text-muted"> <i class="fas fa-star green-h-text me-2"></i>Wishlist, Relavant , Ratings and more</p>
																			</div>
																		</div>
																	</div> :
																	<div>

																	</div>
															}

														</div>
													</div>
												</div>
											</div>
										</>
									}
									<div className="row mt-4">
										<div className="col-md-12">
											<div className="row pt-3 pb-1  text-dark border">
												<div className="col-md-11 col-10 d-flex" onClick={(e) => setShaw2(!show2)}>
													<span class=" text-white    "><p className='fs-5 green-h  ps-2 pe-2 mt-2 f-1'> 2</p></span>
													<h5 className='ms-3 mt-2 text-muted f-HelveticaNeue-Light f-1'> DELIVERY ADDRESS</h5>
												</div>

												<div className="col-md-1 col-2">
													<h2 className='ms-3 mt-2'> <i class="fas fa-plus green-h-text fs-1  " ></i></h2>
												</div>
											</div>

										</div>

									</div>
									{
										show2 == true && <>
											<div className="row  mt-4 m-top-nagative  ">
												<div className="col-md-12 border ">

													<div className="row pt-2 pb-2 bg-green text-white green-h ">
														<div className="col-md-10 col-9 d-flex" onClick={(e) => setShaw2(!show2)}>
															<span class=" green-h-text   "><p className='fs-5  bg-white ps-2 pe-2 mt-2 f-1'> 2</p></span>
															<h5 className='ms-3 mt-3 f-HelveticaNeue-Light f-1' > DELIVERY ADDRESS</h5>
														</div>

														{
															getId && getId.id && <div className="col-md-2 col-3 ">
																<Link to='/myaddress'>
																	<button type="button" class="btn btn-light mt-3 float-end rouded-0 green-h-text fs-7">Add New</button></Link>
															</div>

														}

													</div>

													<div className="row mb-2 mt-3">
														{getId ?
															addressarr &&
															addressarr.map((item, index) => (<>
																<div className="col-md-6 border m-2 ms-5  ">
																	<div className="row">
																		<div className="col-md-11 col-8 mt-2">  <h4>{item.first_name} {item.last_name}</h4></div>
																		<div className="col-md-1 col-2  mt-2"><div class="form-check">
																			<input class="form-check-input fs-5" type="radio" name="address" id="flexRadioDefault1" onChange={() => setAddressId(item.id)} />

																		</div></div>
																	</div>
																	<p className='m-0'>Address: {item.address_line_1},{item.city_name}, {item.state_name}, {item.address_pincode}</p>
																	{
																		item.address_line_2 != null && <span>Address: {item.address_line_2},{item.city_name}, {item.state_name}, {item.address_pincode}</span>
																	}
																	<p >      Mobile No : {item.user_mobile}</p>
																	{
																		item.user_gst != null && <p> gst:{item.user_gst}</p>
																	}

																	{/* <p className='mb-7 f-1'>{item.address_user_address, item.city_name,item.address_pincode}</p>
															<h7>city:</h7> <p>{item.city_name}</p> */}

																</div>

															</>)) :
															<div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>

																<h5> No Address Found!</h5>
															</div>
														}


													</div>

												</div>
											</div>

										</>
									}

									<div className="row pt-2 pb-2  text-dark border mt-4">
										<div className="col-md-12  d-flex col-12" onClick={(e) => setShaw3(!show3)}>
											<span class=" text-white    "><p className='fs-5 green-h  ps-2 pe-2 mt-2'> 3</p></span>
											<h4 className='ms-3 mt-3 text-muted f-HelveticaNeue-Light f-1 '> PAYMENT OPTAION </h4>
										</div>

									</div>
									{show3 == true && <>
										<div className="row border mt-4 mb-2 bg-white m-top-nagative">
											<div className="col-md-12">
												<div className="row  green-h text-white">
													<div className="col-md-11 d-flex col-9 mt-2">
														<span class=" green-h-text   "><p className='fs-5  bg-white ps-2 pe-2 mt-2'> 3</p></span>
														<h4 className="p-2  f-1-2 mt-1 text-white f-HelveticaNeue-Light f-1"> PAYMENT OPTAION</h4>
													</div>
													<div className="col-md-1">
														<h2 className='ms-3 mt-3'> <i class="fas fa-chevron-up" onClick={(e) => setShaw3(!show3)}></i></h2>
													</div>
												</div>
												<div className="row mt-4 mb-2">
													<div className="col-md-12">
														<div className="container">
															<div className="col-md-12  border mt-2 mb-2">
																<div class="form-check pt-2 pb-2 ps-7  ">
																	<input class="form-check-input green-h-text green-h" type="radio" name="flexRadioDefault" id="flexRadioDefault1 " onChange={() => setPaymentMode(1)} />
																	<label class="form-check-label  f-Whitney-Medium " for="flexRadioDefault1">
																		Cash On Delivary
																	</label>
																</div>
															</div>
															<div className="col-md-12  border mt-2 mb-2 ">
																<div class="form-check pt-2 pb-2 ps-7">
																	<input class="form-check-input green-h-text green-h " type="radio" name="flexRadioDefault" id="flexRadioDefault1 " onChange={() => setPaymentMode(2)} />
																	<label class="form-check-label  f-Whitney-Medium " for="flexRadioDefault1">
																		Online
																	</label>
																</div>
															</div>

															<div className="col-md-12  border mt-2 mb-2">
																<div class="form-check pt-2 pb-2 ps-7  ">
																	<input class="form-check-input green-h-text green-h" type="radio" name="flexRadioDefault" id="flexRadioDefault1 " onChange={() => setPaymentMode(3)} />
																	<label class="form-check-label  f-Whitney-Medium " for="flexRadioDefault1">
																		Vouchagram	Reward																</label>
																</div>
															</div>

														</div>
													</div>
												</div>
											</div>
										</div>
									</>

									}

									<div className="row mt-4">
										<div className="col-md-12 d-flex ">

											<h6 className="ml-2">  <i class="fas fa-check-square  mt-2 me-2"></i>     Safe & Secure payment</h6>
										</div>
									</div>
									<div className="row mt-2 mb-2">

										<div className="col-md-12  col-6 mx-auto d-grid gap-2 d-md-flex justify-content-md-center">
											<button type="button" class="btn green-h fs-16 text-white" onClick={() => OrderApi()}>Continue</button>


										</div>
									</div>
								</div>
								{/* slider 2 */}
								<div className="col-md-4 mt-4  mb-5 m-2">
									<div className="row bg-white ">
										<div className="col-md-12 ">
											<div className="container bg-white border">
												<div className="row mt-4 mb-2 ">
													<div className="col-md-9 col-10">
														<h5 className=" green-h-text mt-1">{cartData.length} Item is your cart</h5>
													</div>
													{/* <Link to='\carts'> */}
													<div className="col-md-3 col-2  text-muted  " style={{ cursor: "pointer" }} onClick={() => redirect()}>
														<h5 className='f-1' >Edit <i class="fas fa-chevron-up text-muted  f-1 ms-4"></i></h5>
													</div>
													{/* </Link> */}
												</div>
												<hr />
												{
													cartData &&
													cartData.map((item, index) => (
														<div className="row">
															<div className="col-md-4 col-3">
																<img style={{ height: "20px", width: "20px" }} className="w-100 h-100" src={item.media_file_path} alt="" />
															</div>
															<div className="col-md-5 col-6">
																<h5 className="m-0 f-1">{item.prd_title}</h5>
																{/* <h6 className="m-0 f-0-8 mt-1 text-muted">{item.prd_title}</h6> */}
																<h6 className="m-0 f-1 text-muted"> {!getId ? item.quantity : item.cart_quantity} x ₹{getId ? item.prd_selling_price : item.price}  </h6>
																{/* <h6 className="m-0 f-1 text-muted"> {!getId ? item.quantity : item.cart_quantity}</h6> */}

															</div>
															<div className="col-md-3 col-3  ">

																{/* <h6 className="mt-7 f-1"> <i class="fas "></i> ₹{getId ? item.prd_selling_price : item.price}</h6> */}
																<h6 className="mt-7 f-1 text-muted" > ₹ {!getId ? (item.quantity * item.price) : (item.cart_quantity * item.prd_selling_price)}  </h6>

															</div>

														</div>
													))
												}

												<hr />
												<div className="row mt-4">
													<div className="col-md-9 col-8 text-muted f-1">
														<h6 className='f-1'>Sub Total</h6>
													</div>
													<div className="col-md-3  col-4 text-muted">

														<h6> 	<i class="fas  me-1 f-1"></i> ₹{getId ? sub_total : cartData.length > 0 ? cartData.reduce((a, b) => a + (b.price || 0), 0) : 0}</h6>
													</div>
												</div>
												<div className="row">
													<div className="col-md-9 col-8 text-muted">
														<h6 className='f-1'>Shihpping Charges</h6>
													</div>
													<div className="col-md-3 col-4 text-muted">
														<h6 className="green-h-text ml-2 f-1">Free</h6>
													</div>
												</div>
												<div className="row">
													<div className="col-md-9 col-8 ">
														<h6 className="green-h-text f-1">Discount {cupanName !== "" && "[" + cupanName + "]"}</h6>
													</div>
													<div className="col-md-3 col-4">
														<h6 className="green-h-text ml-2 f-1">  ₹{grandTotal == 0 ? grandTotal : sub_total - grandTotal}</h6>
													</div>
												</div>

												<hr />
												<div className="row mt-4">
													<div className="col-md-9 col-8">
														<h6 className='text-muted f-1'>Grand Total</h6>
													</div>
													<div className="col-md-3  col-4 text-muted">

														<h6> <i class="fas  me-1 f-1"></i> ₹{getId ? grandTotal == 0 ? sub_total : grandTotal : cartData.length > 0 ? cartData.reduce((a, b) => a + (b.price || 0), 0) : 0}</h6>
													</div>
												</div>
												<div class="form-group row mb-3 mt-4">
													<div class="col-9 mb-0 px-0 pr-2 ms-1"> <input onChange={(e) => setCupan(e.target.value)} value={cupan} id="e-mail" type="text" placeholder="Discount Code" name="email" class="form-control input-box rm-border text-left f-1" /> </div>
													<div class="col-2 px-0 pr-2"> <button onClick={() => { CupanApi(); setCupan("") }} type="button" class="btn green-h text-white  f-1 ms-2 rounded-6 ms-2 me-2">Apply</button> </div>
												</div>

												<div className="row mt-2">
													<div className="col-md-12 d-flex ">
														<div class="form-check mt-2 mb-4 ms-2">
															<input class="form-check-input f-1 green-h " type="checkbox" value="" id="flexCheckChecked" checked />
															<label class="form-check-label f-1" for="flexCheckChecked">
																Redeem Loyalty Points (350)
															</label>
														</div>

													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						{/* slider 1 */}

					</div>

			}



		</div>
	);
};

export default Payment;



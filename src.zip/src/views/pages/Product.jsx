import React, { useEffect, useState } from 'react';
import Loading from '../../components/Loading';
import ProductInfo from '../../components/Product/ProductInfo';
import ProductImgCard from "../../components/Product/ProductImgCard"
import Reviews from '../../components/Product/Reviews';
import SuggestedProducts from '../../components/Product/SuggestedProducts';
import useFetch from '../../hooks/useFetch';
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';

const Product = ({ match, history }) => {
	const { data, isLoading, error, doFetch } = useFetch();
	const [product, setProduct] = React.useState(null);
	const [loading, setLoading] = useState(false);
	const [quantity, setQuantity] = useState(1);
	const [total, setTotal] = useState(0);
	const { getUserToken, getUserId } = useAuth();
	const { doPost } = usePost();

	const incrementProduct = () => {
		setQuantity(quantity + 1);
	};

	const decrementProduct = () => {
		if (quantity > 1) {
			setQuantity(quantity - 1);
		}
	};

	const addToCart = async () => {
		setLoading(true);
		const getCardData = JSON.parse(localStorage.getItem('cart'));
		if (getCardData) {
			const newCart = getCardData.filter((item) => item.id !== product.id);
			const newProduct = {
				...product,
				quantity,
				price: total,
				actualPrice: product.prd_mrp,
			};
			localStorage.setItem('cart', JSON.stringify([...newCart, newProduct]));
			addToCartAPI({id: product.id, quantity: quantity});

			setTimeout(() => {
				setLoading(false);
			}, 1000);
		} else {
			const newProduct = {
				id: product.id,
				quantity,
				price: total,
				actualPrice: product.prd_mrp,
			};
			localStorage.setItem('cart', JSON.stringify([newProduct]));
			addToCartAPI({id: product.id, quantity: quantity});
			setTimeout(() => {
				setLoading(false);
			}, 1000);
		}
	};

	useEffect(() => {
		if (product) {
			setTotal(data?.data[0]?.prd_mrp * quantity);
		}
	}, [quantity]);

	useEffect(() => {
		const id = match.params.id;
		doFetch(`product_details?id=${id}`);
	}, [match.params.id]);

	useEffect(() => {
		if (data) {
			setProduct(data?.data[0]);
			setTotal(data?.data[0]?.prd_mrp * quantity);
		}
	}, [data]);


	/* add to cart api */
	const addToCartAPI = (p) => {

		if (getUserToken()) {
			const data = {
				'user_id': getUserId(),
				'product_id': p.id,
				'quantity': p.quantity
			};

			const headers = {
				headers: {
					'TOKEN-KEY': getUserToken(),
					id: getUserId(),
				},
			};

			doPost('add_to_cart', data, headers);
		}

	};
	/* add to cart api */

	return (
		<div className='container mt-8'>
			{isLoading ? (
				<Loading className='center' />
			) : (
				<div className='row gx-8 gy-6 row-cols-lg-2 row-cols-1'>
					<ProductImgCard
						addToCart={addToCart}
						incrementProduct={incrementProduct}
						decrementProduct={decrementProduct}
						loading={loading}
						product={product}
						quantity={quantity}
					/>
					<ProductInfo product={product} total={total} />
				</div>
			)}
			<SuggestedProducts />
			<Reviews />
		</div>
	);
};


export default Product

import React from "react";
import BlogCard from "../../../components/blog/BlogCard";
import Loading from "../../../components/Loading";
import useAuth from "../../../hooks/useAuth";
import { Link } from "react-router-dom";
import usePost from "../../../hooks/usePost";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
// import SellingProduct from '../../components/home/SellingProduct';
import SellingProduct from "../../../components/home/SellingProduct";

import Herbs from "../../../components/Products/ProductCatugory";
const ProductCategory = () => {
  const { getUserToken, getUserId } = useAuth();
  const { response, isLoading, error, doPost } = usePost();

  React.useEffect(() => {
    const header = {
      headers: {
        "TOKEN-KEY": getUserToken(),
        id: getUserId(),
      },
    };
    const data = { page_num: "1" };
    doPost(`get_blog`, data, header);
  }, []);

  return (
    <div>
      <div>
        {/* 
   <Banner />
   */}
        {/* SLIDER 1 */}
        <div className="row   ">
          <div
            className=" col-md-12 h-520  h-xs-537 background-imgss  d-flex justify-content-center  align-items-center"
            style={{ backgroundImage: "url('assets/imgs/productsbg.png')" }}
          >
            <h3 className="  text-white  fw-bold display-5 text-center f-HelveticaNeue-Light l-spacing-4">
              Product Category Page
            </h3>
          </div>
        </div>

        {/* SLIDER 1 */}
        {/* SLIDER 2 */}
        <div className=" hrrr"></div>
        <div className="text-center">
          <img src="/assets/imgs/media/1.svg" alt="" className="w-80px" />
        </div>
        <Tabs>
          <TabList>
            <div className="row">
              <div className="col-md-12   d-flex justify-content-center">
                <div class="scrollmenu col-12 col-md-6 gap-2">
                  <Tab>
                   
                    <a href="#home">
                     
                      <p className=" f-HelveticaNeue-Light  f-1-8 active ">
                        Teas & Infusions
                      </p>
                    </a>
                  </Tab>
                  <Tab>
                   
                    <a href="#news">
                      <p className=" f-HelveticaNeue-Light   f-1-8">
                        Supplements
                      </p>
                    </a>
                  </Tab>
                  <Tab>
                   
                    <a href="#contact">
                     
                      <p className=" f-HelveticaNeue-Light f-1-8  "> Fiber</p>
                    </a>
                  </Tab>
                </div>
              </div>
            </div>
          </TabList>

          {/* <div className="row mt-5 mb-4 mb-3 scrollmenu">
			
   <div className="col-md-4  c"> 
   </div>
   <div className="col-md-2 col-5 ">
      <h5 className=" font-f">Teas & Infusions</h5>
   </div>
   <div className="col-md-2  col-4">
      <h5 className=" font-f">Supplements</h5>
   </div>
   <div className="col-md-1 col-2">
      <h5 className=" font-f"> Fiber</h5>
   </div>
   <div className="col-md-3 col"> 
   </div>
</div> */}
          {/* SLIDER 2 */}
          {/* SLIDER 3 */}
          <TabPanel>
            <div className="row p-0 m-0">
              <div className="col-md-7 p-0 m-0">
                <img
                  src="assets/imgs/cat-imgs/1.jpg"
                  alt=""
                  className=" w-100 h-100 "
                />
              </div>
              <div className="col-md-5 green-dark d-flex justify-content-center  align-items-center ">
                <div className=" container w-75 w-xs-100  ">
                  <div className="row  xs">
                    <div className="col-md-12">
                      <h3 className="text-white fs-36  font-bold mt-5  pt-5 pb-3 f-HelveticaNeue-Light l-spacing-4">
                        Teas & Infusions{" "}
                      </h3>
                      <p>
                        <span class="brand-name text-white">
                          Revered in India as “The Queen of Herbs,” Tulsi (Holy
                          Basil) is Ayurveda’s cherished adaptogenic herb that
                          has been used for more than 5,000 years. Tulsi is the
                          foundation upon which ORGANIC INDIA teas and infusions
                          are formulated. ORGANIC INDIA whole herb tea infusions
                          are based on the Ayurvedic principle that the greatest
                          benefits are found in the whole plant rather than
                          parts. Tulsi is used to aid in stress relief and
                          uplift mood; support the immune system; and support
                          the body’s natural detoxification process.{" "}
                        </span>
                      </p>
                      {/* <div class="d-grid gap-2 col-md-7 col-12 mx-auto pb-5">
            <button class="btn btn-backround text-white  fs-18 mt-6" type="button">Shop Teas & Infusions</button>
         </div> */}
                      <button
                        type="button"
                        class="btn btn-warr w-xs-100 fs-xs  mt-8  ps-6 rounded-3 pe-6 fs-xs fs-14 mt-5 pl-2 pr-2 mb-5  ms-1 text-white text-uppercase "
                      >
                        SHOP TEAS & INFUSION
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabPanel>
          <TabPanel>
            <div className="row p-0 m-0">
              <div className="col-md-7 p-0 m-0">
                <img
                  src="assets/imgs/tab2.png"
                  alt=""
                  className=" w-100 h-100 "
                />
              </div>
              <div className="col-md-5 green-dark d-flex justify-content-center  align-items-center ">
                <div className=" container w-75 w-xs-100  ">
                  <div className="row  xs">
                    <div className="col-md-12">
                      <h3 className="text-white fs-36  font-bold mt-5  pt-5 pb-3 f-HelveticaNeue-Light l-spacing-4">
                        Supplements{" "}
                      </h3>
                      <p>
                        <span class="brand-name text-white">
                          Revered in India as “The Queen of Herbs,” Tulsi (Holy
                          Basil) is Ayurveda’s cherished adaptogenic herb that
                          has been used for more than 5,000 years. Tulsi is the
                          foundation upon which ORGANIC INDIA teas and infusions
                          are formulated. ORGANIC INDIA whole herb tea infusions
                          are based on the Ayurvedic principle that the greatest
                          benefits are found in the whole plant rather than
                          parts. Tulsi is used to aid in stress relief and
                          uplift mood; support the immune system; and support
                          the body’s natural detoxification process.
                        </span>
                      </p>
                      {/* <div class="d-grid gap-2 col-md-7 col-12 mx-auto pb-5">
            <button class="btn btn-backround text-white  fs-18 mt-6" type="button">Shop Teas & Infusions</button>
         </div> */}
                      <button
                        type="button"
                        class="btn btn-warr w-xs-100 fs-xs  mt-8  ps-6 rounded-3 pe-6 fs-xs fs-14 mt-5 pl-2 pr-2 mb-5  ms-1 text-white text-uppercase "
                      >
                        Shop Herbal Supplements
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabPanel>
          <TabPanel>
            <div className="row p-0 m-0">
              <div className="col-md-7 p-0 m-0">
                <img
                  src="assets/imgs/tab3.png"
                  alt=""
                  className=" w-100 h-100 "
                />
              </div>
              <div className="col-md-5 green-dark d-flex justify-content-center  align-items-center ">
                <div className=" container w-75 w-xs-100  ">
                  <div className="row  ">
                    <div className="col-md-12">
                      <h3 className="text-white fs-36 font-bold mt-5  pt-5 pb-3 f-HelveticaNeue-Light l-spacing-4">
                        Fiber{" "}
                      </h3>
                      <p>
                        <span class="brand-name text-white">
                          ORGANIC INDIA offers psyllium grown utilizing
                          regenerative agriculture to preserve the biodiversity
                          of plants and improve soil health, sequester carbon
                          from the environment, and converse environmental
                          resources. All ORGANIC INDIA Psyllium is harvested
                          from small, family-owned farms and is steam treated as
                          a safe alternative to chemical fumigants. Psyllium is
                          one of the most researched fibers and is known to
                          support digestive health, heart health, and
                          regularity.* Additionally, it is a great gluten-free,
                          vegan baking alternative.
                        </span>
                      </p>
                      {/* <div class="d-grid gap-2 col-md-7 col-12 mx-auto pb-5">
            <button class="btn btn-backround text-white  fs-18 mt-6" type="button">Shop Teas & Infusions</button>
         </div> */}
                      <button
                        type="button"
                        class="btn btn-warr w-xs-100 fs-xs  mt-8  ps-6 rounded-3 pe-6 fs-xs fs-14 mt-5 pl-2 pr-2 mb-5  ms-1 text-white text-uppercase "
                      >
                        Shop Fiber
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabPanel>
        </Tabs>
        <div className=" hrr hrrr"></div>
        <div className="text-center mb-2">
          <img src="/assets/imgs/media/1.svg" alt="" className="w-80px" />
        </div>
        {/* <div className="row">
   <div className="col-md-7 m-0 p-0 h-0 ">
	   <img className="w-100  img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThY0HVz_Pv6yhG2RdkcK-xG5Bv4oGD_bdBxw&usqp=CAU" alt="" />
	   </div>
   <div className="col-md-5  h-100 m-0 p-0  h-0 green-dark  d-flex justify-content-center d-flex align-items-center pt-5 pb-6 ">
      <div className="container mt-6 mb-6 ">
         <h3 className="text-white text-center font-bold mt-3  pt-5 pb-5">Teas & Infusions </h3>
         <p className="text-white">The holy basil plant is a small annual or short-lived perennial shrub, up to 1 metre (3.3 feet) in height. The stems are hairy and bear simple toothed or entire leaves oppositely along the stem. The fragrant leaves are green or purple, depending on the variety. The small purple or white tubular flowers have green or purple sepals and are borne in terminal spikes. The fruits are nutlets and produce numerous seeds. The holy basil plant is a small annual or short-lived perennial shrub, up to 1 metre (3.3 feet) in height. The stems are hairy and bear simple toothed or entire leaves oppositely along the stem. The fragrant leaves are green or purple, depending on the variety. The small numerous seeds.</p>
         <div class="d-grid gap-2 col-md-7 col-12 mx-auto pb-5">
            <button class="btn btn-1" type="button">Shop Teas & Infusions</button>
         </div>
      </div>
   </div>
</div> */}
        {/* <div className='row '>
			<div className='col-md-7 m-0 p-0 '>
				<img className='w-100 h-40' src='assets/imgs/know-your-category/1.png' alt='' />
			</div>
			<div className='col-md-5 m-0 p-0  green-dark h-100 '>
				<div className='container  p-5'>
					<h3 className='text-white text-center font-bold mt-3 '>Teas & Infusions </h3>
					<p className='text-white'>
						The holy basil plant is a small annual or short-lived perennial shrub, up to 1
						metre (3.3 feet) in height. The stems are hairy and bear simple toothed or entire
						leaves oppositely along the stem. The fragrant leaves are green or purple,
						depending on the variety. The small purple or white tubular flowers have green or
						purple sepals and are borne in terminal spikes. The fruits are nutlets and produce
						numerous seeds. The holy basil plant is a small annual or short-lived perennial
						shrub, up to 1 metre (3.3 feet) in height. The stems are hairy and bear simple
						toothed or entire leaves oppositely along the stem. The fragrant leaves are green
						or purple, depending on the variety. The small numerous seeds.
					</p>
					<div class='d-grid gap-2 col-md-7 col-12 mx-auto'>
						<button class='btn btn-1' type='button'>
							Shop Teas & Infusions
						</button>
					</div>
				</div>
			</div>
		</div> */}

        <div className="bg-white h-5 ">
          <img
            className="immg 
              bg-white .d-sm-none .d-md-block"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeIAAABoCAMAAAAaawObAAAAA1BMVEX///+nxBvIAAAASElEQVR4nO3BAQ0AAADCoPdPbQ43oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAODPAMQ4AAG8WSytAAAAAElFTkSuQmCC"
            alt="1"
          />
        </div>
        {/* <div className='row'>
			<div className='col-md-6'>
			<img src="assets/imgs/know-your-category/3.png" class="img-thumbnail" alt="..."/>
			</div>
			<div className='col-md-6'></div>
		</div> */}

        <div className="row  pink-color ">
          <div className="col-md-6  d-flex justify-content-center align-items-center  ">
            <div className="row  mb-2 ">
              <div className="d-grid gap-2 col-md-6 col-10 mx-auto d-g mb-4 d-gg">
                <img
                  className="w-100  position-relative m-t-n "
                  src="assets/imgs/product3.png"
                  alt="1"
                />
                <div>
                  <h6 className="p-text-white mt-3  ">WHOLE-HERB PHILOSOPHY</h6>
                  <p className="p-text-white pb-3 ">
                    Homecare cover letter best university report, best critical
                    analysis essay writer websites for university, write me
                    trigonometry book review good paper writing service, sample
                    essay on
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-6  d-flex justify-content-center ">
            <div className="row ">
              <div className="d-grid gap-2 col-md-6 col-10 mx-auto d-g mb-4 d-gg ">
                <img
                  className="w-100 position-relative m-t-n marginn"
                  src="assets/imgs/product4.png"
                  alt="1"
                />
                <h6 className="p-text-white mt-3  ">TULSI- HOLY BASIL</h6>
                <p className="p-text-white pb-3 ">
                  Homecare cover letter best university report, best critical
                  analysis essay writer websites for university, write me
                  trigonometry book review good paper writing service, sample
                  essay on
                </p>
              </div>
            </div>
          </div>
        </div>
        <SellingProduct title="Best Selling Products" />
        {/* <div className='row green-dark '>
			<div className='col mb-4'>
				<h4 className='text-white mt-4 text-center'>Best Selling Products</h4>
				<div className='container w-80 d-flex justify-content-center mt-4'>
					<div className='row'>
						<div className='col-md-3'>
							<img className='w-100' src='assets/imgs/best-selling/1.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'>
								<button class='btn btn-1 mt-2 mb-2' type='button'>
									Button
								</button>
							</div>
						</div>
						<div className='col-md-3'>
							<img className='w-100' src='assets/imgs/best-selling/2.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'>
								<button class='btn btn-1 mt-2 mb-2' type='button'>
									Button
								</button>
							</div>
						</div>
						<div className='col-md-3'>
							<img className='w-100' src='/assets/imgs/best-selling/3.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'>
								<button class='btn btn-1 mt-2 mb-2' type='button'>
									Button
								</button>
							</div>
						</div>
						<div className='col-md-3'>
							<img className='w-100' src='/assets/imgs/best-selling/4.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'>
								<button class='btn btn-1 mt-2 mb-2' type='button'>
									Button
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> */}

        <Herbs />
        {/* <div className='bg-white mt-4 mb-4'></div> */}
        {/* <div className='row green-dark'>
			<div className='col-md-12'>
				<h3 className='text-white mt-4 text-center font-weight-bold'>KNOW YOUR HERBS</h3>
			</div>
		</div>
		<div className='row bg-white  '>
			<div className='container d-flex justify-content-center mb-4 '>
				<div className='row w-80 mt-5'>
					<div className='col-md-12 mb-2'>
						<p>
							Homecare cover letter best university report, best critical analysis essay writer
							websites for university, write me trigonometry book review good paper writing
							service, sample essay on educational and career goals, about aids awareness in
							essay, professional scholarship essay writer site online admission writer website
							gb sap abap experience resume, business plan plate. Best dissertation
							proofreading services for mba steps writing research paper proposal research
							proposal process steps ...
						</p>
					</div>
					<div className='row'>
						<div className='col-md-3 mb-2'>
							<img className='w-100 ' src='/assets/imgs/know-your-herbs/1.png' alt='1' />
						</div>
						<div className='col-md-3 mb-2'>
							<img className='w-100 ' src='/assets/imgs/know-your-herbs/2.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'></div>
						</div>
						<div className='col-md-3 mb-2'>
							<img className='w-100 ' src='/assets/imgs/know-your-herbs/3.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'></div>
						</div>
						<div className='col-md-3'>
							<img className='w-100 ' src='/assets/imgs/know-your-herbs/4.png' alt='1' />
							<div class='d-grid gap-2 col-6 mx-auto'></div>
						</div>
						<div class='d-grid gap-2 col-12 col-md-3 mx-auto'>
							<button class='btn btn-1' type='button'>
								VIEW ALL
							</button>
						</div>
					</div>
				</div>
			</div>
		</div> */}
        {/* <div className='row green-dark'>
			<div className='col-md-12'>
				<h3 className='text-white mt-4 text-center font-weight-bold h-100'></h3>
			</div>
		</div> */}
        {/* <section style={{ borderTop: 'solid 10px #b39659' }}></section> */}
        {/* <div className='bg-white mt-4 '></div> */}

        <div className="row gap-0">
          <div className="col-md-5 pink-color d-flex justify-content-center  align-items-center ">
            <div className=" container w-75 w-xs-100 ">
              <div className="row  xs  ">
                <div className="col-md-12 ">
                  <h3 className="text-white f-1-5 font-bold mt-5  pt-5 pb-3 f-HelveticaNeue-Light l-spacing-4">
                    Discover our Newest Flavors:{" "}
                  </h3>
                  <p className="text-white f-0-8  f-HelveticaNeue-Light ">
                    The holy basil plant is a small annual or short-lived
                    perennial shrub, up to 1 metre (3.3 feet) in height. The
                    stems are hairy and bear simple toothed or entire leaves
                    oppositely along the stem. The fragrant leaves are green or
                    purple, depending on the variety. The small purple or white
                    tubular flowers have green or purple sepals and are borne in
                    terminal spikes. The fruits are nutlets and produce numerous
                    seeds. The holy basil plant is a small annual or short-lived
                    perennial shrub, up to 1 metre (3.3 feet) in height.
                  </p>
                  {/* <div class="d-grid gap-2 col-md-7 col-12 mx-auto pb-5">
            <button class="btn btn-backround text-white  fs-18 mt-6" type="button">Shop Teas & Infusions</button>
         </div> */}
                  <button
                    type="button"
                    class="btn btn-outline-pink-color w-xs-100 fs-xs border-white ps-6 rounded-3 pe-6 fs-4 mt-5 pl-2 pr-2 mb-5  ms-1 text-white fs-14"
                  >
                    SHOP TULSI INFUSION
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-7 m-0 p-0">
            <img src="assets/imgs/product5.png" alt="" className=" w-100 " />
          </div>
        </div>
        {/* <div className='col-md-5 m-0 p-0  bg-danger '>
				<div className='container  p-5'>
					<h3 className='text-white text-center font-bold mt-3 '>Featured Herb :Tulsi </h3>
					<p className='text-white'>
						The holy basil plant is a small annual or short-lived perennial shrub, up to 1
						metre (3.3 feet) in height. The stems are hairy and bear simple toothed or entire
						leaves oppositely along the stem. The fragrant leaves are green or purple,
						depending on the variety. The small purple or white tubular flowers have green or
						purple sepals and are borne in terminal spikes. The fruits are nutlets and produce
						numerous seeds. The holy basil plant is a small annual or short-lived perennial
						shrub, up to 1 metre (3.3 feet) in height. The stems are hairy and bear simple
						toothed or entire leaves oppositely along the stem. The fragrant leaves are green
						or purple, depending on the variety. The small purple or white tubular flowers have
						green or purple sepals and are borne in terminal spikes. The fruits are nutlets and
						produce numerous seeds.
					</p>
					<div class='d-grid gap-2 col-12 col-md-6  mx-auto'>
						<button class='btn btn-1' type='button'>
							SHOP TULSI INFUSION
						</button>
					</div>
				</div>
			</div>
			<div className='col-md-7 m-0 p-0 '>
				<img className='w-100' src='/assets/imgs/know-your-category/4.png' alt='' />
			</div> */}

        {/* 
<div className="row">
   <div className="col-md-7 h-445 ">
      <img className="w-100 h-445 pe-0 ps-0" src="assets/imgs/banner.jpg" alt="image" />
   </div>
   <div className="col-md-5  green-dark h-445  pe-0 ps-0">
      <div className="container  p-5">
         <h4 className=" p2">Teas & Infusions </h4>
         <p className="">A paragraph is a self-contained unit of discourse in writing dealing with a particular point or idea. A paragraph consists of one or more sentences. Though not required by the syntax of any language, paragraphs are usually an expected part of formal writing, used to organize longer prose.</p>
         <p className="">A paragraph is a self-contained unit of discourse in writing dealing with a particular point or idea. A paragraph consists of one or more sentences. Though not required by the syntax of any .</p>
      </div>
      <a href="" className="text-uppercase btn btn-1 me-auto ms-auto mt-4 mb-4  p-2 d-table">
      SHOP TEAS & INFUSIONS
      </a>
   </div>
</div>
*/}
        {/* SLIDER 3 */}
        {/* Content Part */}
        <section style={{ borderTop: "solid 10px #b39659" }}></section>
      </div>
    </div>
  );
};

export default ProductCategory;

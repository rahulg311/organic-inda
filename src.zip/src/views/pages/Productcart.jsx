import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../hooks/useFetch';
import { useLocation } from 'react-router-dom'
import Loading from '../../components/Loading';
import ProductCard from '../../components/Products/ProductCard';
import HerbalSelling from '../../components/Products/HerbalSelling';
import ProductSellingcart from '../../components/Products/ProductSellingcart';
import ProductList from '../../components/Product/ProductList';
import api from '../../api';
import useAuth from '../../hooks/useAuth';
import usePost from '../../hooks/usePost';
import { notification } from '../../utils/notification';


const Productcart = () => {
	var currentUrl = window.location.href;
	const getId = JSON.parse(localStorage.getItem('user'));
	const [id, setID] = useState(currentUrl.split(':').pop())
	const [prodDetails, setProdDetails] = useState([])
	const [totlItem, setTotalItm] = useState(1)
	const { getUserToken, getUserId } = useAuth();
	const { response, isLoading, doPost } = usePost();
	const [productImgs, setProdImgs] = useState([])
	const [loading, setLoading] = useState(false)
	useEffect(() => {
		setTotalItm(1)
		productDetail()
	}, [id])
	

	const numberOfQunty = (getid) => {
		const getCardData = JSON.parse(localStorage.getItem('cart'));
		getCardData.map((key, index) => {
			if (key.id == getid) {
				setTotalItm(key.quantity)
			}

		})
	}

	const productDetail = () => {
		setLoading(true)
		let request = {
			url: `product_details?prd_slug=${id}`,
			data: { user_id: getId ? getId.id : "" }
		}
		api.postother(request).then(data => {
			setProdDetails(data.data.data)
			numberOfQunty(data.data.data.id)
			setProdImgs(data.data.data.prd_img)
			setLoading(false)

		}).catch((err) => {
			setLoading(false)
		})
	}
	const incrementProduct = () => {
		setTotalItm(totlItem + 1)
		
	};

	const decrementProduct = () => {
		totlItem > 1 &&
			setTotalItm(totlItem - 1)
	};
	const addToCart = async (item) => {
		window.location.reload()
		setLoading(true);
		const notify = notification({
            type: "success",
            message: totlItem + " items  added",
        });
        notify();
		
		const getCardData = JSON.parse(localStorage.getItem('cart'));
		if (getCardData && getCardData.length > 0) {
			const checkItem = getCardData.find(e => e.id === item.id);

			if (checkItem) {
				const newCardData = getCardData.map(key => {
					if (key.id === checkItem.id) {
						const quantity = item.quantity;
						key.quantity = quantity;
						key.price = item.prd_mrp * quantity;
						addToCartApi(key);
					}
					return key;
				})
				localStorage.setItem('cart', JSON.stringify(newCardData));
				setTimeout(() => {
					setLoading(false);
				}, 500);
				return;
			} else {


				addToCartApi(item);
				localStorage.setItem('cart', JSON.stringify(item));

			}

			const newCardData = [
				...getCardData,
				{ ...item, quantity: item.quantity, price: item.prd_mrp * item.quantity, actualPrice: item.prd_mrp },
			];
			localStorage.setItem('cart', JSON.stringify(newCardData));
			setTimeout(() => {
				setLoading(false);
			}, 500);


			return;
		}
		const newCardData = [
			{ ...item, quantity: item.quantity, price: item.price, actualPrice: item.prd_mrp },
		];
		localStorage.setItem('cart', JSON.stringify(newCardData));
		setTimeout(() => {
			setLoading(false);
		}, 500);
	
		return;
	}

	const addToCartApi = (item) => {

		if (getUserToken()) {

			/* send cart to api */
			const data = {
				'user_id': getUserId(),
				'product_id': item.id,
				'quantity': item.quantity
			};

			const headers = {
				headers: {
					'TOKEN-KEY': getUserToken(),
					id: getUserId(),
				},
			};

			doPost('add_to_cart', data, headers);
			/* send cart to api */
		}


	}
	return (
		<>
			{
				loading &&
				<Loading />
			}
			<div className='ms-2 me-2 '>



				{/* slider 1 */}
				<div className="">
					<div className="row m-4  bg-white ">
						<div className="col-md-7">
							<div className="container border">
								<div className="row">
									<div className="col-md-12">
										<div className="container w-40 menu-responsive-w mt-4 mb-4">
											<img className="w-100 h-100" src={prodDetails.featured_img} alt="r" />
										</div>


									</div>


									<div></div>
								</div>

								<div className="row d-flex justify-content-center">

									<div class="col-md-4 col-12   ">


										<div class="input-group ms-6 ">
											<span class="input-group-btn m-1 me-2 ">
												<button type="button" class="quantity-left-minus btn  btn-number border rounded-circle" data-type="minus" data-field="" onClick={() => decrementProduct()}>
													<span class="glyphicon glyphicon-minus fw-bold">-</span>
												</button>
											</span>
											<button type="button" class="quantity-left-minus btn  btn-number border " data-type="minus" data-field="">
												<span class="glyphicon glyphicon-minus ps-2 pe-2 fw-bold">{totlItem}</span>
											</button>
											{/* <input type="text" id="quantity" name="quantity" class="form-control m-1 text-center" value="10" min="1" max="100" placeholder="0" /> */}
											<span class="input-group-btn m-1 ms-2">
												<button type="button" class="quantity-right-plus btn  btn-number border rounded-circle" data-type="plus" data-field="" onClick={() => incrementProduct()}>
													<span class="glyphicon glyphicon-plus fw-bold">+</span>
												</button>
											</span>

										</div>

									</div>
								</div>
								<div className='  d-flex justify-content-center'>
									<div className="row w-50 menu-responsive-w mt-5">

										{/* add products Images in below detail of project  */}
										{
											productImgs && productImgs.map((data, index) => (
												<div className="col-3 pro">
													<img className="w-100 h-100" src={data.product_img} alt="1" />
												</div>
											))
										}



										{/* <div className="col-3 pro">
											<img className="w-100 " src="assets/imgs/h2.png" alt="1" />
										</div>
										<div className="col-3 pro">
											<img className="w-100 " src="assets/imgs/h3.png" alt="1" />
										</div>
										<div className="col-3 pro">
											<img className="w-100 " src="assets/imgs/h2.png" alt="1" />
										</div> */}
									</div>
								</div>
								<div className="row mt-5 mb-4">
									<div className="col-md-12 d-flex justify-content-center">
										<button type="button" class="btn green-h text-white m-2" onClick={(e) => addToCart({ id: prodDetails.id, quantity: totlItem, price: prodDetails.prd_selling_price * totlItem, prd_title: prodDetails.prd_title, prd_mrp: prodDetails.prd_selling_price, media_file_path: prodDetails.featured_img })}>Add to Cart</button>
										<button type="button" class="btn  btn-warr text-white  m-2">Buy Now</button>

									</div>
								</div>



							</div>
						</div>




						<div className="col-md-5">
							<div className="container w-90">

								<div className="row ml-2 ">
									<div className='col-md-12'>
										<h2 className='f-2-1 f-HelveticaNeue-Light p-0 m-0 '>{prodDetails.prd_title}</h2>

										<div class="d-flex  ">
											<div class="ratings fs-12 "> <i class="fa fs-12 fa-star rating-colorr "></i> <i class="fa fs-12 fa-star rating-colorr"></i> <i class="fa fs-12 fa-star rating-colorr"></i> <i class="fa fs-12 fa-star rating-colorr"></i> <i class="fa fa-star fs-12"></i> </div>
											<h5 class="review-count text-muted ms-4">18 Ratings & Reviews</h5>


										</div>
									</div>

									<div className="col-md-12 mt-1">
										<p className="mt-2 fs-25 fw-bold f-HelveticaNeue-Light"> Price ₹ : <span className=""><i class="fa f-rupee-sign"></i> {prodDetails.prd_selling_price} </span></p>
									</div>

								</div>



								<div className="row ml-2">
									<div className="col-md-12 d-flex col-12">
										<h5 className="fs-20 fw-bold f-HelveticaNeue-Light  mt-1 me-2"> Pincode :</h5>
										<input className="border w-50 h-75 menu-responsive-w me-2" type="text" name="" id="" placeholder="  Pincode" />
										<button type="button" class="btn btn-2 green-h text-white ml-2 h-75  ">Check</button>
									</div>
								</div>
								<div className="row mt-2 ">
									<div className="col-md-10 d-flex justify-content-center">
										<button type="button" class="btn green-h text-white m-2" onClick={(e) => addToCart({ id: prodDetails.id, quantity: totlItem, price: prodDetails.prd_selling_price * totlItem, prd_title: prodDetails.prd_title, prd_mrp: prodDetails.prd_selling_price, media_file_path: prodDetails.featured_img })}>Add to Cart</button>
										<button type="button" class="btn   btn-warr text-white m-2">Buy Now</button>

									</div>
								</div>
								<div className="row mt-3">
									<div className="col-md-12">
										<p className='f-0-8'>{prodDetails.prd_short_description}</p>

									</div>
									{
										prodDetails.prd_directions_use !== "null" &&
										<div className="col-md-12">
											<h2>Product Directions Use</h2>
											<p className='f-0-8'>{prodDetails.prd_directions_use}</p>

										</div>
									}
									{
										prodDetails.prd_ingredients !== "null" &&
										<div className="col-md-12">
											<h2>Product Ingredients</h2>
											<p className='f-0-8'>{prodDetails.prd_ingredients}</p>

										</div>
									}

								</div>
							</div>
						</div>
					</div></div></div>
			<hr className='mt-4 mb-2' />
			<div className='ms-2 me-2 '>

				{/* slider 1 */}
				<div className="">
					<div className="row m-4  bg-white ">



						<div className='d-flex justify-content-center'>
							<div className="w-100 mt-2 mb-4 bg-white">
							{prodDetails.product_data&& prodDetails.product_data.length >0 &&
								<div className="row mt-3">
									<div className="col-md-10 col-12">
										<h3 className=' f-1-8  f-HelveticaNeue-Light '>You might be interested in</h3>


									</div>
									{/* <div className="col-md-2 col-12">
										<button type="button" class="btn green-h text-white float-end">View all</button>

									</div> */}
								</div>
}

								<div className='row'>
									{prodDetails.product_data &&
										<div className='col-md-12'>
											<ProductList ProdData={prodDetails.product_data} setID={setID} />
									

										</div>
									}
								</div>
								{prodDetails.recent_view  && prodDetails.recent_view.length>0 &&
								<div class="">
									<hr className='mt-5' />
									<div className="row ">
										<div className="col-md-12 com-12">
											<h3 className="p-3 ps-4 f-HelveticaNeue-Light">Recently Viewed</h3>
										</div>
									</div>
									<div class="row">
										<div className='col-md-12'>
											{prodDetails.recent_view &&
												<ProductList ProdData={prodDetails.recent_view} setID={setID} />
											}
										</div>
									</div>


								</div>
}

								<div class="row">
									<div className='card p-0'>
										<div className='card-header border-bottom'>
											<h3 className='m-0'>Most Usefull Reviews</h3>
										</div>
										<div className='card-body p-0'>
											<div class="col-lg-12 mx-auto ">
												<ul class="list-group">
													{
														prodDetails.product_rating && prodDetails.product_rating.map((item, index) => (
															<li class="list-group-item border-0 border-bottom">
																<div class="media align-items-lg-center flex-column flex-lg-row p-3">
																	<div class="media-body order-2 order-lg-1">
																		
																			<div class="d-flex align-items-center justify-content-between mt-1">
																				<h5 class="mt-0 font-weight-bold mb-2">{item.user_name}</h5>
																				<ul class="list-inline fs-20">
																				
																		{
																			[...Array(5)].map((el, index) =>
																			 ( index < item.start_rating ? <li class="list-inline-item m-0"><i class="fa fa-star text-warning"></i></li>: <li class="list-inline-item m-0"><i class="fas fa-star text-dark"></i></li>  ))
																		}
																				
																					

																				</ul>
																			</div>
																			<p class="font-italic text-muted mb-0 small">{item.comment}</p>

																	

																	</div>

																</div>
															</li>

														))
													}

												</ul>
											</div>
										</div>
									</div>

								</div>
							</div>
						</div>
						{/* slider 1 */}

					</div>
				</div></div>
		</>

	);
};

export default Productcart;



import React, { useEffect, useRef } from 'react';
import useFetch from '../../hooks/useFetch';
import Loading from '../../components/Loading';
import ProductCard from '../../components/Products/ProductCard';
import ProductssSelling from '../../components/Products/ProductssSelling';
import { useState } from 'react';
import { Link } from 'react-router-dom';

const Products = () => {
	const[show1,setShaw1] = useState(false);
	const[show2,setShaw2] = useState(false);
	const[show3,setShaw3] = useState(false);
	

	return (
		<div>
                {/* slider 1 */}
				<div >

{/* slider 1 */}
<div>
                {/* slider 1 */}
                <div className="">
                    <div className="row m-4 gap-6  whitec ">
                        <div className="col-md-8 m-1 mb-3">

                            <div className="row border bg-white">
                                <div className="col-md-12">
                                    <div className="row pt-2 text-black  border">
                                        <div className="col-md-12">
                                            <p className="p-2 f-HelveticaNeue-Light fs-5"> My Cart (2)</p>
                                        </div>
                                    </div>
                                    {/* <hr className="m-0 p-0 w-100"/> */}

                                    {/* Product list starts here */}

                              
                                        
                                        <div className="row  mt-7 mb-2">
                                            <div className="col-md-2 col-6 ">
                                                <img className="w-100 h-100 " src="assets/imgs/product111.png " alt="" />
                                            </div>
                                            <div className="col-md-5 col-6">
                                                <p className="m-0 f-HelveticaNeue-Light fs-3 fw-bold">Amla 1lb Bag </p>
                                                <p className="m-0   f-HelveticaNeue-Light fw-bold">90 ct.bottle </p>
                                                <h6 className="m-0 ">
                                                    <i class="fas fa-rupee-sign me-2"></i><span className="h-5 pt-2 ">1184</span>
                                                </h6>
                                            </div>
                                            <div className="col-md-5 col-12 mt-2 p-2 ">

                                                <p className="text-center f-HelveticaNeue-Light  fw-bold">Delivery within 3 days</p>
                                            </div>

                                        </div>
                                        {/* /* Product name */}

                                        {/* add to cart */ }

                                        <div class=" row align-items-center">


                                            <div className=" col-md-2 col-12 w-20">
                                                <div class="d-flex ">
                                                    <span class="input-group-btn m-2   ">
                                                        <button type="button" class="quantity-left-minus btn  btn-number border rounded-circle" data-type="minus" data-field="">
                                                            <span class="glyphicon glyphicon-minus">-</span>
                                                        </button>
                                                    </span>
                                                   <p className='border text-center mt-2  pt-1 pb-1 ps-3 pe-3'>0</p>
                                                    <span class="input-group-btn m-2">
                                                        <button type="button" class="quantity-right-plus btn  btn-number border rounded-circle" data-type="plus" data-field="">
                                                            <span class="glyphicon glyphicon-plus">+</span>
                                                        </button>
                                                    </span>
                                                </div>
                                            </div>
                                            {/* add to cart */}

                                            {/* wishlist */}
                                            <div class="mt-2 col-md-2 m-0 col-6">
                                                <h5> <i class="fas fa-heart text-danger pe-2"></i><span className=" f-HelveticaNeue-Light  ">Wishlist</span></h5>
                                            </div>
                                            {/* wishlist */}

                                            {/* delete */}
                                            <div class="mt-1 col-md-2 col-6 m-0" >
                                                <h5> <i class="fas fa-trash pe-2   text-danger"></i> <span className="f-HelveticaNeue-Light">Delete</span></h5>
                                            </div>
                                            {/* delete */}


                                        </div>
                                        {/* border line */}
                                        {/* <div className="border-green-lines mt-2 mb-2"></div> */}
                                       {/* border line */}
                                        {/* add to cart */ }

                                      

                                    {/* Product list ends here */}





                                    <div class="d-grid gap-2 col-12 col-md-6 text-center mx-auto mt-4 mb-6 mt-5">

                                        <button class="btn green-h text-white f-HelveticaNeue-Light fs-4" type="button" ><Link to="/payment" className='text-white'>CONTINUE CHECKOUT </Link></button>
                                    </div>
                                </div>
                            </div>


                        </div>
                        {/* slider 2 */}
                        <div className="col-md-3   whitec mb-5 m-1">
                            <div className="row bg-white">
                                <div className="col-md-12 border">
                                    <div className="container bg-white">
                                        <div className="row mt-4 mb-2 ">
                                            <div className="col-md-12 col-12 ">
                                                <h5 className=" f-HelveticaNeue-Light fs-4">PRICE DETAILS</h5>
                                            </div>

                                        </div>
                                        <hr />

                                        <div className="row  mt-5">
                                            <div className="col-md-8 col-7 ">
                                                <p  className='f-HelveticaNeue-Light fs-5 text-muted'>Price (2 items)</p>
                                            </div>
                                            <div className="col-md-4 col-5">
                                                
                                                <p className='fs-6'> <i class="fas fa-rupee-sign me-2  text-muted"></i>5,394</p>
                                            </div>
                                        </div>
                                        <div className="row ">
                                            <div className="col-md-8 col-8">
                                                <p className='f-HelveticaNeue-Light fs-5 text-muted'>Discount</p>
                                            </div>

                                            <div className="col-md-4 d-flex col-4">
                                             
                                                <p className='fs-6'>   <i class="fas fa-rupee-sign me-2 text-muted"></i> -530</p>
                                            </div>
                                        </div>
                                        <div className="row ">
                                            <div className="col-md-8 col-8">
                                                <p className="green-h-text f-HelveticaNeue-Light fs-5 ">Delivery Charges</p>
                                            </div>
                                            <div className="col-md-4 col-4">
                                                <p className="green-h-text f-HelveticaNeue-Light  fs-1'">FREE</p>
                                            </div>
                                        </div>

                                        <hr />
                                        <div className="row ">
                                            <div className="col-md-8 col-7">
                                                <p className='f-HelveticaNeue-Light fs-5 mt-1'>Total  Amount</p>
                                            </div>
                                            <div className="col-md-4 col-5">
                                                
                                                <p className=' f-HelveticaNeue-Light fs-5 mt-1'> <i class="fas fa-rupee-sign text-muted me-2"></i>4.560</p>
                                            </div>



                                        </div>
                                        <hr />
                                        <p className="green-h-text">You will save  585 on this order </p>

                                        <div className="row mt-2 mb-4">
                                            <div className="col-md-12 d-flex ">
                                            <div class="form-check fs-4">
  <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" />
 
</div>
                                              
                                                <p className=" fs-4 f-HelveticaNeue-Light">Safe & secure payment</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* slider 1 */}

            </div>
{/* slider 1 */}

</div>
                {/* slider 1 */}

            </div>
	);
};

export default Products;



import React from 'react'
import useAuth from '../../hooks/useAuth';
import { Link } from 'react-router-dom';

const Profile = ({ history }) => {
	const { user } = useAuth();
	const { getUserToken } = useAuth();

	React.useEffect(() => {
		if (!getUserToken()) {
			history.push('/');
		}
	}, []);

	return (
		<div className='container mt-6'>
			<section className='row  gy-4 gx-7 row-cols-lg-2 row-cols-1'>
				<div className='col'>
					<div className='d-flex justify-content-between'>
						<h1 className='mb-5'>My Account </h1>
						<Link to='/edit-profile'>
							<i class='fas fa-edit fs-19'></i>
						</Link>
					</div>
					<p>Name: {user?.user_full_name} </p>
					<p>Email: {user?.user_email}</p>
					<p>Phone: {user?.user_mobile}</p>
					<p>Address: </p>
				</div>
				<div className='col'>
					<h1 className='mb-5 ps-lg-4 ps-3'>My Orders</h1>
					<section className='rounded-4'>
						<div className='d-lg-flex border p-4 rounded-4  align-item-start mb-5'>
							<div>
								<img
									src='http://localhost:3000/assets/imgs/best-selling/2.png'
									className='w-100px border p-1 rounded-4 me-4'
									alt=''
								/>
							</div>
							<div className='w-100 mt-lg-0 mt-4'>
								<div className='d-flex justify-content-between w-100'>
									<h5>product name </h5>
									<h5>$100</h5>
								</div>
								<div class='d-flex flex-wrap justify-content-between'>
									<small className=''>ID : #32332</small>
									<small>X3</small>
									<small className=''>Date : 12/01/21</small>
									<small className=''>Status : On Going</small>
								</div>
							</div>
						</div>
						<div className='d-lg-flex border p-4 rounded-4  align-item-start mb-5'>
							<div>
								<img
									src='http://localhost:3000/assets/imgs/best-selling/2.png'
									className='w-100px border p-1 rounded-4 me-4'
									alt=''
								/>
							</div>
							<div className='w-100 mt-lg-0 mt-4'>
								<div className='d-flex justify-content-between w-100'>
									<h5>product name</h5>
									<h5>$100</h5>
								</div>
								<div class='d-flex flex-wrap justify-content-between'>
									<small className=''>ID : #32332</small>
									<small>X3</small>
									<small className=''>Date : 12/01/21</small>
									<small className=''>Status : Past Order</small>
								</div>
							</div>
						</div>
					</section>
				</div>
			</section>
		</div>
	);
};

export default Profile


import React, { useEffect, useRef, useState } from 'react';
import useFetch from '../../../hooks/useFetch';
import Loading from '../../../components/Loading';
import ProductCard from '../../../components/Products/ProductCard';
import { Link } from 'react-router-dom';
import API from '../../../api';
import ProductssSelling from '../../../components/Products/ProductssSelling';
import HerbalSelling from '../../../components/Products/HerbalSelling';
import { useHistory } from "react-router-dom";

const ShopByCategory = () => {
    let history = useHistory();
   
    return (
        
        <div className='mt-2 row btn-show '>
            <div className='col-md-12 col-12'>
               
      
             
<div className='row green-h'>
    <div className='col-12 p-0 m-0'>
        <h5 className='text-center text-white  p-0 m-0 p-2  '>Shop By Category <i class="fas fa-times float-end  p-0 m-0 pe-4 mt-1 text-danger" onClick={() => history.goBack()}></i></h5> 

    
  
</div>
</div>
<div className='containe ps-4 pe-4  mb-4'>
<div className='row'>
    <div className='col-md-12'>
    <div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item row">
    <h2 class="accordion-header col-12 p-0" id="flush-headingOne">
      <button class="accordion-button1 collapsed float-start  w-50 " type="button">
        FORMULATION
      </button>
      <i class="fas fa-chevron-down float-end mt-4 f-s-16 pe-3"  data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne"></i>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body p-0">

      <ul class=" p-0 ms-3">
  <li class="list-group-item ul-style border-none "><Link to="/productcart">An item</Link></li>
  <li class="list-group-item ul-style  border-none">A second item</li>
  <li class="list-group-item ul-style  border-none">A third item</li>
  <li class="list-group-item ul-style border-none ">A fourth item</li>
  <li class="list-group-item ul-style border-none ">And a fifth one</li>
</ul>
      </div>
    </div>
  </div>
  <div class="accordion-item row">
    <h2 class="accordion-header col-12 p-0" id="flush-headingTwo">
      <button class="accordion-button1 collapsed float-start  w-50" type="button">
        TEA
      </button>
      <i class="fas fa-chevron-down float-end mt-4 f-s-16 pe-3"  data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo"></i>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body p-0">

      <ul class=" p-0 ms-3">
  <li class="list-group-item ul-style border-none ">An item</li>
  <li class="list-group-item ul-style  border-none">A second item</li>
  <li class="list-group-item ul-style  border-none">A third item</li>
  <li class="list-group-item ul-style border-none ">A fourth item</li>
  <li class="list-group-item ul-style border-none ">And a fifth one</li>
</ul>
      </div>
    </div>
  </div>
 
  <div class="accordion-item row">
    <h2 class="accordion-header col-12 p-0" id="flush-headingThree">
      <button class="accordion-button1 collapsed float-start  w-50" type="button">
      PACKAGED FOOD
      </button>
      <i class="fas fa-chevron-down float-end mt-4 f-s-16 pe-3"  data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseTwo"></i>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body p-0">

      <ul class=" p-0 ms-3">
  <li class="list-group-item ul-style border-none ">An item</li>
  <li class="list-group-item ul-style  border-none">A second item</li>
  <li class="list-group-item ul-style  border-none">A third item</li>
  <li class="list-group-item ul-style border-none ">A fourth item</li>
  <li class="list-group-item ul-style border-none ">And a fifth one</li>
</ul>
      </div>
    </div>
  </div>
  <div class="accordion-item row">
    <h2 class="accordion-header col-12 p-0" id="flush-headingFour">
      <button class="accordion-button1 collapsed float-start  w-50 " type="button">
      BODYCARE
      </button>
      <i class="fas fa-chevron-down float-end mt-4 f-s-16 pe-3"  data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseTwo"></i>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body p-0">

      <ul class=" p-0 ms-3">
  <li class="list-group-item ul-style border-none ">An item</li>
  <li class="list-group-item ul-style  border-none">A second item</li>
  <li class="list-group-item ul-style  border-none">A third item</li>
  <li class="list-group-item ul-style border-none ">A fourth item</li>
  <li class="list-group-item ul-style border-none ">And a fifth one</li>
</ul>
      </div>
    </div>
  </div>
 
 
 
</div>
    </div>
</div>

</div>

   









                  
          
               
            </div>
        </div>
       );
};

        export default ShopByCategory;




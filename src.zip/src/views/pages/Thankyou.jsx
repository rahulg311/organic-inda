import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import checkmark from '../../assets/check-mark.png';

const Thankyou = (props) => {

    useEffect(() => {

        window.localStorage.removeItem('cart');

    }, []);

    return (
       
        <div className='row justify-content-center m-8'>

            <div className='col-sm-3 border text-center'>
              <img style={{height:"80px", width:"80px"}} src={checkmark}/>

                <h1 > Thank  You !</h1>
                <h5>your order id is #{props.orderId} </h5>
               

                <NavLink to="/" className="btn btn-outline-success btn-sm mt-2 mb-2"><i className="fa fa-arrow-left"></i> Go Back to Home</NavLink>
            </div>

        </div>
       

    );
};


export default Thankyou;

import React from 'react'
import Banner from '../../components/home/Banner';
import Cetagory from '../../components/home/Cetagory';
import SellingProduct from '../../components/home/SellingProduct';
import Blogs from '../../components/home/Blogs';
import Herbs from '../../components/home/Herbs';
import Info from '../../components/home/Info';
import api from '../../api'
import { useEffect } from 'react';
import { useState } from 'react'; 
import Loading from '../../components/Loading';

const Home = () => {
	const  [bannerData, setBannerData] = useState([])
	const [loading , setLoading ] = useState(false)
    
	const getBannerData = () =>{
		let request = `home`
		setLoading(true)
		api.get(request).then(data => {
			setLoading(false)
			setBannerData(data.data.data)
		}).catch((err) => {
		})
	}

	useEffect(()=>{
		getBannerData()
	},[])

    return (<>
	{
		loading && <Loading/>
	}
			<div className=''>
				{
					bannerData&& bannerData.slider && <Banner slider = {bannerData.slider} />
				}
				
				<main className='mt-3 '>
					{
						bannerData&& bannerData.category &&  <Cetagory category= {bannerData.category}/>
					}
					{
						bannerData&& bannerData.best_selling_product && <SellingProduct title='Best Selling Products' best_selling_product= {bannerData.best_selling_product}/> 
					}
					
					<Info/>
					{
						bannerData&& bannerData.herb && <Herbs herb={bannerData.herb}/> 
					}
					{
						bannerData&& bannerData.blog && <Blogs blog={bannerData.blog}/> 
						
					}
				
				</main>
			</div>
			</>);
}

export default Home

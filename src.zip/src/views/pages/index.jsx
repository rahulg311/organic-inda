import React from 'react'
import { Route, Switch } from 'react-router-dom';
import { DashboardRoutes } from '../../routes/routes';
import Manu from '../../components/common/Manu';
const index = () => {
	
    return (
			<div>
				<Manu />
				<Switch>
					{DashboardRoutes.map((route, idx) => (
						<Route
							key={idx}
							exact={route.exact}
							path={route.path}
							strict={route.strict}
							component={route.component}
						/>
					))}
				</Switch>
			</div>
		);
}

export default index

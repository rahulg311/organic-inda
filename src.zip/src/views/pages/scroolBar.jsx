import React from 'react'

export const scroolBar = () => {
  return (
    <div>
{/* scrool baar html */}





{/* overflow-auto   h-180" id="style-2" */}





{/* scrool css */}
{/* #style-2::-webkit-scrollbar {
		width: 12px;
		background-color: #F5F5F5;
	  }
	  
	  #style-2::-webkit-scrollbar-thumb {
		border-radius: 10px;
	   border: 10px solid rgba(50, 46, 46, 0.05);
		transform: rotate(-90deg);
	  } */}


    </div>
  )
}
